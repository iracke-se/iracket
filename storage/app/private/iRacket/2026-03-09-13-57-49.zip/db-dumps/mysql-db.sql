/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` enum('top_sticky','bottom_sticky','top','bottom','within_page','random','popup') NOT NULL DEFAULT 'top',
  `views` bigint(20) unsigned NOT NULL DEFAULT 0,
  `clicks` bigint(20) unsigned NOT NULL DEFAULT 0,
  `locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`locations`)),
  `link` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','scheduled') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iracket-cache-scraper_setting_schedule_export_day','N;',1773068268),
('iracket-cache-scraper_setting_schedule_export_enabled','N;',1773068268),
('iracket-cache-scraper_setting_schedule_export_time','N;',1773068268),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-03-09 13:53:05\";s:10:\"updated_at\";s:19:\"2026-03-09 13:53:05\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1773068268);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `from_club_id` bigint(20) unsigned DEFAULT NULL,
  `to_club_id` bigint(20) unsigned DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `born` date DEFAULT NULL,
  `from_club_name` varchar(255) DEFAULT NULL,
  `to_club_name` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `club_transitions_to_club_id_completion_date_index` (`to_club_id`,`completion_date`),
  KEY `club_transitions_from_club_id_completion_date_index` (`from_club_id`,`completion_date`),
  KEY `club_transitions_user_id_index` (`user_id`),
  CONSTRAINT `club_transitions_from_club_id_foreign` FOREIGN KEY (`from_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_to_club_id_foreign` FOREIGN KEY (`to_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_transitions` WRITE;
/*!40000 ALTER TABLE `club_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `team1_score` int(11) DEFAULT NULL,
  `team2_score` int(11) DEFAULT NULL,
  `played_at` date DEFAULT NULL,
  `profixio_match_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_details_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `live_match_details_played_at_division_index` (`played_at`,`division`),
  KEY `live_match_details_profixio_match_id_index` (`profixio_match_id`),
  KEY `live_match_details_is_synced_index` (`is_synced`),
  CONSTRAINT `live_match_details_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_details` WRITE;
/*!40000 ALTER TABLE `live_match_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_games` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_detail_id` bigint(20) unsigned NOT NULL,
  `game_number` varchar(255) DEFAULT NULL,
  `game_type` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) DEFAULT NULL,
  `player2_name` varchar(255) DEFAULT NULL,
  `player1_partner_name` varchar(255) DEFAULT NULL,
  `player2_partner_name` varchar(255) DEFAULT NULL,
  `player1_sets` int(11) DEFAULT NULL,
  `player2_sets` int(11) DEFAULT NULL,
  `winner_name` varchar(255) DEFAULT NULL,
  `profixio_game_id` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_games_synced_match_id_foreign` (`synced_match_id`),
  KEY `live_match_games_live_match_detail_id_game_number_index` (`live_match_detail_id`,`game_number`),
  KEY `live_match_games_profixio_game_id_index` (`profixio_game_id`),
  KEY `live_match_games_is_synced_index` (`is_synced`),
  CONSTRAINT `live_match_games_live_match_detail_id_foreign` FOREIGN KEY (`live_match_detail_id`) REFERENCES `live_match_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `live_match_games_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_games` WRITE;
/*!40000 ALTER TABLE `live_match_games` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_games` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_set_id` bigint(20) unsigned NOT NULL,
  `point_number` int(11) DEFAULT NULL,
  `player1_points` int(11) DEFAULT NULL,
  `player2_points` int(11) DEFAULT NULL,
  `serve` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_points_live_match_set_id_point_number_index` (`live_match_set_id`,`point_number`),
  CONSTRAINT `live_match_points_live_match_set_id_foreign` FOREIGN KEY (`live_match_set_id`) REFERENCES `live_match_sets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_points` WRITE;
/*!40000 ALTER TABLE `live_match_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_points` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_sets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_game_id` bigint(20) unsigned NOT NULL,
  `set_number` int(11) DEFAULT NULL,
  `player1_points` int(11) DEFAULT NULL,
  `player2_points` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_sets_live_match_game_id_set_number_index` (`live_match_game_id`,`set_number`),
  CONSTRAINT `live_match_sets_live_match_game_id_foreign` FOREIGN KEY (`live_match_game_id`) REFERENCES `live_match_games` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_sets` WRITE;
/*!40000 ALTER TABLE `live_match_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_sets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_game_id` bigint(20) unsigned DEFAULT NULL,
  `source` enum('player_added','scraped') NOT NULL DEFAULT 'player_added',
  `is_unofficial` tinyint(1) NOT NULL DEFAULT 0,
  `uuid` uuid NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `player1_match_points` int(11) DEFAULT NULL,
  `player2_match_points` int(11) DEFAULT NULL,
  `player1_opponent_rating` int(11) DEFAULT NULL,
  `player2_opponent_rating` int(11) DEFAULT NULL,
  `player1_points_before` int(11) DEFAULT NULL,
  `player2_points_before` int(11) DEFAULT NULL,
  `player1_points_change` int(11) DEFAULT NULL,
  `player2_points_change` int(11) DEFAULT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `is_manual` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `replaced_by_match_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  KEY `matches_replaced_by_match_id_foreign` (`replaced_by_match_id`),
  KEY `match_lookup` (`player1_id`,`player2_id`,`played_at`,`deleted_at`),
  KEY `matches_is_unofficial_index` (`is_unofficial`),
  KEY `matches_live_match_game_id_foreign` (`live_match_game_id`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_live_match_game_id_foreign` FOREIGN KEY (`live_match_game_id`) REFERENCES `live_match_games` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_replaced_by_match_id_foreign` FOREIGN KEY (`replaced_by_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',1),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',1),
(10,'2025_11_22_173439_create_notifications_table',1),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',1),
(12,'2025_11_22_174607_add_age_to_users_table',1),
(13,'2025_11_22_180425_create_clubs_table',1),
(14,'2025_11_22_180426_create_matches_table',1),
(15,'2025_11_22_180426_create_monthly_rankings_table',1),
(16,'2025_11_22_180427_add_club_id_to_users_table',1),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',1),
(18,'2025_11_22_180433_create_permission_tables',1),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',1),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',1),
(21,'2025_11_22_183254_add_uuid_to_users_table',1),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',1),
(23,'2025_11_22_183655_make_terms_translatable',1),
(24,'2025_11_22_231254_create_scraper_tables',1),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',1),
(26,'2025_11_23_074902_add_icon_to_notifications_table',1),
(27,'2025_11_23_084421_create_scraper_settings_table',1),
(28,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',1),
(29,'2025_11_23_090000_create_contacts_table',1),
(30,'2025_11_23_103307_add_sbtf_player_fields_to_users_table',1),
(31,'2025_11_24_091012_create_banners_table',1),
(32,'2025_11_24_094538_create_user_monitors_table',1),
(33,'2025_11_24_102243_add_connection_fields_to_users_table',1),
(34,'2025_11_24_105000_add_points_tracking_to_matches_table',1),
(35,'2025_11_24_111359_create_club_transitions_table',1),
(36,'2025_12_23_132006_add_match_tracking_fields',1),
(37,'2025_12_23_133213_make_matches_created_by_nullable',1),
(38,'2025_12_23_160000_add_step_tracking_to_scraper_runs_table',1),
(39,'2026_01_23_071913_add_user_fullname_to_users_table',1),
(40,'2026_01_23_120000_add_popup_scraper_fields_to_scraped_tables',1),
(41,'2026_02_01_100000_create_live_match_details_table',1),
(42,'2026_02_01_100001_create_live_match_games_table',1),
(43,'2026_02_01_100002_create_live_match_sets_table',1),
(44,'2026_02_01_100003_create_live_match_points_table',1),
(45,'2026_02_02_110300_add_match_points_to_matches_table',1),
(46,'2026_02_10_141200_alter_game_number_to_string',1),
(47,'2026_02_10_141500_add_live_match_game_id_to_matches_table',1),
(48,'2026_03_04_000001_add_locale_to_users_table',1),
(49,'2026_03_05_000001_add_district_to_users_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `opponent_name` varchar(255) DEFAULT NULL,
  `result` varchar(1) DEFAULT NULL,
  `opponent_points` int(11) DEFAULT NULL,
  `match_points` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `scraped_month` varchar(7) DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `ranking_date` date DEFAULT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_diff` varchar(255) DEFAULT NULL,
  `rmld_id` varchar(255) DEFAULT NULL,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_ranking_id` bigint(20) unsigned DEFAULT NULL,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  KEY `scraped_rankings_synced_ranking_id_foreign` (`synced_ranking_id`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_ranking_id_foreign` FOREIGN KEY (`synced_ranking_id`) REFERENCES `monthly_rankings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
INSERT INTO `scraper_logs` VALUES
(1,1,'info','Starting: Creating Database Backup','[]','2026-03-09 12:57:49','2026-03-09 12:57:49');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `current_step` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `steps_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`steps_data`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
INSERT INTO `scraper_runs` VALUES
(1,'full_scrape','Step 1/9: Creating Database Backup','running','{\"month\":\"2026-03\",\"all\":false,\"no_backup\":false}',NULL,0,0,NULL,'2026-03-09 12:57:49',NULL,'2026-03-09 12:57:49','2026-03-09 12:57:49');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php','string','urls','URL for players list scraper','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2026-03-09 12:53:05','2026-03-09 12:53:05'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2026-03-09 12:53:05','2026-03-09 12:53:05');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `monitored_user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_monitors_user_id_monitored_user_id_unique` (`user_id`,`monitored_user_id`),
  KEY `user_monitors_monitored_user_id_foreign` (`monitored_user_id`),
  CONSTRAINT `user_monitors_monitored_user_id_foreign` FOREIGN KEY (`monitored_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_monitors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_monitors` WRITE;
/*!40000 ALTER TABLE `user_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_monitors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` uuid NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_fullname` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `birth_year` int(11) DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `sbtf_player_id` varchar(255) DEFAULT NULL,
  `sbtf_synced` tinyint(1) NOT NULL DEFAULT 0,
  `sbtf_synced_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 0,
  `is_active_player` tinyint(1) NOT NULL DEFAULT 1,
  `accepts_push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `locale` varchar(2) DEFAULT NULL,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  KEY `users_club_id_foreign` (`club_id`),
  KEY `users_player_match_index` (`last_name`,`first_name`,`birth_year`),
  KEY `users_sbtf_player_id_index` (`sbtf_player_id`),
  CONSTRAINT `users_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

