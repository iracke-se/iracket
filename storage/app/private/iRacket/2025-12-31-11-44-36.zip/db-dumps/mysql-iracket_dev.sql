/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` enum('top_sticky','bottom_sticky','top','bottom','within_page','random','popup') NOT NULL DEFAULT 'top',
  `views` bigint(20) unsigned NOT NULL DEFAULT 0,
  `clicks` bigint(20) unsigned NOT NULL DEFAULT 0,
  `locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`locations`)),
  `link` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','scheduled') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `banners` VALUES
(1,'Summer Tournament 2025','assets/images/landing/lastsect.png','top_sticky',1250,89,'[\"home\",\"matches\"]','https://example.com/summer-tournament','2025-11-14','2025-12-14','active','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(2,'Premium Membership','assets/images/landing/lefthero-deskt.png','bottom_sticky',3420,156,'[\"players\",\"bubbler\"]','https://example.com/premium','2025-10-25','2026-01-23','active','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(3,'New Racket Collection','assets/images/landing/pingpong.png','top',919,45,'[\"home\",\"clubs\"]','https://example.com/rackets','2025-11-24','2025-12-08','active','2025-11-24 08:36:01','2025-11-24 10:46:11'),
(4,'Winter League Registration','assets/images/landing/righthero-deskt.png','popup',2100,312,NULL,'https://example.com/winter-league','2025-11-29','2026-01-08','scheduled','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(5,'Club Sponsorship','assets/images/landing/iPhone12left.png','within_page',567,23,'[\"clubs\"]','https://example.com/sponsors','2025-11-19','2025-12-19','active','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(6,'Training Sessions','assets/images/landing/iPhone12right2.png','bottom',1973,80,'[\"matches\",\"players\"]','https://example.com/training',NULL,NULL,'active','2025-11-24 08:36:01','2025-12-12 12:34:09'),
(7,'Old Campaign','assets/images/landing/badge-appStore.png','random',4500,234,'[\"home\"]','https://example.com/old-campaign','2025-09-25','2025-10-25','inactive','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(8,'App Download','assets/images/landing/badge-PlayStore.png','bottom_sticky',780,92,'[\"settings\",\"profile\"]','https://example.com/app','2025-11-09','2026-01-08','active','2025-11-24 08:36:01','2025-11-24 08:36:01');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cache` VALUES
('iracket-cache-scraper_setting_schedule_export_day','N;',1767185075),
('iracket-cache-scraper_setting_schedule_export_enabled','N;',1767185075),
('iracket-cache-scraper_setting_schedule_export_time','N;',1767185075),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1767184992);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `club_monthly_rankings` VALUES
(1,4,2025,11,1,8303,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(2,3,2025,11,2,5191,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(3,8,2025,11,3,13840,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(4,6,2025,11,4,13902,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(5,7,2025,11,5,5775,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(6,5,2025,11,6,13008,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(7,1,2025,11,7,13684,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(8,2,2025,11,8,7237,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(9,6,2025,10,1,9260,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(10,7,2025,10,2,8346,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(11,5,2025,10,3,10996,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(12,4,2025,10,4,6357,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(13,3,2025,10,5,9332,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(14,8,2025,10,6,13644,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(15,1,2025,10,7,12906,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(16,2,2025,10,8,7088,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(17,6,2025,9,1,5656,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(18,7,2025,9,2,10186,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(19,3,2025,9,3,6807,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(20,4,2025,9,4,12721,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(21,1,2025,9,5,11798,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(22,2,2025,9,6,11695,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(23,8,2025,9,7,12938,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(24,5,2025,9,8,10216,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(25,5,2025,8,1,9124,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(26,8,2025,8,2,7678,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(27,3,2025,8,3,7224,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(28,4,2025,8,4,5786,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(29,1,2025,8,5,11345,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(30,7,2025,8,6,6861,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(31,2,2025,8,7,13211,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(32,6,2025,8,8,13853,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(33,4,2025,7,1,11624,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(34,6,2025,7,2,7340,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(35,3,2025,7,3,6150,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(36,7,2025,7,4,8538,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(37,8,2025,7,5,7717,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(38,2,2025,7,6,8624,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(39,1,2025,7,7,10091,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(40,5,2025,7,8,12261,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(41,2,2025,6,1,13304,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(42,6,2025,6,2,7400,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(43,5,2025,6,3,5158,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(44,7,2025,6,4,6304,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(45,3,2025,6,5,11587,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(46,4,2025,6,6,14460,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(47,8,2025,6,7,13610,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(48,1,2025,6,8,7470,'2025-11-22 17:08:01','2025-11-22 17:08:01');
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `club_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `from_club_id` bigint(20) unsigned DEFAULT NULL,
  `to_club_id` bigint(20) unsigned DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `born` date DEFAULT NULL,
  `from_club_name` varchar(255) DEFAULT NULL,
  `to_club_name` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `club_transitions_to_club_id_completion_date_index` (`to_club_id`,`completion_date`),
  KEY `club_transitions_from_club_id_completion_date_index` (`from_club_id`,`completion_date`),
  KEY `club_transitions_user_id_index` (`user_id`),
  CONSTRAINT `club_transitions_from_club_id_foreign` FOREIGN KEY (`from_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_to_club_id_foreign` FOREIGN KEY (`to_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_transitions` WRITE;
/*!40000 ALTER TABLE `club_transitions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `club_transitions` VALUES
(1,'Licens 2025-26',NULL,6,8,'Eriksson','Johan','1992-07-06','Västerås Padel Club','Helsingborg Racket & Fitness','2025-12-09',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(2,'Licens 2025-26',NULL,4,7,'Nilsson','Maria','1992-04-02','Uppsala Squash Center','Örebro Tennis Society','2025-12-27',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(3,'Licens 2025-26',NULL,5,3,'Gustafsson','Emma','1991-05-08','Linköping Racket Arena','Malmö Badminton Club','2025-10-04',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(4,'Licens 2025-26',NULL,7,1,'Svensson','Per','1997-02-11','Örebro Tennis Society','Stockholm Racket Club','2026-01-11',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(5,'Licens 2025-26',NULL,7,4,'Persson','Karin','1986-01-03','Örebro Tennis Society','Uppsala Squash Center','2025-12-17',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(6,'Licens 2025-26',NULL,7,6,'Eriksson','Johan','1998-03-14','Örebro Tennis Society','Västerås Padel Club','2025-12-18',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(7,'Licens 2025-26',174,7,5,'Hansson','Anna','1992-08-15','Örebro Tennis Society','Linköping Racket Arena','2025-12-03',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(8,'Licens 2025-26',NULL,8,6,'Persson','Karin','1991-12-22','Helsingborg Racket & Fitness','Västerås Padel Club','2025-10-13',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(9,'Licens 2025-26',NULL,3,1,'Karlsson','Lars','1981-09-17','Malmö Badminton Club','Stockholm Racket Club','2025-10-01',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(10,'Licens 2025-26',NULL,5,4,'Karlsson','Lars','1994-05-13','Linköping Racket Arena','Uppsala Squash Center','2026-01-13',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(11,'Licens 2025-26',134,5,7,'Andersson','Oscar','2003-10-20','Linköping Racket Arena','Örebro Tennis Society','2025-12-31',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(12,'Licens 2025-26',NULL,8,4,'Larsson','Eva','2007-01-27','Helsingborg Racket & Fitness','Uppsala Squash Center','2025-11-06',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(13,'Licens 2025-26',NULL,1,2,'Karlsson','Lars','1997-03-11','Stockholm Racket Club','Göteborg Tennis & Padel','2025-09-02',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(14,'Licens 2025-26',NULL,5,3,'Persson','Karin','1989-12-26','Linköping Racket Arena','Malmö Badminton Club','2025-09-11',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(15,'Licens 2025-26',NULL,4,1,'Svensson','Per','2004-07-16','Uppsala Squash Center','Stockholm Racket Club','2025-11-10',0,'2025-11-24 10:21:10','2025-11-24 10:21:10');
/*!40000 ALTER TABLE `club_transitions` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `clubs` VALUES
(1,'Stockholm Racket Club','stockholm-racket-club','Premier racket sports club in Stockholm with world-class facilities.',NULL,'Stockholm','https://stockholmracketclub.se','info@stockholmracketclub.se','+46 8 123 4567','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(2,'Göteborg Tennis & Padel','goteborg-tennis-padel','Leading tennis and padel club on the west coast.',NULL,'Gothenburg','https://gtpadel.se','kontakt@gtpadel.se','+46 31 234 5678','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(3,'Malmö Badminton Club','malmo-badminton-club','Southern Sweden\'s premier badminton facility.',NULL,'Malmö',NULL,'info@malmobadminton.se','+46 40 345 6789','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(4,'Uppsala Squash Center','uppsala-squash-center','Modern squash center with 8 courts.',NULL,'Uppsala',NULL,'bokning@uppsalasquash.se','+46 18 456 7890','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(5,'Linköping Racket Arena','linkoping-racket-arena','Multi-sport racket arena in Östergötland.',NULL,'Linköping',NULL,'info@lkpgarena.se','+46 13 567 8901','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(6,'Västerås Padel Club','vasteras-padel-club','Dedicated padel club with indoor and outdoor courts.',NULL,'Västerås',NULL,'hej@vasteraspadel.se','+46 21 678 9012','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(7,'Örebro Tennis Society','orebro-tennis-society','Historic tennis club founded in 1920.',NULL,'Örebro',NULL,'styrelsen@orebrotennis.se','+46 19 789 0123','2025-11-24 07:10:15','2025-11-24 07:10:15'),
(8,'Helsingborg Racket & Fitness','helsingborg-racket-fitness','Combined racket sports and fitness center.',NULL,'Helsingborg',NULL,'kontakt@hbgracket.se','+46 42 890 1234','2025-11-24 07:10:15','2025-11-24 07:10:15');
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `contacts` VALUES
(1,'Andrej Gjoshevski','info@weboook.co.uk','test hhhhhhhhhhh','replied','2025-11-23 07:16:34',2,'oooookookokokokokokokokok','2025-11-23 07:16:19','2025-11-23 07:16:34');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `jobs` VALUES
(10,'default','{\"uuid\":\"666b60b7-01ec-4d68-8050-a9224ce61688\",\"displayName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":1,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":14400,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"command\":\"O:30:\\\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\\\":4:{s:7:\\\"timeout\\\";i:14400;s:10:\\\"\\u0000*\\u0000command\\\";s:13:\\\"scraper:start\\\";s:13:\\\"\\u0000*\\u0000parameters\\\";a:1:{s:5:\\\"month\\\";s:7:\\\"2025-12\\\";}s:10:\\\"\\u0000*\\u0000options\\\";a:1:{s:7:\\\"--force\\\";b:1;}}\"},\"createdAt\":1767181476,\"delay\":null}',1,1767181476,1767181476,1767181476);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source` enum('player_added','scraped') NOT NULL DEFAULT 'player_added',
  `is_unofficial` tinyint(1) NOT NULL DEFAULT 0,
  `uuid` char(36) NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `player1_points_before` int(11) DEFAULT NULL,
  `player2_points_before` int(11) DEFAULT NULL,
  `player1_points_change` int(11) DEFAULT NULL,
  `player2_points_change` int(11) DEFAULT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `is_manual` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `replaced_by_match_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  KEY `matches_replaced_by_match_id_foreign` (`replaced_by_match_id`),
  KEY `match_lookup` (`player1_id`,`player2_id`,`played_at`,`deleted_at`),
  KEY `matches_is_unofficial_index` (`is_unofficial`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_replaced_by_match_id_foreign` FOREIGN KEY (`replaced_by_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matches` VALUES
(1,'player_added',1,'67830c76-bcf9-4311-a67f-f4ffeb92b481',165,169,'2025-09-23',3,0,NULL,NULL,NULL,NULL,165,'[\"Good backhand\",\"Great footwork\",\"Excellent net play\"]','[\"Consistent player\"]','Great match with lots of rallies.','confirmed',1,165,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(2,'player_added',1,'3fa89f22-9ef3-4c47-8cf3-73d28576bd1d',158,176,'2025-09-01',2,3,NULL,NULL,NULL,NULL,176,'[\"Strong forehand\",\"Fast serve\",\"Great footwork\"]','[]',NULL,'confirmed',1,158,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(3,'player_added',1,'efb3142e-eeef-4ae8-8b26-84b968a9cba1',137,127,'2025-10-10',2,0,NULL,NULL,NULL,NULL,137,'[\"Great footwork\"]','[]',NULL,'confirmed',1,137,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(4,'player_added',1,'dca2023f-7f97-4f70-94f9-b09138a0d845',152,130,'2025-09-06',0,2,NULL,NULL,NULL,NULL,130,'[\"Strong forehand\",\"Great footwork\",\"Excellent net play\"]','[\"Strong forehand\"]','Great match with lots of rallies.','confirmed',1,152,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(5,'player_added',1,'ffe5f234-c451-452c-b526-8800261df107',146,144,'2025-09-10',1,0,NULL,NULL,NULL,NULL,146,'[\"Good backhand\",\"Great footwork\",\"Excellent net play\"]','[\"Excellent net play\",\"Good sportsmanship\"]','Great match with lots of rallies.','confirmed',1,146,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(6,'player_added',1,'6d505bd1-f2e0-4181-998a-eb7d163224aa',167,176,'2025-10-08',3,1,NULL,NULL,NULL,NULL,167,'[]','[\"Great footwork\",\"Excellent net play\",\"Good sportsmanship\"]',NULL,'confirmed',1,167,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(7,'player_added',1,'5980974a-da28-4a82-8ebb-ad6eafbecca2',134,152,'2025-08-31',0,1,NULL,NULL,NULL,NULL,152,'[\"Fast serve\",\"Great footwork\",\"Good sportsmanship\"]','[]',NULL,'confirmed',1,134,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(8,'player_added',1,'b6344c1c-c190-48d7-9cab-56518130e248',152,140,'2025-09-18',3,0,NULL,NULL,NULL,NULL,152,'[]','[\"Fast serve\",\"Excellent net play\",\"Consistent player\"]',NULL,'confirmed',1,152,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(9,'player_added',1,'0ec7bf5c-0302-4aa0-98b1-87b79ac32ba9',154,155,'2025-09-26',3,2,NULL,NULL,NULL,NULL,154,'[\"Good sportsmanship\",\"Consistent player\"]','[\"Great footwork\",\"Excellent net play\",\"Good sportsmanship\"]','Great match with lots of rallies.','confirmed',1,154,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(10,'player_added',1,'ea610705-578f-45b5-a4ab-a2ed7becf605',140,2,'2025-09-12',3,2,NULL,NULL,NULL,NULL,140,'[\"Good backhand\",\"Fast serve\"]','[\"Good backhand\",\"Strong forehand\"]','Great match with lots of rallies.','confirmed',1,140,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(11,'player_added',1,'7e641832-669b-4ac6-a377-71429cc2adae',136,130,'2025-10-10',1,0,NULL,NULL,NULL,NULL,136,'[\"Good sportsmanship\"]','[\"Fast serve\",\"Excellent net play\",\"Consistent player\"]',NULL,'confirmed',1,136,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(12,'player_added',1,'b7a39781-8026-4d33-884b-93a904f5bdd0',152,150,'2025-10-20',1,2,NULL,NULL,NULL,NULL,150,'[]','[]',NULL,'confirmed',1,152,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(13,'player_added',1,'436c8862-49e6-4f0d-a000-33cd9d91a6c7',142,170,'2025-11-19',2,0,NULL,NULL,NULL,NULL,142,'[]','[\"Good backhand\",\"Fast serve\",\"Consistent player\"]',NULL,'confirmed',1,142,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(14,'player_added',1,'2d6b46c9-1bc2-4c24-bec4-9d45709ca0c5',132,141,'2025-10-07',2,1,NULL,NULL,NULL,NULL,132,'[\"Consistent player\"]','[]',NULL,'confirmed',1,132,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(15,'player_added',1,'a3069e49-4055-4284-8128-f326c68bcc17',130,175,'2025-09-04',2,0,NULL,NULL,NULL,NULL,130,'[\"Excellent net play\",\"Good sportsmanship\"]','[\"Strong forehand\",\"Great footwork\",\"Good sportsmanship\"]','Great match with lots of rallies.','confirmed',1,130,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(16,'player_added',1,'7a60d0a1-2555-450c-b899-58e2ad4599c0',138,131,'2025-11-12',3,0,NULL,NULL,NULL,NULL,138,'[\"Excellent net play\",\"Good sportsmanship\"]','[\"Great footwork\",\"Good sportsmanship\"]',NULL,'confirmed',1,138,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(17,'player_added',1,'44bc7079-14e5-4dc8-994a-63bcf43a13e5',133,164,'2025-10-20',2,3,NULL,NULL,NULL,NULL,164,'[\"Excellent net play\",\"Consistent player\"]','[\"Strong forehand\",\"Great footwork\"]',NULL,'confirmed',1,133,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(18,'player_added',1,'1097e2f0-eaf6-4b73-a557-d32cfe0d8c1e',130,135,'2025-09-08',3,2,NULL,NULL,NULL,NULL,130,'[\"Good backhand\",\"Great footwork\"]','[\"Great footwork\"]',NULL,'confirmed',1,130,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(19,'player_added',1,'1f202034-b884-405d-93af-c81ecf25b0d7',175,150,'2025-10-22',3,2,NULL,NULL,NULL,NULL,175,'[\"Good backhand\",\"Fast serve\",\"Great footwork\"]','[\"Great footwork\"]',NULL,'confirmed',1,175,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(20,'player_added',1,'99949a17-5095-498a-8940-8bea6a11a6f4',169,135,'2025-10-05',2,1,NULL,NULL,NULL,NULL,169,'[\"Good backhand\"]','[]',NULL,'confirmed',1,169,'2025-11-24 07:10:27','2025-12-31 10:36:03',NULL,NULL),
(21,'player_added',1,'d2396caa-6f95-4b72-b9ee-6fdaaecf9505',2,167,'2025-11-24',2,4,NULL,NULL,NULL,NULL,167,'[]','[\"Good backhand\",\"Great sportsmanship\",\"Super sensitive\",\"Fast footwork\"]',NULL,'pending',1,2,'2025-11-24 07:31:13','2025-12-31 10:36:03',NULL,NULL),
(22,'player_added',1,'8b9b9ed2-4dd8-46fe-bfb1-0f657b7a50c8',2,172,'2025-10-27',2,3,1244,1971,-20,20,172,'[]','[]',NULL,'confirmed',1,2,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(23,'player_added',1,'74d0909f-dc82-4411-a95d-ea485c79f6a8',127,134,'2025-10-26',3,0,1416,2166,20,-20,127,'[]','[]',NULL,'confirmed',1,127,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(24,'player_added',1,'69c1a539-4720-47fa-9d99-3ff6366bb803',160,173,'2025-10-31',0,3,1998,2496,-20,20,173,'[]','[]',NULL,'confirmed',1,160,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(25,'player_added',1,'47d0d6d9-b83f-4515-99dc-da9f33b5ae0d',177,160,'2025-11-03',3,2,1323,1998,20,-20,177,'[]','[]',NULL,'confirmed',1,177,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(26,'player_added',1,'93df96de-9dd6-4b9e-a589-1a6a39f7318f',138,161,'2025-11-04',0,2,2217,1982,-15,15,161,'[]','[]',NULL,'confirmed',1,138,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(27,'player_added',1,'363adab9-d7d6-4d48-8d3f-5255db9894d4',155,144,'2025-11-11',0,3,1661,2137,-20,20,144,'[]','[]',NULL,'confirmed',1,155,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(28,'player_added',1,'d4b72fcb-f9e2-4a2f-b907-18c8f53667fb',158,148,'2025-11-18',3,0,2495,1884,20,-20,158,'[]','[]',NULL,'confirmed',1,158,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(29,'player_added',1,'f09dc94e-e14a-4f2e-ae8b-46d92c7e7b74',176,158,'2025-11-15',0,3,1217,2495,-20,20,158,'[]','[]',NULL,'confirmed',1,176,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(30,'player_added',1,'5668e218-10f0-4cab-a83c-5f5e8469fd23',132,155,'2025-11-10',2,3,1685,1661,-10,10,155,'[]','[]',NULL,'confirmed',1,132,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(31,'player_added',1,'72e2b8b4-75e5-4231-a2a1-1aaa06beba2a',134,163,'2025-11-11',1,2,2166,1668,-20,20,163,'[]','[]',NULL,'confirmed',1,134,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(32,'player_added',1,'76843c92-55f9-4c99-8622-62cda328b03a',128,176,'2025-11-09',1,0,2097,1217,20,-20,128,'[]','[]',NULL,'confirmed',1,128,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(33,'player_added',1,'bca22cc1-4d48-4e92-9d04-36f34c72d2fb',136,157,'2025-11-08',1,0,1536,900,20,-20,136,'[]','[]',NULL,'confirmed',1,136,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(34,'player_added',1,'e2b913ae-5dc3-4aa0-b343-8c2903a1c3ee',158,152,'2025-10-26',0,3,2495,1392,-20,20,152,'[]','[]',NULL,'confirmed',1,158,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(35,'player_added',1,'51f3970b-dea9-4e9a-bdd3-3604291f37d1',165,129,'2025-10-30',2,3,2300,942,-20,20,129,'[]','[]',NULL,'confirmed',1,165,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(36,'player_added',1,'41f421f4-2292-44b9-9a3e-63fa7f4a3004',139,161,'2025-11-07',1,0,2078,1982,10,-10,139,'[]','[]',NULL,'confirmed',1,139,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(37,'player_added',1,'8c768c42-087f-4871-90e9-70f89f47b82d',130,157,'2025-11-14',3,1,1451,900,20,-20,130,'[]','[]',NULL,'confirmed',1,130,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(38,'player_added',1,'1032093c-fb1f-4fd9-ad70-0c451c79b703',144,168,'2025-11-06',2,3,2137,1632,-20,20,168,'[]','[]',NULL,'confirmed',1,144,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(39,'player_added',1,'fe42686f-4656-42af-8225-b8c7e92d9cee',139,175,'2025-11-23',2,0,2078,1435,20,-20,139,'[]','[]',NULL,'confirmed',1,139,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(40,'player_added',1,'8437e82b-4385-49e4-8bc0-0696a4c478dd',154,165,'2025-10-26',0,3,1815,2300,-20,20,165,'[]','[]',NULL,'confirmed',1,154,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL),
(41,'player_added',1,'aee63266-87a7-4406-aaf3-2cfce3f1269b',127,170,'2025-11-23',1,0,1416,982,20,-20,127,'[]','[]',NULL,'confirmed',1,127,'2025-11-24 10:21:10','2025-12-31 10:36:03',NULL,NULL);
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',2),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',3),
(10,'2025_11_22_173439_create_notifications_table',3),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',3),
(12,'2025_11_22_174607_add_age_to_users_table',4),
(13,'2025_11_22_180425_create_clubs_table',5),
(14,'2025_11_22_180426_create_matches_table',5),
(15,'2025_11_22_180426_create_monthly_rankings_table',5),
(16,'2025_11_22_180427_add_club_id_to_users_table',6),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',6),
(18,'2025_11_22_180433_create_permission_tables',6),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',7),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',8),
(21,'2025_11_22_183254_add_uuid_to_users_table',8),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',8),
(23,'2025_11_22_183655_make_terms_translatable',9),
(24,'2025_11_22_231254_create_scraper_tables',10),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',11),
(26,'2025_11_23_074902_add_icon_to_notifications_table',12),
(27,'2025_11_23_090000_create_contacts_table',13),
(28,'2025_11_23_084421_create_scraper_settings_table',14),
(29,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',15),
(30,'2025_11_23_103307_add_sbtf_player_fields_to_users_table',16),
(31,'2025_11_24_091012_create_banners_table',17),
(32,'2025_11_24_094538_create_user_monitors_table',18),
(33,'2025_11_24_102243_add_connection_fields_to_users_table',19),
(34,'2025_11_24_105000_add_points_tracking_to_matches_table',20),
(35,'2025_11_24_111359_create_club_transitions_table',21),
(36,'2025_12_23_132006_add_match_tracking_fields',22),
(37,'2025_12_23_133213_make_matches_created_by_nullable',22),
(38,'2025_12_23_160000_add_step_tracking_to_scraper_runs_table',22);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `monthly_rankings` VALUES
(1,2,2025,11,42,1244,58,'2025-11-22 17:08:01','2025-11-24 10:21:10'),
(3,2,2025,10,1,1977,87,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(6,2,2025,9,2,1236,81,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(8,2,2025,8,2,1388,-26,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(9,2,2025,7,1,1178,85,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(12,2,2025,6,2,1672,42,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(563,128,2025,11,14,2097,146,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(564,128,2025,1,50,2327,41,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(565,128,2025,2,24,756,-19,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(566,128,2025,3,40,937,201,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(567,128,2025,4,6,1564,-117,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(568,128,2025,5,11,1728,-7,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(569,128,2025,6,38,2213,-118,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(570,128,2025,7,31,1482,131,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(571,128,2025,8,15,2282,217,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(572,128,2025,9,47,1538,235,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(573,128,2025,10,50,1198,45,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(574,129,2025,11,49,942,28,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(575,129,2025,1,17,998,240,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(576,129,2025,2,27,1500,17,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(577,129,2025,3,10,2264,119,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(578,129,2025,4,21,2385,226,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(579,129,2025,5,7,1357,167,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(580,129,2025,6,39,1033,142,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(581,129,2025,7,17,736,-6,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(582,129,2025,8,21,1911,189,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(583,129,2025,9,1,2019,51,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(584,129,2025,10,11,2196,26,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(585,130,2025,11,36,1451,-30,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(586,130,2025,1,28,1126,-35,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(587,130,2025,2,1,1369,49,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(588,130,2025,3,22,771,-16,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(589,130,2025,4,47,2237,-15,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(590,130,2025,5,30,813,110,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(591,130,2025,6,26,711,182,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(592,130,2025,7,22,1890,63,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(593,130,2025,8,37,1001,195,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(594,130,2025,9,2,1085,197,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(595,130,2025,10,40,1165,44,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(596,131,2025,11,5,2403,-70,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(597,131,2025,1,23,2145,137,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(598,131,2025,2,38,1967,31,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(599,131,2025,3,17,2174,206,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(600,131,2025,4,18,946,140,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(601,131,2025,5,37,1646,-133,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(602,131,2025,6,38,836,-128,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(603,131,2025,7,16,1948,123,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(604,131,2025,8,16,1095,41,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(605,131,2025,9,44,1658,29,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(606,131,2025,10,19,2288,174,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(607,132,2025,11,29,1685,167,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(608,132,2025,1,46,1455,49,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(609,132,2025,2,37,1160,-134,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(610,132,2025,3,47,893,-148,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(611,132,2025,4,36,1387,224,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(612,132,2025,5,35,1673,248,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(613,132,2025,6,4,2268,-136,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(614,132,2025,7,17,1039,11,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(615,132,2025,8,21,2108,-27,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(616,132,2025,9,47,1698,187,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(617,132,2025,10,31,1469,63,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(618,133,2025,11,27,1753,191,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(619,133,2025,1,40,777,153,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(620,133,2025,2,24,1199,-139,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(621,133,2025,3,31,1515,173,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(622,133,2025,4,26,920,151,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(623,133,2025,5,3,973,195,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(624,133,2025,6,45,1455,156,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(625,133,2025,7,24,1305,-150,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(626,133,2025,8,42,1465,-147,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(627,133,2025,9,15,2381,158,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(628,133,2025,10,34,1063,-125,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(629,134,2025,11,11,2166,-80,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(630,134,2025,1,12,1338,-96,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(631,134,2025,2,18,1117,129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(632,134,2025,3,19,1055,-81,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(633,134,2025,4,10,1486,103,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(634,134,2025,5,38,2085,228,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(635,134,2025,6,28,838,193,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(636,134,2025,7,18,2112,160,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(637,134,2025,8,18,747,107,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(638,134,2025,9,4,1711,98,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(639,134,2025,10,8,2003,191,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(640,135,2025,11,34,1491,-71,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(641,135,2025,1,4,793,30,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(642,135,2025,2,6,1574,-20,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(643,135,2025,3,8,2034,77,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(644,135,2025,4,14,2068,52,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(645,135,2025,5,47,1638,-28,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(646,135,2025,6,43,2017,110,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(647,135,2025,7,50,775,196,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(648,135,2025,8,23,1195,-144,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(649,135,2025,9,45,2223,177,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(650,135,2025,10,32,1763,160,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(651,136,2025,11,33,1536,52,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(652,136,2025,1,46,2246,151,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(653,136,2025,2,12,1030,2,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(654,136,2025,3,26,1496,40,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(655,136,2025,4,21,1239,134,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(656,136,2025,5,32,2081,203,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(657,136,2025,6,14,1282,54,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(658,136,2025,7,24,998,99,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(659,136,2025,8,26,1719,99,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(660,136,2025,9,21,1985,63,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(661,136,2025,10,10,2342,-85,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(662,137,2025,11,52,810,25,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(663,137,2025,1,3,2101,223,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(664,137,2025,2,19,2115,-41,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(665,137,2025,3,31,2219,122,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(666,137,2025,4,42,1920,36,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(667,137,2025,5,12,1515,115,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(668,137,2025,6,12,1940,-13,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(669,137,2025,7,25,1884,185,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(670,137,2025,8,16,789,-118,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(671,137,2025,9,5,1237,89,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(672,137,2025,10,8,1112,200,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(673,138,2025,11,10,2217,-85,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(674,138,2025,1,2,2092,81,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(675,138,2025,2,15,1940,188,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(676,138,2025,3,35,1972,-117,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(677,138,2025,4,14,1565,-20,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(678,138,2025,5,36,949,120,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(679,138,2025,6,50,1605,-82,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(680,138,2025,7,28,2183,240,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(681,138,2025,8,2,982,180,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(682,138,2025,9,4,2270,-147,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(683,138,2025,10,8,1704,-112,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(684,139,2025,11,15,2078,-70,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(685,139,2025,1,23,1888,0,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(686,139,2025,2,15,2049,164,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(687,139,2025,3,15,2012,182,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(688,139,2025,4,29,1843,170,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(689,139,2025,5,31,2310,236,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(690,139,2025,6,22,1251,32,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(691,139,2025,7,12,1953,66,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(692,139,2025,8,44,997,71,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(693,139,2025,9,35,1781,-98,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(694,139,2025,10,10,1977,7,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(695,140,2025,11,21,1971,-66,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(696,140,2025,1,21,752,116,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(697,140,2025,2,23,1280,128,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(698,140,2025,3,11,707,-139,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(699,140,2025,4,39,1792,75,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(700,140,2025,5,2,996,26,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(701,140,2025,6,49,1791,201,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(702,140,2025,7,27,998,178,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(703,140,2025,8,24,1735,59,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(704,140,2025,9,41,2027,175,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(705,140,2025,10,8,2357,31,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(706,141,2025,11,35,1465,176,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(707,141,2025,1,14,1537,174,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(708,141,2025,2,24,966,131,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(709,141,2025,3,32,1064,-124,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(710,141,2025,4,42,2352,-74,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(711,141,2025,5,31,1325,28,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(712,141,2025,6,46,1147,29,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(713,141,2025,7,6,1362,118,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(714,141,2025,8,48,862,163,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(715,141,2025,9,20,1813,-122,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(716,141,2025,10,11,2378,-85,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(717,142,2025,11,44,1151,122,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(718,142,2025,1,19,2219,219,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(719,142,2025,2,10,865,143,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(720,142,2025,3,33,2294,150,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(721,142,2025,4,26,1422,173,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(722,142,2025,5,6,1328,133,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(723,142,2025,6,26,1602,158,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(724,142,2025,7,21,1027,248,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(725,142,2025,8,19,1675,110,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(726,142,2025,9,3,1518,100,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(727,142,2025,10,42,1978,186,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(728,143,2025,11,41,1298,-50,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(729,143,2025,1,9,1660,-126,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(730,143,2025,2,29,2375,-36,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(731,143,2025,3,25,983,237,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(732,143,2025,4,43,1629,198,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(733,143,2025,5,45,1159,5,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(734,143,2025,6,29,1122,126,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(735,143,2025,7,44,1404,-50,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(736,143,2025,8,50,1576,-98,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(737,143,2025,9,19,2018,-144,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(738,143,2025,10,14,1634,208,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(739,144,2025,11,12,2137,43,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(740,144,2025,1,19,1970,-39,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(741,144,2025,2,42,1859,-39,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(742,144,2025,3,1,751,65,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(743,144,2025,4,27,1877,67,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(744,144,2025,5,22,971,41,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(745,144,2025,6,23,2139,104,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(746,144,2025,7,29,1409,222,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(747,144,2025,8,32,1516,134,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(748,144,2025,9,48,1520,-31,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(749,144,2025,10,37,1627,-124,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(750,145,2025,11,7,2330,176,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(751,145,2025,1,29,999,244,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(752,145,2025,2,24,1156,25,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(753,145,2025,3,7,1749,61,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(754,145,2025,4,38,1088,-55,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(755,145,2025,5,14,1954,233,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(756,145,2025,6,24,1529,-142,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(757,145,2025,7,46,1923,162,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(758,145,2025,8,27,988,-138,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(759,145,2025,9,50,2144,84,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(760,145,2025,10,43,1234,207,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(761,146,2025,11,9,2276,-45,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(762,146,2025,1,21,1298,239,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(763,146,2025,2,13,1912,151,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(764,146,2025,3,17,1147,223,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(765,146,2025,4,30,2184,200,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(766,146,2025,5,36,946,-56,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(767,146,2025,6,24,1936,-60,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(768,146,2025,7,25,1188,-147,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(769,146,2025,8,6,1903,-141,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(770,146,2025,9,18,1825,200,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(771,146,2025,10,42,2200,227,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(772,147,2025,11,45,1143,6,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(773,147,2025,1,4,1585,19,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(774,147,2025,2,18,943,172,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(775,147,2025,3,14,2116,-145,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(776,147,2025,4,16,1968,118,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(777,147,2025,5,25,1725,82,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(778,147,2025,6,10,1016,187,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(779,147,2025,7,30,2217,-139,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(780,147,2025,8,3,1404,-54,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(781,147,2025,9,16,2281,119,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(782,147,2025,10,24,1746,241,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(783,148,2025,11,22,1884,-65,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(784,148,2025,1,27,2348,163,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(785,148,2025,2,27,1185,-86,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(786,148,2025,3,15,2398,-94,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(787,148,2025,4,29,1637,-7,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(788,148,2025,5,6,752,26,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(789,148,2025,6,23,2206,154,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(790,148,2025,7,24,1615,193,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(791,148,2025,8,49,924,-80,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(792,148,2025,9,2,747,-36,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(793,148,2025,10,1,1656,-42,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(794,149,2025,11,17,2006,-7,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(795,149,2025,1,23,875,-67,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(796,149,2025,2,18,1310,191,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(797,149,2025,3,43,1340,43,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(798,149,2025,4,42,1656,228,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(799,149,2025,5,12,1953,131,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(800,149,2025,6,45,1291,-54,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(801,149,2025,7,45,1933,100,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(802,149,2025,8,9,1533,216,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(803,149,2025,9,49,1998,-124,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(804,149,2025,10,11,1647,111,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(805,150,2025,11,4,2449,-96,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(806,150,2025,1,20,802,243,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(807,150,2025,2,18,848,-30,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(808,150,2025,3,41,1814,180,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(809,150,2025,4,20,1906,-139,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(810,150,2025,5,22,1216,161,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(811,150,2025,6,43,2041,9,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(812,150,2025,7,33,1504,-54,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(813,150,2025,8,50,1467,131,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(814,150,2025,9,38,1908,242,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(815,150,2025,10,15,842,136,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(816,151,2025,11,26,1757,116,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(817,151,2025,1,19,1986,-87,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(818,151,2025,2,38,1000,13,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(819,151,2025,3,50,2141,127,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(820,151,2025,4,46,1460,149,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(821,151,2025,5,45,1702,88,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(822,151,2025,6,45,1762,-23,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(823,151,2025,7,18,1672,179,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(824,151,2025,8,7,1974,-76,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(825,151,2025,9,4,997,-104,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(826,151,2025,10,50,900,62,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(827,152,2025,11,39,1392,147,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(828,152,2025,1,49,2216,-111,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(829,152,2025,2,37,1152,21,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(830,152,2025,3,10,1316,-124,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(831,152,2025,4,17,2277,84,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(832,152,2025,5,38,1067,44,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(833,152,2025,6,3,1877,67,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(834,152,2025,7,2,1980,0,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(835,152,2025,8,36,1065,-108,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(836,152,2025,9,15,1046,7,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(837,152,2025,10,44,1179,28,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(838,153,2025,11,6,2372,-5,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(839,153,2025,1,25,1378,-32,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(840,153,2025,2,28,2131,1,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(841,153,2025,3,33,1410,173,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(842,153,2025,4,9,883,-123,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(843,153,2025,5,27,1566,26,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(844,153,2025,6,12,1511,53,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(845,153,2025,7,6,1888,-145,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(846,153,2025,8,7,902,-89,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(847,153,2025,9,20,2292,103,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(848,153,2025,10,9,778,29,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(849,154,2025,11,24,1815,175,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(850,154,2025,1,50,1809,-121,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(851,154,2025,2,22,1234,39,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(852,154,2025,3,35,1350,-130,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(853,154,2025,4,13,1721,211,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(854,154,2025,5,4,1486,67,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(855,154,2025,6,19,1264,209,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(856,154,2025,7,8,1736,-28,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(857,154,2025,8,33,1607,113,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(858,154,2025,9,14,944,202,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(859,154,2025,10,38,1544,103,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(860,155,2025,11,31,1661,60,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(861,155,2025,1,16,1657,-59,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(862,155,2025,2,38,1722,165,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(863,155,2025,3,34,1343,194,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(864,155,2025,4,31,1260,-76,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(865,155,2025,5,29,787,63,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(866,155,2025,6,18,2249,173,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(867,155,2025,7,37,810,200,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(868,155,2025,8,25,2233,199,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(869,155,2025,9,12,2387,172,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(870,155,2025,10,40,1817,-73,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(871,156,2025,11,25,1779,-66,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(872,156,2025,1,26,1009,-11,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(873,156,2025,2,24,875,247,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(874,156,2025,3,33,1634,180,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(875,156,2025,4,40,2195,-33,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(876,156,2025,5,33,1690,-44,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(877,156,2025,6,46,819,-20,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(878,156,2025,7,28,1593,-1,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(879,156,2025,8,43,2215,97,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(880,156,2025,9,13,2133,38,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(881,156,2025,10,46,1313,43,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(882,157,2025,11,50,900,70,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(883,157,2025,1,35,1116,223,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(884,157,2025,2,39,992,176,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(885,157,2025,3,47,2379,-60,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(886,157,2025,4,38,1160,-49,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(887,157,2025,5,48,1374,167,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(888,157,2025,6,2,1452,-106,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(889,157,2025,7,40,1599,165,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(890,157,2025,8,44,987,-29,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(891,157,2025,9,20,2384,230,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(892,157,2025,10,30,1495,112,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(893,158,2025,11,2,2495,-5,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(894,158,2025,1,2,1476,-34,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(895,158,2025,2,31,2034,-139,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(896,158,2025,3,15,1215,-6,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(897,158,2025,4,44,816,56,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(898,158,2025,5,24,850,-73,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(899,158,2025,6,46,2381,148,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(900,158,2025,7,38,2377,40,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(901,158,2025,8,1,1960,4,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(902,158,2025,9,22,2255,-104,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(903,158,2025,10,2,1012,-37,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(904,159,2025,11,13,2135,-87,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(905,159,2025,1,12,2389,171,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(906,159,2025,2,20,960,-125,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(907,159,2025,3,19,1630,-32,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(908,159,2025,4,6,1078,71,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(909,159,2025,5,41,2076,32,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(910,159,2025,6,28,2269,106,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(911,159,2025,7,43,1982,248,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(912,159,2025,8,1,2117,-135,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(913,159,2025,9,4,1417,-78,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(914,159,2025,10,50,1825,182,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(915,160,2025,11,18,1998,135,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(916,160,2025,1,14,989,-64,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(917,160,2025,2,3,1539,73,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(918,160,2025,3,41,1630,-129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(919,160,2025,4,41,2247,-48,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(920,160,2025,5,29,2099,-33,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(921,160,2025,6,47,2111,20,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(922,160,2025,7,33,1127,151,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(923,160,2025,8,43,1077,180,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(924,160,2025,9,9,964,22,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(925,160,2025,10,41,1008,91,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(926,161,2025,11,19,1982,88,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(927,161,2025,1,47,1893,105,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(928,161,2025,2,44,1089,-67,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(929,161,2025,3,16,810,233,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(930,161,2025,4,4,926,34,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(931,161,2025,5,34,1528,133,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(932,161,2025,6,34,1844,103,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(933,161,2025,7,17,2172,-9,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(934,161,2025,8,33,1464,216,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(935,161,2025,9,29,1582,-81,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(936,161,2025,10,2,1448,-95,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(937,162,2025,11,3,2461,13,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(938,162,2025,1,42,2245,118,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(939,162,2025,2,42,1047,230,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(940,162,2025,3,23,1342,-96,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(941,162,2025,4,11,1128,101,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(942,162,2025,5,1,1889,129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(943,162,2025,6,8,1671,246,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(944,162,2025,7,36,1891,-91,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(945,162,2025,8,50,1573,238,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(946,162,2025,9,10,2133,204,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(947,162,2025,10,13,1211,11,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(948,163,2025,11,30,1668,18,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(949,163,2025,1,45,1936,187,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(950,163,2025,2,7,1075,236,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(951,163,2025,3,44,2193,141,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(952,163,2025,4,8,1457,-21,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(953,163,2025,5,9,987,-10,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(954,163,2025,6,49,1438,-30,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(955,163,2025,7,42,901,184,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(956,163,2025,8,27,1714,67,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(957,163,2025,9,22,936,125,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(958,163,2025,10,46,1290,122,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(959,164,2025,11,47,987,101,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(960,164,2025,1,9,1206,177,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(961,164,2025,2,30,1215,-89,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(962,164,2025,3,1,2285,-94,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(963,164,2025,4,31,1309,-109,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(964,164,2025,5,25,1062,-114,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(965,164,2025,6,23,2108,-96,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(966,164,2025,7,17,1845,-71,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(967,164,2025,8,28,766,38,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(968,164,2025,9,12,2046,190,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(969,164,2025,10,15,797,126,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(970,165,2025,11,8,2300,184,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(971,165,2025,1,37,1253,191,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(972,165,2025,2,34,1847,61,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(973,165,2025,3,30,1499,126,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(974,165,2025,4,17,2031,23,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(975,165,2025,5,11,2208,136,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(976,165,2025,6,21,1109,-134,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(977,165,2025,7,47,768,218,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(978,165,2025,8,41,1455,129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(979,165,2025,9,31,2232,226,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(980,165,2025,10,34,1882,-134,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(981,166,2025,11,46,1142,76,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(982,166,2025,1,33,922,173,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(983,166,2025,2,46,1307,134,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(984,166,2025,3,37,905,38,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(985,166,2025,4,42,1038,-127,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(986,166,2025,5,47,1974,243,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(987,166,2025,6,40,1211,19,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(988,166,2025,7,30,1028,-129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(989,166,2025,8,11,1112,123,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(990,166,2025,9,27,1540,-51,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(991,166,2025,10,49,1293,76,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(992,167,2025,11,51,896,-54,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(993,167,2025,1,47,950,116,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(994,167,2025,2,10,1856,135,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(995,167,2025,3,3,2264,89,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(996,167,2025,4,42,2035,72,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(997,167,2025,5,13,1602,5,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(998,167,2025,6,38,2340,180,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(999,167,2025,7,42,1454,62,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1000,167,2025,8,44,2357,200,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1001,167,2025,9,41,760,203,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1002,167,2025,10,10,1815,-142,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1003,168,2025,11,32,1632,-32,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1004,168,2025,1,6,1345,100,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1005,168,2025,2,33,2078,-97,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1006,168,2025,3,18,952,11,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1007,168,2025,4,32,2328,195,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1008,168,2025,5,40,1285,229,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1009,168,2025,6,38,982,101,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1010,168,2025,7,21,1892,141,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1011,168,2025,8,34,1692,106,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1012,168,2025,9,31,2397,95,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1013,168,2025,10,37,2148,-52,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1014,169,2025,11,28,1708,29,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1015,169,2025,1,37,1047,95,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1016,169,2025,2,19,1112,191,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1017,169,2025,3,18,1413,241,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1018,169,2025,4,11,1955,37,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1019,169,2025,5,42,2032,204,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1020,169,2025,6,2,1417,6,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1021,169,2025,7,40,896,136,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1022,169,2025,8,2,2349,-110,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1023,169,2025,9,7,1933,-93,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1024,169,2025,10,3,2138,220,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1025,170,2025,11,48,982,89,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1026,170,2025,1,21,2291,-36,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1027,170,2025,2,32,1740,-124,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1028,170,2025,3,29,2286,224,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1029,170,2025,4,14,738,175,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1030,170,2025,5,18,1102,217,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1031,170,2025,6,14,2019,-133,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1032,170,2025,7,30,890,-45,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1033,170,2025,8,29,832,57,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1034,170,2025,9,17,1269,-51,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1035,170,2025,10,42,1813,-57,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1036,171,2025,11,23,1875,98,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1037,171,2025,1,2,1213,175,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1038,171,2025,2,2,2212,139,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1039,171,2025,3,35,1366,-99,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1040,171,2025,4,39,2188,250,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1041,171,2025,5,28,1922,-57,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1042,171,2025,6,34,840,172,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1043,171,2025,7,41,1546,-34,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1044,171,2025,8,31,790,22,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1045,171,2025,9,31,1973,167,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1046,171,2025,10,26,808,173,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1047,172,2025,11,20,1971,-56,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1048,172,2025,1,41,1038,235,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1049,172,2025,2,19,2228,114,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1050,172,2025,3,44,722,-20,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1051,172,2025,4,12,905,66,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1052,172,2025,5,18,1498,116,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1053,172,2025,6,1,1829,207,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1054,172,2025,7,27,757,-68,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1055,172,2025,8,28,2023,-143,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1056,172,2025,9,18,1824,15,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1057,172,2025,10,35,2007,218,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1058,173,2025,11,1,2496,79,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1059,173,2025,1,13,2388,-84,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1060,173,2025,2,11,1019,154,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1061,173,2025,3,2,1477,-30,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1062,173,2025,4,7,1296,109,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1063,173,2025,5,46,1266,-119,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1064,173,2025,6,18,1035,211,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1065,173,2025,7,50,1315,-24,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1066,173,2025,8,12,1384,-11,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1067,173,2025,9,6,1282,-89,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1068,173,2025,10,31,2299,-55,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1069,174,2025,11,16,2054,-29,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1070,174,2025,1,37,2113,171,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1071,174,2025,2,18,1719,189,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1072,174,2025,3,39,1252,-11,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1073,174,2025,4,48,1157,128,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1074,174,2025,5,31,1485,66,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1075,174,2025,6,13,850,-21,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1076,174,2025,7,41,1990,90,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1077,174,2025,8,44,771,219,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1078,174,2025,9,33,1817,51,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1079,174,2025,10,34,2374,-93,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1080,175,2025,11,37,1435,-34,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1081,175,2025,1,46,1232,-61,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1082,175,2025,2,31,1310,208,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1083,175,2025,3,35,2215,53,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1084,175,2025,4,2,2038,63,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1085,175,2025,5,11,709,184,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1086,175,2025,6,35,1948,36,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1087,175,2025,7,30,2104,82,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1088,175,2025,8,12,2281,148,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1089,175,2025,9,48,883,-4,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1090,175,2025,10,21,723,-122,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1091,176,2025,11,43,1217,-78,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1092,176,2025,1,7,1941,-37,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1093,176,2025,2,2,1510,56,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1094,176,2025,3,25,2118,33,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1095,176,2025,4,12,1183,182,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1096,176,2025,5,13,2033,-107,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1097,176,2025,6,45,1921,-124,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1098,176,2025,7,21,1024,202,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1099,176,2025,8,21,1296,125,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1100,176,2025,9,7,976,129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1101,176,2025,10,45,2095,224,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1102,177,2025,11,40,1323,-48,'2025-11-24 07:10:25','2025-11-24 10:21:10'),
(1103,177,2025,1,50,1846,189,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1104,177,2025,2,34,1039,220,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1105,177,2025,3,30,1637,-138,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1106,177,2025,4,34,1401,116,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1107,177,2025,5,47,1753,35,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1108,177,2025,6,50,1157,129,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1109,177,2025,7,16,1705,-33,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1110,177,2025,8,47,1517,-83,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1111,177,2025,9,11,921,-57,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1112,177,2025,10,6,1304,76,'2025-11-24 07:10:25','2025-11-24 07:10:25'),
(1113,127,2025,11,38,1416,0,'2025-11-24 10:21:10','2025-11-24 10:21:10');
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `notifications` VALUES
(8,2,'match_result','Match Result','You won against Erik Lindqvist! Your ranking increased by 15 points.','\"{\\\"match_id\\\":1,\\\"opponent\\\":\\\"Erik Lindqvist\\\",\\\"points\\\":15}\"',NULL,'2025-11-24 08:04:43','2025-11-22 16:39:46','2025-11-24 08:04:43'),
(9,2,'ranking_update','Ranking Update','Your monthly ranking has been updated. You are now ranked #42 in your region.','\"{\\\"rank\\\":42,\\\"region\\\":\\\"Stockholm\\\"}\"',NULL,'2025-11-23 06:58:33','2025-11-22 16:39:46','2025-11-23 06:58:33'),
(10,2,'achievement','Achievement Unlocked!','Congratulations! You\'ve won 10 matches this month. Keep it up!','\"{\\\"achievement\\\":\\\"win_streak_10\\\"}\"',NULL,'2025-11-22 16:58:29','2025-11-22 16:39:46','2025-11-22 16:58:29'),
(11,2,'match_result','Match Result','You lost against Anna Svensson. Your ranking decreased by 8 points.','\"{\\\"match_id\\\":2,\\\"opponent\\\":\\\"Anna Svensson\\\",\\\"points\\\":-8}\"',NULL,'2025-11-22 15:39:46','2025-11-22 16:39:46','2025-11-22 16:39:46'),
(12,2,'system','Welcome to iRacket!','Welcome to iRacket! Start by recording your first match to see your ranking.',NULL,NULL,'2025-11-20 16:39:46','2025-11-22 16:39:46','2025-11-22 16:39:46'),
(13,2,'bubbler','Bubbler Update','You made it to the top 3 in your class last month! Check out the Bubbler rankings.','\"{\\\"position\\\":2,\\\"class\\\":\\\"Class 4\\\"}\"',NULL,'2025-11-23 06:58:33','2025-11-22 16:39:46','2025-11-23 06:58:33'),
(14,2,'follow','New Follower','Marcus Johansson started following you.','\"{\\\"follower_id\\\":5,\\\"follower_name\\\":\\\"Marcus Johansson\\\"}\"',NULL,'2025-11-22 04:39:46','2025-11-22 16:39:46','2025-11-22 16:39:46'),
(15,167,'match_created','New Match Added','Andrej Gjoshevski added a match with you (2-4). Please confirm or reject it.','{\"match_id\":21,\"url\":\"https:\\/\\/iracket.ddev.site\\/matches\\/d2396caa-6f95-4b72-b9ee-6fdaaecf9505\"}','assets/images/icon.png',NULL,'2025-11-24 07:31:13','2025-11-24 07:31:13');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `password_reset_tokens` VALUES
('info@weboook.co.uk','$2y$12$TiwjkawXM3WHokKG4y25P.ODxbWdgf/q0WTUMm3oqSkVA4/HOAIQG','2025-12-12 12:44:46');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `roles` VALUES
(1,'Admin','web','2025-11-22 17:06:07','2025-11-22 17:06:07'),
(2,'Manager','web','2025-11-22 17:06:07','2025-11-22 17:06:07');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `scraper_logs` VALUES
(1,1,'info','Starting: Creating Database Backup','[]','2025-12-31 07:54:33','2025-12-31 07:54:33'),
(2,1,'error','Failed: Creating Database Backup - Failed to create backup: sh: line 1: ddev: command not found\n','[]','2025-12-31 07:54:33','2025-12-31 07:54:33'),
(3,2,'info','Starting: Creating Database Backup','[]','2025-12-31 07:58:25','2025-12-31 07:58:25'),
(4,2,'error','Failed: Creating Database Backup - Failed to create backup: sh: line 1: ddev: command not found\n','[]','2025-12-31 07:58:25','2025-12-31 07:58:25'),
(5,3,'info','Starting: Creating Database Backup','[]','2025-12-31 10:36:01','2025-12-31 10:36:01'),
(6,3,'info','Completed: Creating Database Backup (in 0.48s)','[]','2025-12-31 10:36:01','2025-12-31 10:36:01'),
(7,3,'info','Starting: Scraping Players','[]','2025-12-31 10:36:01','2025-12-31 10:36:01'),
(8,3,'info','Completed: Scraping Players (in 1.01s)','[]','2025-12-31 10:36:02','2025-12-31 10:36:02'),
(9,3,'info','Starting: Syncing Players → Users & Clubs','[]','2025-12-31 10:36:02','2025-12-31 10:36:02'),
(10,3,'info','Starting player sync: 0 players to process','[]','2025-12-31 10:36:02','2025-12-31 10:36:02'),
(11,3,'info','Player sync completed: 0 created, 0 updated, 0 errors','[]','2025-12-31 10:36:02','2025-12-31 10:36:02'),
(12,3,'info','Completed: Syncing Players → Users & Clubs (in 0.02s)','[]','2025-12-31 10:36:02','2025-12-31 10:36:02'),
(13,3,'info','Starting: Scraping Series Matches','[]','2025-12-31 10:36:02','2025-12-31 10:36:02'),
(14,3,'info','Completed: Scraping Series Matches (in 1.00s)','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(15,3,'info','Starting: Syncing Matches','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(16,3,'info','Starting match sync: 0 matches to process','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(17,3,'info','Marking unofficial matches...','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(18,3,'info','Match sync completed: 0 created, 0 comments migrated, 41 marked unofficial','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(19,3,'info','Completed: Syncing Matches (in 0.01s)','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(20,3,'info','Starting: Scraping Rankings (Male) - 3 Parallel Processes','[]','2025-12-31 10:36:03','2025-12-31 10:36:03'),
(21,3,'info','Completed: Scraping Rankings (Male) - 3 Parallel Processes (in 7.00s)','[]','2025-12-31 10:36:10','2025-12-31 10:36:10'),
(22,3,'info','Starting: Scraping Rankings (Female) - 3 Parallel Processes','[]','2025-12-31 10:36:10','2025-12-31 10:36:10'),
(23,3,'info','Completed: Scraping Rankings (Female) - 3 Parallel Processes (in 7.00s)','[]','2025-12-31 10:36:17','2025-12-31 10:36:17'),
(24,3,'info','Starting: Syncing All Rankings','[]','2025-12-31 10:36:17','2025-12-31 10:36:17'),
(25,3,'info','Starting rankings sync: 0 rankings to process','[]','2025-12-31 10:36:17','2025-12-31 10:36:17'),
(26,3,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2025-12-31 10:36:17','2025-12-31 10:36:17'),
(27,3,'info','Completed: Syncing All Rankings (in 0.01s)','[]','2025-12-31 10:36:17','2025-12-31 10:36:17'),
(28,3,'info','Starting: Scraping Series Standings','[]','2025-12-31 10:36:17','2025-12-31 10:36:17'),
(29,3,'info','Completed: Scraping Series Standings (in 1.00s)','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(30,3,'info','Starting: Calculating Bubbler Points','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(31,3,'info','Starting Bubbler points calculation for 2025-12','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(32,3,'info','Found 0 matches to process','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(33,3,'info','Bubbler calculation completed: 0 matches processed, 0 rankings updated','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(34,3,'info','Completed: Calculating Bubbler Points (in 0.00s)','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(35,3,'info','Starting: Aggregating Club Rankings','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(36,3,'info','Starting club rankings aggregation for 2025-12','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(37,3,'info','Found 0 clubs with ranked players','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(38,3,'info','Club rankings aggregation completed: 0 clubs processed, 0 created, 0 updated','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(39,3,'info','Completed: Aggregating Club Rankings (in 0.00s)','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(40,3,'info','Starting: Verifying Data Integrity','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(41,3,'info','Completed: Verifying Data Integrity (in 0.00s)','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(42,3,'info','Full scrape completed successfully','[]','2025-12-31 10:36:18','2025-12-31 10:36:18'),
(43,4,'info','Starting: Creating Database Backup','[]','2025-12-31 10:44:36','2025-12-31 10:44:36');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `current_step` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `steps_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`steps_data`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `scraper_runs` VALUES
(1,'full_scrape','Step 1/12: Creating Database Backup','failed','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.021065950393676758,\"success\":false,\"error\":\"Failed to create backup: sh: line 1: ddev: command not found\\n\",\"failed_at\":\"2025-12-31 08:54:33\"}}',0,0,'Failed to create backup: sh: line 1: ddev: command not found\n','2025-12-31 07:54:33','2025-12-31 07:54:33','2025-12-31 07:54:33','2025-12-31 07:54:33'),
(2,'full_scrape','Step 1/12: Creating Database Backup','failed','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.011627197265625,\"success\":false,\"error\":\"Failed to create backup: sh: line 1: ddev: command not found\\n\",\"failed_at\":\"2025-12-31 08:58:25\"}}',0,0,'Failed to create backup: sh: line 1: ddev: command not found\n','2025-12-31 07:58:25','2025-12-31 07:58:25','2025-12-31 07:58:25','2025-12-31 07:58:25'),
(3,'full_scrape','Step 12/12: Verifying Data Integrity','completed','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.48484015464782715,\"success\":true,\"details\":{\"Backup File\":\"\\/home\\/iracket\\/domains\\/dev.iracket.se\\/public_html\\/storage\\/app\\/private\\/iRacket\\/2025-12-31-11-36-01.zip\"},\"completed_at\":\"2025-12-31 11:36:01\"},\"step_2\":{\"description\":\"Scraping Players\",\"duration\":1.0127110481262207,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2025-12-31 11:36:02\"},\"step_3\":{\"description\":\"Syncing Players \\u2192 Users & Clubs\",\"duration\":0.02055191993713379,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2025-12-31 11:36:02\"},\"step_4\":{\"description\":\"Scraping Series Matches\",\"duration\":1.0031259059906006,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2025-12-31 11:36:03\"},\"step_5\":{\"description\":\"Syncing Matches\",\"duration\":0.011952877044677734,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2025-12-31 11:36:03\"},\"step_6\":{\"description\":\"Scraping Rankings (Male) - 3 Parallel Processes\",\"duration\":7.004768133163452,\"success\":true,\"details\":[],\"completed_at\":\"2025-12-31 11:36:10\"},\"step_7\":{\"description\":\"Scraping Rankings (Female) - 3 Parallel Processes\",\"duration\":7.004203796386719,\"success\":true,\"details\":[],\"completed_at\":\"2025-12-31 11:36:17\"},\"step_8\":{\"description\":\"Syncing All Rankings\",\"duration\":0.010868072509765625,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2025-12-31 11:36:17\"},\"step_9\":{\"description\":\"Scraping Series Standings\",\"duration\":1.0026288032531738,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2025-12-31 11:36:18\"},\"step_10\":{\"description\":\"Calculating Bubbler Points\",\"duration\":0.003520965576171875,\"success\":true,\"details\":{\"Errors\":0},\"completed_at\":\"2025-12-31 11:36:18\"},\"step_11\":{\"description\":\"Aggregating Club Rankings\",\"duration\":0.004928112030029297,\"success\":true,\"details\":[],\"completed_at\":\"2025-12-31 11:36:18\"},\"step_12\":{\"description\":\"Verifying Data Integrity\",\"duration\":0.004445075988769531,\"success\":true,\"details\":[],\"completed_at\":\"2025-12-31 11:36:18\"}}',0,0,NULL,'2025-12-31 10:36:01','2025-12-31 10:36:18','2025-12-31 10:36:01','2025-12-31 10:36:18'),
(4,'full_scrape','Step 1/12: Creating Database Backup','running','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}',NULL,0,0,NULL,'2025-12-31 10:44:36',NULL,'2025-12-31 10:44:36','2025-12-31 10:44:36');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php?forb=SBTF.SE.BT','string','urls','URL for players list scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `terms` VALUES
(1,'{\"en\":\"Terms and Conditions\"}','terms-and-conditions','{\"en\":\"\\n                <h1>Terms and Conditions<\\/h1>\\n                <p><strong>Last updated:<\\/strong> November 22, 2025<\\/p>\\n\\n                <h2>1. Acceptance of Terms<\\/h2>\\n                <p>By accessing and using iRacket, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.<\\/p>\\n\\n                <h2>2. Use License<\\/h2>\\n                <p>Permission is granted to temporarily use iRacket for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:<\\/p>\\n                <ul>\\n                    <li>modify or copy the materials;<\\/li>\\n                    <li>use the materials for any commercial purpose, or for any public display (commercial or non-commercial);<\\/li>\\n                    <li>attempt to decompile or reverse engineer any software contained on iRacket;<\\/li>\\n                    <li>remove any copyright or other proprietary notations from the materials; or<\\/li>\\n                    <li>transfer the materials to another person or \\\"mirror\\\" the materials on any other server.<\\/li>\\n                <\\/ul>\\n\\n                <h2>3. User Account<\\/h2>\\n                <p>To use certain features of iRacket, you must register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.<\\/p>\\n\\n                <h2>4. User Conduct<\\/h2>\\n                <p>You agree not to use iRacket to:<\\/p>\\n                <ul>\\n                    <li>Upload, post, or transmit any content that is unlawful, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, or otherwise objectionable;<\\/li>\\n                    <li>Impersonate any person or entity;<\\/li>\\n                    <li>Upload, post, or transmit any content that infringes any patent, trademark, trade secret, copyright, or other proprietary rights;<\\/li>\\n                    <li>Upload, post, or transmit any unsolicited or unauthorized advertising, promotional materials, or any other form of solicitation.<\\/li>\\n                <\\/ul>\\n\\n                <h2>5. Disclaimer<\\/h2>\\n                <p>The materials on iRacket are provided on an \\\"as is\\\" basis. iRacket makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.<\\/p>\\n\\n                <h2>6. Limitations<\\/h2>\\n                <p>In no event shall iRacket or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use iRacket.<\\/p>\\n\\n                <h2>7. Modifications<\\/h2>\\n                <p>iRacket may revise these terms of service at any time without notice. By using this application you are agreeing to be bound by the then current version of these terms of service.<\\/p>\\n\\n                <h2>8. Governing Law<\\/h2>\\n                <p>These terms and conditions are governed by and construed in accordance with the laws and you irrevocably submit to the exclusive jurisdiction of the courts in that location.<\\/p>\\n\\n                <h2>9. Contact Us<\\/h2>\\n                <p>If you have any questions about these Terms and Conditions, please contact us at support@iracket.com.<\\/p>\\n            \"}',1,'2025-11-22 16:05:42','2025-11-22 16:05:42'),
(2,'{\"en\":\"Privacy Policy\"}','privacy-policy','{\"en\":\"\\n                <h1>Privacy Policy<\\/h1>\\n                <p><strong>Last updated:<\\/strong> November 22, 2025<\\/p>\\n\\n                <h2>1. Introduction<\\/h2>\\n                <p>Welcome to iRacket. We respect your privacy and are committed to protecting your personal data. This privacy policy will inform you about how we look after your personal data and tell you about your privacy rights.<\\/p>\\n\\n                <h2>2. Information We Collect<\\/h2>\\n                <p>We may collect, use, store and transfer different kinds of personal data about you which we have grouped together as follows:<\\/p>\\n                <ul>\\n                    <li><strong>Identity Data<\\/strong> includes first name, last name, username or similar identifier.<\\/li>\\n                    <li><strong>Contact Data<\\/strong> includes email address and telephone numbers.<\\/li>\\n                    <li><strong>Technical Data<\\/strong> includes internet protocol (IP) address, your login data, browser type and version, time zone setting and location.<\\/li>\\n                    <li><strong>Profile Data<\\/strong> includes your username and password, your interests, preferences, feedback and survey responses.<\\/li>\\n                    <li><strong>Usage Data<\\/strong> includes information about how you use our website and services.<\\/li>\\n                <\\/ul>\\n\\n                <h2>3. How We Use Your Information<\\/h2>\\n                <p>We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:<\\/p>\\n                <ul>\\n                    <li>To register you as a new customer.<\\/li>\\n                    <li>To process and deliver your service.<\\/li>\\n                    <li>To manage our relationship with you.<\\/li>\\n                    <li>To improve our website, products\\/services, marketing or customer relationships.<\\/li>\\n                    <li>To recommend products or services which may be of interest to you.<\\/li>\\n                <\\/ul>\\n\\n                <h2>4. Data Security<\\/h2>\\n                <p>We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your personal data to those employees, agents, contractors and other third parties who have a business need to know.<\\/p>\\n\\n                <h2>5. Data Retention<\\/h2>\\n                <p>We will only retain your personal data for as long as necessary to fulfil the purposes we collected it for, including for the purposes of satisfying any legal, accounting, or reporting requirements.<\\/p>\\n\\n                <h2>6. Your Legal Rights<\\/h2>\\n                <p>Under certain circumstances, you have rights under data protection laws in relation to your personal data, including the right to:<\\/p>\\n                <ul>\\n                    <li>Request access to your personal data.<\\/li>\\n                    <li>Request correction of your personal data.<\\/li>\\n                    <li>Request erasure of your personal data.<\\/li>\\n                    <li>Object to processing of your personal data.<\\/li>\\n                    <li>Request restriction of processing your personal data.<\\/li>\\n                    <li>Request transfer of your personal data.<\\/li>\\n                    <li>Right to withdraw consent.<\\/li>\\n                <\\/ul>\\n\\n                <h2>7. Third-Party Links<\\/h2>\\n                <p>This website may include links to third-party websites, plug-ins and applications. Clicking on those links or enabling those connections may allow third parties to collect or share data about you. We do not control these third-party websites and are not responsible for their privacy statements.<\\/p>\\n\\n                <h2>8. Cookies<\\/h2>\\n                <p>We use cookies to distinguish you from other users of our website. This helps us to provide you with a good experience when you browse our website and also allows us to improve our site.<\\/p>\\n\\n                <h2>9. Changes to This Privacy Policy<\\/h2>\\n                <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the \\\"Last updated\\\" date.<\\/p>\\n\\n                <h2>10. Contact Us<\\/h2>\\n                <p>If you have any questions about this Privacy Policy, please contact us at privacy@iracket.com.<\\/p>\\n            \"}',1,'2025-11-22 16:05:42','2025-11-22 16:05:42'),
(3,'{\"en\":\"Bubbler\"}','bubbler','{\"en\":\"\\n                    <h1>What is Bubbler?<\\/h1>\\n                    <p>Bubbler is about who was the best the previous month.<\\/p>\\n\\n                    <h2>How do you know if you\'ve been the best?<\\/h2>\\n                    <p>Well, it\'s about who got the most points the previous month, and it\'s the most points in their range.<\\/p>\\n\\n                    <p>The ranges are: 0-499, 500-999, 1000-1249, 1250-1499, 1500-1749, 1750-1999, 2000-2249, 2250 and up.<\\/p>\\n\\n                    <p>We show the top three in each segment and region. The default is within your own range and region.<\\/p>\\n\\n                    <h2>Interval for Women<\\/h2>\\n                    <ul>\\n                        <li><strong>Elite class:<\\/strong> At least 1750 points<\\/li>\\n                        <li><strong>Class 1:<\\/strong> 1500-1749 points<\\/li>\\n                        <li><strong>Class 2:<\\/strong> 1250-1499 points<\\/li>\\n                        <li><strong>Class 3:<\\/strong> 1000-1249 points<\\/li>\\n                        <li><strong>Class 4:<\\/strong> 750-999 points<\\/li>\\n                        <li><strong>Class 5:<\\/strong> Maximum 749 points<\\/li>\\n                    <\\/ul>\\n\\n                    <h2>Interval for Men<\\/h2>\\n                    <ul>\\n                        <li><strong>Elite:<\\/strong> At least 2250 points<\\/li>\\n                        <li><strong>Class 1:<\\/strong> 2000-2249 points<\\/li>\\n                        <li><strong>Class 2:<\\/strong> 1750-1999 points<\\/li>\\n                        <li><strong>Class 3:<\\/strong> 1500-1749 points<\\/li>\\n                        <li><strong>Class 4:<\\/strong> 1250-1499 points<\\/li>\\n                        <li><strong>Class 5:<\\/strong> 1000-1249 points<\\/li>\\n                        <li><strong>Class 6:<\\/strong> 750-999 points<\\/li>\\n                        <li><strong>Class 7:<\\/strong> Maximum 749 points<\\/li>\\n                    <\\/ul>\\n\\n                    <p>If you get, for example, 100 points one month and go over the range, you will appear in your previous range.<\\/p>\\n\\n                    <p>Bubblers are simply different lists based on rankings combined with gender, age, geography, etc. We want to build a number of lists that we publish on different pages.<\\/p>\\n\\n                    <h2>How Points are Calculated<\\/h2>\\n                    <p>When a user enters new match statistics, the system implements the following logic:<\\/p>\\n                    <ol>\\n                        <li>Calculate the ranking point difference between the players playing the match.<\\/li>\\n                        <li>Check within which ranking score difference interval the result belongs.<\\/li>\\n                        <li>Check which player is the winner and whether it was with higher ranking points or lower ranking points, before the match.<\\/li>\\n                        <li>Increase and decrease the points according to the winner and loser of the match, based on the official figures below.<\\/li>\\n                    <\\/ol>\\n\\n                    <h2>Points Table<\\/h2>\\n                    <table style=\\\"width: 100%; border-collapse: collapse; margin: 1rem 0;\\\">\\n                        <thead>\\n                            <tr style=\\\"border-bottom: 2px solid #404040;\\\">\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Point Difference<\\/th>\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Higher Ranked Wins<\\/th>\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Lower Ranked Wins<\\/th>\\n                            <\\/tr>\\n                        <\\/thead>\\n                        <tbody>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">0 - 25<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">10 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">10 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">26 - 50<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">9 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">11 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">51 - 75<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">8 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">12 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">76 - 100<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">7 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">13 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">101 - 125<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">6 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">15 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">126 - 150<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">6 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">16 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">151 - 200<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">5 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">17 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">201 - 250<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">4 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">18 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">251 - 300<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">3 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">19 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">301 - 400<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">20 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">401 - 500<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">30 points<\\/td>\\n                            <\\/tr>\\n                            <tr>\\n                                <td style=\\\"padding: 0.75rem;\\\">501 and up<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">40 points<\\/td>\\n                            <\\/tr>\\n                        <\\/tbody>\\n                    <\\/table>\\n\\n                    <p>The winner receives plus points and the loser receives the same number of minus points according to the table.<\\/p>\\n\\n                    <h2>Example<\\/h2>\\n                    <p><strong>Player 1:<\\/strong> 1100 points<br>\\n                    <strong>Player 2:<\\/strong> 1300 points<\\/p>\\n\\n                    <p>The difference in points = 1300 - 1100 = <strong>200 points<\\/strong><\\/p>\\n\\n                    <p>Based on the table above (151-200 range):<\\/p>\\n                    <ul>\\n                        <li><strong>If Player 1 wins:<\\/strong> Player 1 will have 1117 points (+17) and Player 2 will have 1283 points (-17)<\\/li>\\n                        <li><strong>If Player 2 wins:<\\/strong> Player 1 will have 1095 points (-5) and Player 2 will have 1305 points (+5)<\\/li>\\n                    <\\/ul>\\n\\n                    <p>Bubblers are lists based on different listings. We place different lists on various pages throughout the application.<\\/p>\\n                \"}',1,'2025-11-22 16:16:52','2025-11-22 16:16:52'),
(4,'{\"en\":\"About Us\"}','about','{\"en\":\"\\n                    <h1>About Us<\\/h1>\\n                    <p>Welcome to i-Racket, what rankings should be and a little more.<\\/p>\\n\\n                    <p>We are passionate table tennis players who have created this app to bring together and strengthen the table tennis community throughout Sweden. i-Racket is your ultimate companion for everything related to table tennis rankings, whether you are a beginner or an experienced player.<\\/p>\\n\\n                    <h2>Our Vision<\\/h2>\\n                    <p>We strive to promote and develop table tennis in Sweden by offering a platform that enables community, competition, ranking and engagement. Our vision is to highlight table tennis with a focus on ranking and thus encourage growth in the sport.<\\/p>\\n\\n                    <h2>What i-Racket Offers<\\/h2>\\n                    <ul>\\n                        <li><strong>Real-time rankings:<\\/strong> Every match you publish generates your new ranking. You can immediately see how you can climb the rankings or fight to maintain your position.<\\/li>\\n                        <li><strong>Monthly Rankings:<\\/strong> We retrieve and secure your ranking from the official industry body.<\\/li>\\n                        <li><strong>Follow your Favorite Players:<\\/strong> Follow your favorite players and friends. Get updates on their latest matches and achievements.<\\/li>\\n                        <li><strong>Record your own matches:<\\/strong> Record your own matches played, and note their strengths and weaknesses. The next time you meet, you can use this information.<\\/li>\\n                        <li><strong>Bubbler:<\\/strong> We highlight the most promising players and the most prominent clubs in the country.<\\/li>\\n                        <li><strong>Follow your child:<\\/strong> As a parent, you can follow your child and their friends. You can see their progress and any awards they have won.<\\/li>\\n                    <\\/ul>\\n\\n                    <h2>Our Team<\\/h2>\\n                    <p>i-Racket is created by a dedicated team of table tennis enthusiasts. We are passionate about the sport and about creating a dynamic and user-friendly platform that helps you improve your game and experience the joy of table tennis.<\\/p>\\n\\n                    <h2>Contact<\\/h2>\\n                    <p>Do you have any questions, suggestions or just want to say hello? Don\'t hesitate to contact us at <a href=\\\"mailto:info@iracket.se\\\">info@iracket.se<\\/a><\\/p>\\n                \"}',1,'2025-11-22 16:19:19','2025-11-22 16:19:19');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `user_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `monitored_user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_monitors_user_id_monitored_user_id_unique` (`user_id`,`monitored_user_id`),
  KEY `user_monitors_monitored_user_id_foreign` (`monitored_user_id`),
  CONSTRAINT `user_monitors_monitored_user_id_foreign` FOREIGN KEY (`monitored_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_monitors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_monitors` WRITE;
/*!40000 ALTER TABLE `user_monitors` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `user_monitors` VALUES
(1,2,173,'2025-11-24 08:52:16','2025-11-24 08:52:16'),
(2,2,127,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(3,2,141,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(4,2,157,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(5,127,133,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(6,127,156,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(7,127,169,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(8,128,129,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(9,128,168,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(10,129,127,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(11,129,159,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(12,129,168,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(13,129,169,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(14,130,140,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(15,130,148,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(16,130,159,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(17,131,137,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(18,131,146,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(19,131,173,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(20,132,133,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(21,132,138,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(22,132,158,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(23,132,161,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(24,132,174,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(25,133,142,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(26,133,166,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(27,134,132,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(28,134,140,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(29,134,150,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(30,134,163,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(31,135,128,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(32,135,137,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(33,135,152,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(34,135,158,'2025-11-24 10:21:10','2025-11-24 10:21:10');
/*!40000 ALTER TABLE `user_monitors` ENABLE KEYS */;
UNLOCK TABLES;
commit;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `birth_year` int(11) DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `sbtf_player_id` varchar(255) DEFAULT NULL,
  `sbtf_synced` tinyint(1) NOT NULL DEFAULT 0,
  `sbtf_synced_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 0,
  `is_active_player` tinyint(1) NOT NULL DEFAULT 1,
  `accepts_push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  KEY `users_player_match_index` (`last_name`,`first_name`,`birth_year`),
  KEY `users_sbtf_player_id_index` (`sbtf_player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES
(2,'db312c7b-1b97-439f-93b8-4ca9b49fc489','Andrej','Gjoshevski',NULL,'info@weboook.co.uk',NULL,NULL,NULL,NULL,7,1,'111992287661943275388',NULL,NULL,0,NULL,'2025-11-22 21:28:18',1,1,1,NULL,NULL,'$2y$12$xF6RqzkXuxbI847ijlDYvuqVWFfmimA/hu/UNB7LXkOcOj37HkX06',NULL,NULL,NULL,'nV756jSOfHSEKdPfhCdbkwlxNU3BVsDd4OANTAnTwRgEPWZNGtUnNgvyUt18',NULL,NULL,NULL,1,'2025-11-22 16:15:48','2025-11-22 16:15:48','2025-12-31 07:51:49'),
(127,'8f5123a6-abda-4520-bfbe-daf78b1f2702','Andrej','Gjoshevski',NULL,'gosezmaj@gmail.com',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,0,1,0,'457233','2025-11-24 07:09:57','$2y$12$va7ejwOfgKdABoA9P0wHk.wINjxMfJ9TqVC/9XcopPJyxqNiAObqK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 06:54:57','2025-11-24 06:54:57','2025-11-24 06:54:57'),
(128,'e6cde269-c35d-4f63-b8a6-130f291908f6','Daniel','Axelsson',NULL,'daniel.axelsson0@example.com',NULL,'male',38,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:16',0,1,0,NULL,NULL,'$2y$12$pI.QPhgDSSWZ5tWYEdRvy..sS1FkPGJGMYufLnV9a7ARn2SpLJKRu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:16','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(129,'d6b6f95a-c390-4bb4-847c-f9059162794e','Björn','Bergström',NULL,'björn.bergström1@example.com',NULL,'male',43,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:16',0,1,0,NULL,NULL,'$2y$12$BbOB60.nuQ69ZwIEvwsC9Ot.N9r4t2xJn1Vf0GwWd9jLUZJxasc4i',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:16','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(130,'57857c1c-325a-4bfa-b067-ba021c540dde','Johan','Berg',NULL,'johan.berg2@example.com',NULL,'male',31,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:16',0,1,0,NULL,NULL,'$2y$12$nS2OpQtVPs8qbQK4cxtjau708VbKlRq2DACF/0mEsBtPQlejC.LkW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:16','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(131,'72e2ed65-4c46-4d6a-8ad1-2a314d00e7ec','Magnus','Svensson',NULL,'magnus.svensson3@example.com',NULL,'male',26,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:17',0,1,0,NULL,NULL,'$2y$12$5PRd7OAyZKk.tbfXpMMD8.s8Ns5Erg.qw1ohBgu0XcNlAGZU7j9YW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:17','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(132,'427464c2-f6d7-43c0-922e-325438c58e39','Magnus','Andersson',NULL,'magnus.andersson4@example.com',NULL,'male',52,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:17',0,1,0,NULL,NULL,'$2y$12$UxX2KDjhDgcxKPnD9THVjOtw0V7Ft229gYuIvNpQsKO7n9oA0SMfi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:17','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(133,'ade055e9-21d4-430e-a0e0-9ea0b3244726','Peter','Hansson',NULL,'peter.hansson5@example.com',NULL,'male',51,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:17',0,1,0,NULL,NULL,'$2y$12$FePpCjW5dHIx6mzrYSyakuC4BJcWR0Wo9/a/oNwsTUr1foTY1XXsW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:17','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(134,'25fdb2be-859f-400d-b15a-7a18a08824b9','Oscar','Andersson',NULL,'oscar.andersson6@example.com',NULL,'male',41,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:17',0,1,0,NULL,NULL,'$2y$12$7IAqpC8ZptsLZE4BYGyiX.UrPYmUlPfIEh3wH2Be.pjww16/XRDkK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:17','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(135,'51c5f500-cb81-492c-a853-a22d92f0448c','Fredrik','Lund',NULL,'fredrik.lund7@example.com',NULL,'male',36,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:17',0,1,0,NULL,NULL,'$2y$12$Df401J1ieuUzJbCUPt/4weJmDTNUWyqTq8WcXvhG72PfTZTbGj/Nu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:17','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(136,'41a3ecbd-7cc3-4643-8474-43cd47143c01','Jan','Berglund',NULL,'jan.berglund8@example.com',NULL,'male',42,NULL,6,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:18',0,1,0,NULL,NULL,'$2y$12$zakPhoxbl.RgYPUcF1HpJ.mcwKAJjL5xKHH8bqQ4lK4gjO.tDxUnC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:18','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(137,'6ed0bffe-edc5-435c-831d-5af4e6376f85','Nils','Jonsson',NULL,'nils.jonsson9@example.com',NULL,'male',23,NULL,6,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:18',0,1,0,NULL,NULL,'$2y$12$rwvqEiNWjynWXy/oDlNI1.P4VPQzxUMufCuRfSeSTeVf/Dn1URNKK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:18','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(138,'d352de93-ff84-4239-a8a7-12c93119c529','Fredrik','Lundgren',NULL,'fredrik.lundgren10@example.com',NULL,'male',39,NULL,5,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:18',0,1,0,NULL,NULL,'$2y$12$Sh38YXnq9ePCiikLk4T4o.7xr9HXu2wePpDZM89BGkpio8Z5JHI1m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:18','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(139,'4d3182c5-b08d-414a-b21c-34567878c0dc','Jan','Lundgren',NULL,'jan.lundgren11@example.com',NULL,'male',51,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:18',0,1,0,NULL,NULL,'$2y$12$heEuGRjQ94oAPgmecxb1guZ41oabrVl.vfPVT4UauN/ldxnHmVA92',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:18','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(140,'02323eeb-5922-4d32-8f55-6eba47d3f81c','Stefan','Lund',NULL,'stefan.lund12@example.com',NULL,'male',38,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:18',0,1,0,NULL,NULL,'$2y$12$ffMpP8Uv4HWf9j4bFXs35e9ZTCrW.UHYcpevqHdCqeMn4rQFW3wYG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:18','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(141,'607614f1-cb11-41ca-a874-104e3d69bf94','Mattias','Berg',NULL,'mattias.berg13@example.com',NULL,'male',38,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:19',0,1,0,NULL,NULL,'$2y$12$Z7hEumKA3DWsEgMJaKsThO837MpYDYJhb1bAiU.80x6GZgpwF476e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:19','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(142,'c97d9b7e-be62-4f75-ba96-f176d461d12a','Jan','Mattsson',NULL,'jan.mattsson14@example.com',NULL,'male',50,NULL,8,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:19',0,1,0,NULL,NULL,'$2y$12$bgnB2HagQgDE6uHYsAOst.ODM8Ro79JS1pVCkH384Vzw741ra7XVm',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:19','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(143,'4d5c4095-69ac-41a2-ba1f-d9d9a006f190','Oscar','Lundgren',NULL,'oscar.lundgren15@example.com',NULL,'male',24,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:19',0,1,0,NULL,NULL,'$2y$12$LzZrfRyF0.gWw5ClIP95HuGYZJmFzoPlwUMTscqXCYc/dR9vvnoNG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:19','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(144,'7857d45c-2590-471d-8627-aac2afbe894d','Fredrik','Bergström',NULL,'fredrik.bergström16@example.com',NULL,'male',21,NULL,7,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:19',0,1,0,NULL,NULL,'$2y$12$DP5Y0btAZSGg5jy.HzZzg.t5C7iaYSlWWwEa6etZE.HDoNUdyJRvy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:19','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(145,'e98f1c4f-67ea-4197-8950-d0fbe84577e4','Marcus','Svensson',NULL,'marcus.svensson17@example.com',NULL,'male',33,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:19',0,1,0,NULL,NULL,'$2y$12$7FhU92O6vPfJJdvJneRHiuCtHfOdhQws.TmC0VQ3CUEACZ7vKlvi.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:19','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(146,'153ff6a0-b5b3-471f-9e74-c4c5eb93619a','Erik','Lindberg',NULL,'erik.lindberg18@example.com',NULL,'male',22,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:19',0,1,0,NULL,NULL,'$2y$12$ZWJMfLP0oStosf7kguVt3uTLhbc6qp4yh/UlNt04olBJXRHbPXRpS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:19','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(147,'bb1052b5-dcbe-48b1-a611-9569ee6da2ec','Jan','Olsson',NULL,'jan.olsson19@example.com',NULL,'male',27,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:20',0,1,0,NULL,NULL,'$2y$12$sUCSKa8qDyqaeAVsmz7dBOeercGOr4G5j.So1q6Gex7jHesGVelam',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:20','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(148,'07ef1d61-c779-482a-95c1-8af9a20ce33d','Johan','Fredriksson',NULL,'johan.fredriksson20@example.com',NULL,'male',39,NULL,7,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:20',0,1,0,NULL,NULL,'$2y$12$B7DJm7H7IGZPuIk5RpQfS.JaiB8EEhin00HLYo9DWHIMxjU9.v.jy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:20','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(149,'ec74f068-3b38-4f55-be69-4ba9baad0a20','Henrik','Lundgren',NULL,'henrik.lundgren21@example.com',NULL,'male',55,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:20',0,1,0,NULL,NULL,'$2y$12$97U1cEE8gn2jxumvLFlLqe55kwuchTLSM5vuRpsSkqtr6BjOnDEHq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:20','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(150,'1c2e18ad-a202-4d69-b8ae-7d695a6e0b0f','Jan','Larsson',NULL,'jan.larsson22@example.com',NULL,'male',44,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:20',0,1,0,NULL,NULL,'$2y$12$FkUPHV.exVCrZMQdVYg0SOu4Svm4h2D6KSlaQDLhXNiNARwFKF57W',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:20','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(151,'7bb954c6-e9b6-47e0-a1ee-c87909b5bd7b','Björn','Persson',NULL,'björn.persson23@example.com',NULL,'male',53,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:20',0,1,0,NULL,NULL,'$2y$12$.D8KX8Asvp6B9SwN4VD5Fui2WMBiLJY0LyXJfT3CjYJVHTSAT0pOG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:20','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(152,'5fd70e6d-f7f8-41b3-8109-5a64198fad3b','Björn','Bengtsson',NULL,'björn.bengtsson24@example.com',NULL,'male',45,NULL,8,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:21',0,1,0,NULL,NULL,'$2y$12$p/su4QdJIaHQjuddun.qWOIG8FlWPWevhgMUntiTz3J2Pj9nnH2Ym',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:21','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(153,'f0d47656-eb50-445e-88dd-da3f8245e388','Karin','Berg',NULL,'karin.berg0@example.com',NULL,'female',23,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:21',0,1,0,NULL,NULL,'$2y$12$gc8crxi4DqGtu7g19NOOCe6JvulWdAUto6JTfSjPtxjYCxwIupO3e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:21','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(154,'5f83d143-d2be-4eff-b11c-31a3e6af28b8','Karin','Pettersson',NULL,'karin.pettersson1@example.com',NULL,'female',21,NULL,6,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:21',0,1,0,NULL,NULL,'$2y$12$zcShlsGvpC8FR5kYa5EucOaMCrSyF78dG0jGJqam0KoH6U/.D/2si',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:21','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(155,'a287dc87-73fd-46fb-80c3-640bb0f83746','Anna','Andersson',NULL,'anna.andersson2@example.com',NULL,'female',32,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:21',0,1,0,NULL,NULL,'$2y$12$k0MXtMehSLVtT1ZVy1tyY.Xq5qZ9Mf6DNCY/OxSIfAF2zLHPAlxEm',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:21','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(156,'2e1af134-6715-4d3c-afe7-d2fa1f62bd62','Maja','Lund',NULL,'maja.lund3@example.com',NULL,'female',55,NULL,8,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:21',0,1,0,NULL,NULL,'$2y$12$CCAqtamTuoUBkK/b/LE88.sPJEhcWDcuxXAOUxCgr07xbq/EWaF2q',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:21','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(157,'a2bf787b-c055-46da-a8d5-4e14fc72171a','Karin','Lindqvist',NULL,'karin.lindqvist4@example.com',NULL,'female',52,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:21',0,1,0,NULL,NULL,'$2y$12$Y6g/YrIea3w5IMN7a4xPG.QEIWgG1SOKFK.kg3EV3rtKIu5j1gOIe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:21','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(158,'30f634f3-60bf-45f2-883f-2f42a7460f05','Kristina','Johansson',NULL,'kristina.johansson5@example.com',NULL,'female',54,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:22',0,1,0,NULL,NULL,'$2y$12$uDOTAH2hEP6td.KJDBJRye7nEJ6hwbe/ytCJLCIYgk2.95mGdVB7K',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:22','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(159,'098517fa-0673-4179-b7b7-c5f65040bd2d','Ingrid','Lund',NULL,'ingrid.lund6@example.com',NULL,'female',51,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:22',0,1,0,NULL,NULL,'$2y$12$woJs3ntiMJkW.TFFahvejulTTkrwaSF8RXn4slODS5nNxuhA0JMde',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:22','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(160,'8eb8a8f0-529c-4c83-884e-bd3024e1efc6','Ingrid','Lindström',NULL,'ingrid.lindström7@example.com',NULL,'female',41,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:22',0,1,0,NULL,NULL,'$2y$12$qQ1q/loXd1m41XkeIvY24Ol.gJBBnIaPPmwPREl8i07StZGjnhq/m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:22','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(161,'2e5af614-c3c0-494c-a80c-8e84005aa92f','Lena','Jansson',NULL,'lena.jansson8@example.com',NULL,'female',34,NULL,8,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:22',0,1,0,NULL,NULL,'$2y$12$rEaJ29DWHqb45l0V8lfMEegdjhTYPhSArR0D/1ybsnyjT.9plGOp.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:22','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(162,'ec77c91a-3156-439f-bf1b-b6bc24dc8761','Wilma','Hansson',NULL,'wilma.hansson9@example.com',NULL,'female',37,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:22',0,1,0,NULL,NULL,'$2y$12$xTpl1s3epkdzlPNkbfNQxu85x.PSNG7O2iAtgSh71Srt3pQ.peePG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:22','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(163,'c5efb644-7c45-4d2d-8430-a7ddfbbd0251','Johanna','Hansson',NULL,'johanna.hansson10@example.com',NULL,'female',34,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:23',0,1,0,NULL,NULL,'$2y$12$UpIYmVdZC15Ka2AJueUI1OCjZwQXWvN1rw4TNoJdCEQMQDGLxPOkW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:23','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(164,'c4318d9c-425a-4ceb-b7a2-bdfde0b9e2bc','Maja','Lundqvist',NULL,'maja.lundqvist11@example.com',NULL,'female',43,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:23',0,1,0,NULL,NULL,'$2y$12$HIQB3S/VWSC5sXrOnP1vq.6aYFcS4jIh6LsCbFinF2wIh3ltelxoy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:23','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(165,'346884de-ab14-448b-93dc-19e9ba167bea','Maja','Olsson',NULL,'maja.olsson12@example.com',NULL,'female',25,NULL,7,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:23',0,1,0,NULL,NULL,'$2y$12$OWfHwc6oOcjZ84uh9FERZOn2sBlmbmwi0xJuu3MxMbpSLGj63onay',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:23','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(166,'29a71406-df5b-44ea-ad4e-4aedca729b38','Emma','Karlsson',NULL,'emma.karlsson13@example.com',NULL,'female',23,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:23',0,1,0,NULL,NULL,'$2y$12$yopOGHANFvZYfZhhgtXOh.JnMp4ajA6t7qYJt.Q6cH8K3pBrgeBqi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:23','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(167,'7d32feef-c6e0-43fd-bb4f-1098116f3daf','Amanda','Persson',NULL,'amanda.persson14@example.com',NULL,'female',45,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:23',0,1,0,NULL,NULL,'$2y$12$ccJbUpVH8wsBwf.KoxORB.cq0xBZDTFKWBGjft.vtWTMWuo7Xaczy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:23','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(168,'54bb33cb-1f15-4cfa-a58f-41744407a4ab','Ingrid','Johansson',NULL,'ingrid.johansson15@example.com',NULL,'female',18,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:24',0,1,0,NULL,NULL,'$2y$12$1vtbfKxsxcUvBVS0oWOT1.mPwOC4d9tIz.mgLDw4cm3/PYJ.rys7W',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:24','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(169,'62992532-7653-410d-aa97-b0fbb75f69fa','Karin','Jansson',NULL,'karin.jansson16@example.com',NULL,'female',40,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:24',0,1,0,NULL,NULL,'$2y$12$TbYrI79jqy6rJ4aOw5S4nebtW/uHvRgvOftuFX/qTFtrh6Qx1sd6y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:24','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(170,'3e5cd16d-b678-48da-9f26-7c4d2b26a5f8','Maja','Lindqvist',NULL,'maja.lindqvist17@example.com',NULL,'female',21,NULL,3,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:24',0,1,0,NULL,NULL,'$2y$12$IYFIEsNJcf/W6ufQQE8aS.yr81Sgb08/ObHM2pKq1IEoR0Mm0dKru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:24','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(171,'cdfd5d62-1d54-4054-8170-8be355165298','Maja','Lindberg',NULL,'maja.lindberg18@example.com',NULL,'female',26,NULL,4,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:24',0,1,0,NULL,NULL,'$2y$12$NCehN28tj2ixXyxdyruYA.niZPGHhp222aC6VtnI8/84cEt7g0naW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:24','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(172,'2d54cd09-cdda-47f3-b3d9-2da1014f3a77','Emma','Fredriksson',NULL,'emma.fredriksson19@example.com',NULL,'female',31,NULL,7,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:24',0,1,0,NULL,NULL,'$2y$12$9q0DLxnhKKSu4pvNB3Enle8dlTHXdpZ1R2qZ66HC1TYMwina74I7m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:24','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(173,'72246273-5433-47db-8283-0602d74193a1','Jessica','Lindqvist',NULL,'jessica.lindqvist20@example.com',NULL,'female',55,NULL,6,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:24',0,1,0,NULL,NULL,'$2y$12$qEKSgEQvmz9pBRDrvZAAOufk1XcjklpXHEYYPUuP56BmTSjOAWzKq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:24','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(174,'1723196a-88a7-41a8-a18a-ac76dbd692ce','Anna','Hansson',NULL,'anna.hansson21@example.com',NULL,'female',41,NULL,1,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:25',0,1,0,NULL,NULL,'$2y$12$hYfyTabXFhwvEXG8jaOsu.sTkN07kClUy23pe/xEgaa8AjufTkPmC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:25','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(175,'fce7517e-7922-4bce-a7ce-c309bee672fd','Karin','Lindström',NULL,'karin.lindström22@example.com',NULL,'female',20,NULL,2,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:25',0,1,0,NULL,NULL,'$2y$12$Wu50Jywg1DIG511B4omkJOwR0zd9x6ACv/6FkCLRFhtHy.fJQBMrq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:25','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(176,'b8d08c43-e041-4a51-ac3b-f419ad8dcaa4','Johanna','Hansson',NULL,'johanna.hansson23@example.com',NULL,'female',34,NULL,5,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:25',0,1,0,NULL,NULL,'$2y$12$Q6mIjrBpZCr7fcs0M7UJuOu8mzijSkes4cMGR1atcL9O/HMT8MGuO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:25','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(177,'bcc00e92-b210-40c4-9914-507f07b6614c','Sara','Lindgren',NULL,'sara.lindgren24@example.com',NULL,'female',31,NULL,7,1,NULL,NULL,NULL,0,NULL,'2025-11-24 07:10:25',0,1,0,NULL,NULL,'$2y$12$Vq3aViAXzGPUcpe1DIEkJ.S1MP9ek8z6wM3sHSkrDlkbRL52RHWHq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-24 07:10:25','2025-11-24 07:10:25','2025-11-24 07:10:25'),
(178,'0ef21a23-fda0-41e1-976c-0afb6b02b264','Mirjana','Davcheva',NULL,'mirjana.davcheva@gmail.com',NULL,NULL,NULL,NULL,NULL,1,'106171430107742147139',NULL,NULL,0,NULL,'2025-12-12 19:07:29',0,1,0,NULL,NULL,'$2y$12$JLMH4cmJSMHIc9XFFNYhTOBBkrI6cUCV0JZTVCFmTQVs6kwutkkui',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-12-12 13:33:26','2025-12-12 13:33:26','2025-12-12 19:07:29'),
(179,'5e34bef4-117a-42e0-b3c9-22744625c98b','Mirjana','Maneva',NULL,'mirjana.maneva@gmail.com',NULL,NULL,NULL,NULL,NULL,1,'106898100476102642416',NULL,NULL,0,NULL,'2025-12-23 06:02:08',0,1,0,NULL,NULL,'$2y$12$Z1gsWveKdfP667Eb5UK4wOubWCkRebcQEpAh01EL7dy0JjtrJIiDe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-12-23 05:47:03','2025-12-23 05:47:03','2025-12-23 06:02:08');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

