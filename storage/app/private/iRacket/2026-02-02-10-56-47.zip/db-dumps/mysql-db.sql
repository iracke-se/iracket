/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` enum('top_sticky','bottom_sticky','top','bottom','within_page','random','popup') NOT NULL DEFAULT 'top',
  `views` bigint(20) unsigned NOT NULL DEFAULT 0,
  `clicks` bigint(20) unsigned NOT NULL DEFAULT 0,
  `locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`locations`)),
  `link` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','scheduled') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iracket-cache-2bebca41af7f98bb7d5ab842f1499cba','i:1;',1770024495),
('iracket-cache-2bebca41af7f98bb7d5ab842f1499cba:timer','i:1770024495;',1770024495),
('iracket-cache-scraper_setting_schedule_export_day','N;',1770033407),
('iracket-cache-scraper_setting_schedule_export_enabled','N;',1770033407),
('iracket-cache-scraper_setting_schedule_export_time','N;',1770033407),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `from_club_id` bigint(20) unsigned DEFAULT NULL,
  `to_club_id` bigint(20) unsigned DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `born` date DEFAULT NULL,
  `from_club_name` varchar(255) DEFAULT NULL,
  `to_club_name` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `club_transitions_to_club_id_completion_date_index` (`to_club_id`,`completion_date`),
  KEY `club_transitions_from_club_id_completion_date_index` (`from_club_id`,`completion_date`),
  KEY `club_transitions_user_id_index` (`user_id`),
  CONSTRAINT `club_transitions_from_club_id_foreign` FOREIGN KEY (`from_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_to_club_id_foreign` FOREIGN KEY (`to_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_transitions` WRITE;
/*!40000 ALTER TABLE `club_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source` enum('player_added','scraped') NOT NULL DEFAULT 'player_added',
  `is_unofficial` tinyint(1) NOT NULL DEFAULT 0,
  `uuid` uuid NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `player1_points_before` int(11) DEFAULT NULL,
  `player2_points_before` int(11) DEFAULT NULL,
  `player1_points_change` int(11) DEFAULT NULL,
  `player2_points_change` int(11) DEFAULT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `is_manual` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `replaced_by_match_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  KEY `matches_replaced_by_match_id_foreign` (`replaced_by_match_id`),
  KEY `match_lookup` (`player1_id`,`player2_id`,`played_at`,`deleted_at`),
  KEY `matches_is_unofficial_index` (`is_unofficial`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_replaced_by_match_id_foreign` FOREIGN KEY (`replaced_by_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3375 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',1),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',1),
(10,'2025_11_22_173439_create_notifications_table',1),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',1),
(12,'2025_11_22_174607_add_age_to_users_table',1),
(13,'2025_11_22_180425_create_clubs_table',1),
(14,'2025_11_22_180426_create_matches_table',1),
(15,'2025_11_22_180426_create_monthly_rankings_table',1),
(16,'2025_11_22_180427_add_club_id_to_users_table',1),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',1),
(18,'2025_11_22_180433_create_permission_tables',1),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',1),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',1),
(21,'2025_11_22_183254_add_uuid_to_users_table',1),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',1),
(23,'2025_11_22_183655_make_terms_translatable',1),
(24,'2025_11_22_231254_create_scraper_tables',1),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',1),
(26,'2025_11_23_074902_add_icon_to_notifications_table',1),
(27,'2025_11_23_084421_create_scraper_settings_table',1),
(28,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',1),
(29,'2025_11_23_090000_create_contacts_table',1),
(30,'2025_11_23_103307_add_sbtf_player_fields_to_users_table',1),
(31,'2025_11_24_091012_create_banners_table',1),
(32,'2025_11_24_094538_create_user_monitors_table',1),
(33,'2025_11_24_102243_add_connection_fields_to_users_table',1),
(34,'2025_11_24_105000_add_points_tracking_to_matches_table',1),
(35,'2025_11_24_111359_create_club_transitions_table',1),
(36,'2025_12_23_132006_add_match_tracking_fields',1),
(37,'2025_12_23_133213_make_matches_created_by_nullable',1),
(38,'2025_12_23_160000_add_step_tracking_to_scraper_runs_table',1),
(39,'2026_01_23_071913_add_user_fullname_to_users_table',1),
(40,'2026_01_23_120000_add_popup_scraper_fields_to_scraped_tables',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',999);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=109715 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2026-02-02 08:34:07','2026-02-02 08:34:07'),
(2,'Manager','web','2026-02-02 08:34:07','2026-02-02 08:34:07'),
(3,'User','web','2026-02-02 08:34:07','2026-02-02 08:34:07');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `opponent_name` varchar(255) DEFAULT NULL,
  `result` varchar(1) DEFAULT NULL,
  `opponent_points` int(11) DEFAULT NULL,
  `match_points` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `scraped_month` varchar(7) DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `ranking_date` date DEFAULT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_diff` varchar(255) DEFAULT NULL,
  `rmld_id` varchar(255) DEFAULT NULL,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_ranking_id` bigint(20) unsigned DEFAULT NULL,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  KEY `scraped_rankings_synced_ranking_id_foreign` (`synced_ranking_id`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_ranking_id_foreign` FOREIGN KEY (`synced_ranking_id`) REFERENCES `monthly_rankings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3679 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
INSERT INTO `scraper_logs` VALUES
(3458,10,'info','Starting: Creating Database Backup','[]','2026-02-02 09:42:58','2026-02-02 09:42:58'),
(3459,10,'info','Completed: Creating Database Backup (in 0.14s)','[]','2026-02-02 09:42:58','2026-02-02 09:42:58'),
(3460,10,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:42:58','2026-02-02 09:42:58'),
(3461,11,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3462,11,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3463,11,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'1\'','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3464,11,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3465,11,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3466,11,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3467,11,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3468,11,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3469,10,'info','Completed: Scraping Rankings & Matches (Male) (in 1.01s)','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3470,10,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3471,12,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3472,12,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3473,12,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'1\'','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3474,12,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3475,12,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3476,12,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3477,12,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3478,12,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3479,10,'info','Completed: Scraping Rankings & Matches (Female) (in 1.00s)','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3480,10,'info','Starting: Syncing Rankings','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3481,10,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3482,10,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3483,10,'info','Completed: Syncing Rankings (in 0.03s)','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3484,10,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3485,10,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3486,10,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3487,10,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3488,10,'info','Completed: Creating Monthly Rankings (in 0.00s)','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3489,10,'info','Starting: Syncing Matches','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3490,10,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3491,10,'info','Marking unofficial matches...','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3492,10,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3493,10,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3494,10,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3495,13,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3496,13,'info','Starting series scrape','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3497,13,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3498,14,'info','Starting: Creating Database Backup','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3499,14,'info','Completed: Creating Database Backup (in 0.14s)','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3500,14,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3501,15,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3502,15,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3503,15,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'1\'','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3504,15,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3505,15,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3506,15,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3507,15,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3508,15,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3509,14,'info','Completed: Scraping Rankings & Matches (Male) (in 1.01s)','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3510,14,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3511,16,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3512,16,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3513,16,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'1\'','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3514,16,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3515,16,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3516,16,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3517,16,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3518,16,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3519,14,'info','Completed: Scraping Rankings & Matches (Female) (in 1.00s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3520,14,'info','Starting: Syncing Rankings','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3521,14,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3522,14,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3523,14,'info','Completed: Syncing Rankings (in 0.03s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3524,14,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3525,14,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3526,14,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3527,14,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3528,14,'info','Completed: Creating Monthly Rankings (in 0.00s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3529,14,'info','Starting: Syncing Matches','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3530,14,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3531,14,'info','Marking unofficial matches...','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3532,14,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3533,14,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3534,14,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3535,17,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3536,17,'info','Starting series scrape','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3537,17,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:47:47','2026-02-02 09:47:47'),
(3538,18,'info','Starting: Creating Database Backup','[]','2026-02-02 09:52:41','2026-02-02 09:52:41'),
(3539,18,'info','Completed: Creating Database Backup (in 0.15s)','[]','2026-02-02 09:52:41','2026-02-02 09:52:41'),
(3540,18,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:52:41','2026-02-02 09:52:41'),
(3541,19,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3542,19,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3543,19,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'111\'','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3544,19,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3545,19,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3546,19,'info','Python: asyncio.run(main())','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3547,19,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3548,19,'info','Python:     return runner.run(main)','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3549,19,'info','Python:            ^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3550,19,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3551,19,'info','Python:     return self._loop.run_until_complete(task)','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3552,19,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3553,19,'info','Python:   File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3554,19,'info','Python:     return future.result()','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3555,19,'info','Python:            ^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3556,19,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3557,19,'info','Python:     result = await scraper.run()','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3558,19,'info','Python:              ^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3559,19,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3560,19,'info','Python:     self.browser = await p.chromium.launch(','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3561,19,'info','Python:                    ^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3562,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3563,19,'info','Python:     await self._impl_obj.launch(','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3564,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3565,19,'info','Python:     Browser, from_channel(await self._channel.send(\"launch\", params))','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3566,19,'info','Python:                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3567,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3568,19,'info','Python:     return await self._connection.wrap_api_call(','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3569,19,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3570,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3571,19,'info','Python:     raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3572,19,'info','Python: playwright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3573,19,'info','Python: ╔════════════════════════════════════════════════════════════╗','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3574,19,'info','Python: ║ Looks like Playwright was just installed or updated.       ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3575,19,'info','Python: ║ Please run the following command to download new browsers: ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3576,19,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3577,19,'info','Python: ║     playwright install                                     ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3578,19,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3579,19,'info','Python: ║ <3 Playwright Team                                         ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3580,19,'info','Python: ╚════════════════════════════════════════════════════════════╝','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3581,19,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 449, in <module>\\n    asyncio.run(main())\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 190, in run\\n    return runner.run(main)\\n           ^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 118, in run\\n    return self._loop.run_until_complete(task)\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/base_events.py\\\", line 653, in run_until_complete\\n    return future.result()\\n           ^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 442, in main\\n    result = await scraper.run()\\n             ^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 64, in run\\n    self.browser = await p.chromium.launch(\\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/async_api\\/_generated.py\\\", line 14398, in launch\\n    await self._impl_obj.launch(\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_browser_type.py\\\", line 95, in launch\\n    Browser, from_channel(await self._channel.send(\\\"launch\\\", params))\\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 59, in send\\n    return await self._connection.wrap_api_call(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 520, in wrap_api_call\\n    raise rewrite_error(error, f\\\"{parsed_st[\'apiName\']}: {error}\\\") from None\\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at \\/home\\/webook\\/.cache\\/ms-playwright\\/chromium-1140\\/chrome-linux\\/chrome\\n\\u2554\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2557\\n\\u2551 Looks like Playwright was just installed or updated.       \\u2551\\n\\u2551 Please run the following command to download new browsers: \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551     playwright install                                     \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551 <3 Playwright Team                                         \\u2551\\n\\u255a\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u255d\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3582,18,'info','Completed: Scraping Rankings & Matches (Male) (in 2.01s)','[]','2026-02-02 09:52:43','2026-02-02 09:52:43'),
(3583,18,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:52:43','2026-02-02 09:52:43'),
(3584,20,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3585,20,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3586,20,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'111\'','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3587,20,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3588,20,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3589,20,'info','Python: asyncio.run(main())','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3590,20,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3591,20,'info','Python:     return runner.run(main)','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3592,20,'info','Python:            ^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3593,20,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3594,20,'info','Python:     return self._loop.run_until_complete(task)','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3595,20,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3596,20,'info','Python:   File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3597,20,'info','Python:     return future.result()','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3598,20,'info','Python:            ^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3599,20,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3600,20,'info','Python:     result = await scraper.run()','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3601,20,'info','Python:              ^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3602,20,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3603,20,'info','Python:     self.browser = await p.chromium.launch(','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3604,20,'info','Python:                    ^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3605,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3606,20,'info','Python:     await self._impl_obj.launch(','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3607,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3608,20,'info','Python:     Browser, from_channel(await self._channel.send(\"launch\", params))','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3609,20,'info','Python:                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3610,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3611,20,'info','Python:     return await self._connection.wrap_api_call(','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3612,20,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3613,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3614,20,'info','Python:     raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3615,20,'info','Python: playwright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3616,20,'info','Python: ╔════════════════════════════════════════════════════════════╗','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3617,20,'info','Python: ║ Looks like Playwright was just installed or updated.       ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3618,20,'info','Python: ║ Please run the following command to download new browsers: ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3619,20,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3620,20,'info','Python: ║     playwright install                                     ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3621,20,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3622,20,'info','Python: ║ <3 Playwright Team                                         ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3623,20,'info','Python: ╚════════════════════════════════════════════════════════════╝','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3624,20,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 449, in <module>\\n    asyncio.run(main())\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 190, in run\\n    return runner.run(main)\\n           ^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 118, in run\\n    return self._loop.run_until_complete(task)\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/base_events.py\\\", line 653, in run_until_complete\\n    return future.result()\\n           ^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 442, in main\\n    result = await scraper.run()\\n             ^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 64, in run\\n    self.browser = await p.chromium.launch(\\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/async_api\\/_generated.py\\\", line 14398, in launch\\n    await self._impl_obj.launch(\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_browser_type.py\\\", line 95, in launch\\n    Browser, from_channel(await self._channel.send(\\\"launch\\\", params))\\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 59, in send\\n    return await self._connection.wrap_api_call(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 520, in wrap_api_call\\n    raise rewrite_error(error, f\\\"{parsed_st[\'apiName\']}: {error}\\\") from None\\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at \\/home\\/webook\\/.cache\\/ms-playwright\\/chromium-1140\\/chrome-linux\\/chrome\\n\\u2554\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2557\\n\\u2551 Looks like Playwright was just installed or updated.       \\u2551\\n\\u2551 Please run the following command to download new browsers: \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551     playwright install                                     \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551 <3 Playwright Team                                         \\u2551\\n\\u255a\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u255d\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3625,18,'info','Completed: Scraping Rankings & Matches (Female) (in 2.01s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3626,18,'info','Starting: Syncing Rankings','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3627,18,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3628,18,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3629,18,'info','Completed: Syncing Rankings (in 0.04s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3630,18,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3631,18,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3632,18,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3633,18,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3634,18,'info','Completed: Creating Monthly Rankings (in 0.01s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3635,18,'info','Starting: Syncing Matches','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3636,18,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3637,18,'info','Marking unofficial matches...','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3638,18,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3639,18,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3640,18,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3641,21,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:52:46','2026-02-02 09:52:46'),
(3642,21,'info','Starting series scrape','[]','2026-02-02 09:52:46','2026-02-02 09:52:46'),
(3643,21,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:52:46','2026-02-02 09:52:46'),
(3644,22,'info','Starting: Creating Database Backup','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3645,22,'info','Completed: Creating Database Backup (in 0.17s)','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3646,22,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3647,23,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3648,23,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3649,23,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'111\'','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3650,23,'info','Python: [ERROR] Fatal error: Month 2025.11.01 not found in dropdown','[]','2026-02-02 09:53:59','2026-02-02 09:53:59'),
(3651,23,'error','Scrape failed','{\"message\":\"Python scraper failed: [{\\\"error\\\":\\\"Month 2025.11.01 not found in dropdown\\\"}]\",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#1 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#3 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#9 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#11 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#16 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#17 {main}\"}','2026-02-02 09:53:59','2026-02-02 09:53:59'),
(3652,22,'info','Completed: Scraping Rankings & Matches (Male) (in 6.02s)','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3653,22,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3654,24,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3655,24,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3656,24,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'111\'','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3657,24,'info','Python: [ERROR] Fatal error: Month 2025.11.01 not found in dropdown','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3658,24,'error','Scrape failed','{\"message\":\"Python scraper failed: [{\\\"error\\\":\\\"Month 2025.11.01 not found in dropdown\\\"}]\",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#1 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#3 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#9 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#11 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#16 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#17 {main}\"}','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3659,22,'info','Completed: Scraping Rankings & Matches (Female) (in 5.02s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3660,22,'info','Starting: Syncing Rankings','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3661,22,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3662,22,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3663,22,'info','Completed: Syncing Rankings (in 0.04s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3664,22,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3665,22,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3666,22,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3667,22,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3668,22,'info','Completed: Creating Monthly Rankings (in 0.00s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3669,22,'info','Starting: Syncing Matches','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3670,22,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3671,22,'info','Marking unofficial matches...','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3672,22,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3673,22,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3674,22,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3675,25,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:54:06','2026-02-02 09:54:06'),
(3676,25,'info','Starting series scrape','[]','2026-02-02 09:54:06','2026-02-02 09:54:06'),
(3677,25,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:54:06','2026-02-02 09:54:06'),
(3678,26,'info','Starting: Creating Database Backup','[]','2026-02-02 09:56:47','2026-02-02 09:56:47');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `current_step` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `steps_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`steps_data`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
INSERT INTO `scraper_runs` VALUES
(10,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.1393117904663086,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-42-58.zip\"},\"completed_at\":\"2026-02-02 10:42:58\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":1.0078339576721191,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:42:59\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":1.0035429000854492,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:43:00\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.031646013259887695,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:43:01\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.004102945327758789,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:43:01\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.01198720932006836,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:43:01\"}}',0,0,NULL,'2026-02-02 09:42:58',NULL,'2026-02-02 09:42:58','2026-02-02 09:43:01'),
(11,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:42:59','2026-02-02 09:42:59','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(12,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:43:00','2026-02-02 09:43:00','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(13,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:43:01',NULL,'2026-02-02 09:43:01','2026-02-02 09:43:01'),
(14,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.142409086227417,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-47-44.zip\"},\"completed_at\":\"2026-02-02 10:47:44\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":1.0111920833587646,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:47:45\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":1.0043950080871582,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:47:46\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.03190207481384277,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:47:46\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.00392603874206543,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:47:46\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.01106405258178711,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:47:46\"}}',0,0,NULL,'2026-02-02 09:47:44',NULL,'2026-02-02 09:47:44','2026-02-02 09:47:46'),
(15,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:47:44','2026-02-02 09:47:44','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(16,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:47:45','2026-02-02 09:47:45','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(17,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:47:46',NULL,'2026-02-02 09:47:46','2026-02-02 09:47:46'),
(18,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.15445494651794434,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-52-41.zip\"},\"completed_at\":\"2026-02-02 10:52:41\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":2.0106899738311768,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:52:43\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":2.007002115249634,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:52:45\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.03700900077819824,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:52:45\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.008775949478149414,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:52:45\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.010875940322875977,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:52:45\"}}',0,0,NULL,'2026-02-02 09:52:41',NULL,'2026-02-02 09:52:41','2026-02-02 09:52:45'),
(19,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>\n    asyncio.run(main())\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run\n    return runner.run(main)\n           ^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run\n    return self._loop.run_until_complete(task)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete\n    return future.result()\n           ^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main\n    result = await scraper.run()\n             ^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run\n    self.browser = await p.chromium.launch(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch\n    await self._impl_obj.launch(\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch\n    Browser, from_channel(await self._channel.send(\"launch\", params))\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send\n    return await self._connection.wrap_api_call(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call\n    raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome\n╔════════════════════════════════════════════════════════════╗\n║ Looks like Playwright was just installed or updated.       ║\n║ Please run the following command to download new browsers: ║\n║                                                            ║\n║     playwright install                                     ║\n║                                                            ║\n║ <3 Playwright Team                                         ║\n╚════════════════════════════════════════════════════════════╝\n\nStandard Output: ','2026-02-02 09:52:42','2026-02-02 09:52:42','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(20,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>\n    asyncio.run(main())\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run\n    return runner.run(main)\n           ^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run\n    return self._loop.run_until_complete(task)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete\n    return future.result()\n           ^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main\n    result = await scraper.run()\n             ^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run\n    self.browser = await p.chromium.launch(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch\n    await self._impl_obj.launch(\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch\n    Browser, from_channel(await self._channel.send(\"launch\", params))\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send\n    return await self._connection.wrap_api_call(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call\n    raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome\n╔════════════════════════════════════════════════════════════╗\n║ Looks like Playwright was just installed or updated.       ║\n║ Please run the following command to download new browsers: ║\n║                                                            ║\n║     playwright install                                     ║\n║                                                            ║\n║ <3 Playwright Team                                         ║\n╚════════════════════════════════════════════════════════════╝\n\nStandard Output: ','2026-02-02 09:52:44','2026-02-02 09:52:44','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(21,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:52:46',NULL,'2026-02-02 09:52:46','2026-02-02 09:52:46'),
(22,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.1693129539489746,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-53-54.zip\"},\"completed_at\":\"2026-02-02 10:53:54\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":6.0218141078948975,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:54:00\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":5.017053127288818,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:54:05\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.03749394416809082,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:54:05\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.004302978515625,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:54:05\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.008448123931884766,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:54:05\"}}',0,0,NULL,'2026-02-02 09:53:54',NULL,'2026-02-02 09:53:54','2026-02-02 09:54:05'),
(23,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}',NULL,0,0,'Python scraper failed: [{\"error\":\"Month 2025.11.01 not found in dropdown\"}]','2026-02-02 09:53:54','2026-02-02 09:53:59','2026-02-02 09:53:54','2026-02-02 09:53:59'),
(24,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}',NULL,0,0,'Python scraper failed: [{\"error\":\"Month 2025.11.01 not found in dropdown\"}]','2026-02-02 09:54:00','2026-02-02 09:54:05','2026-02-02 09:54:00','2026-02-02 09:54:05'),
(25,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:54:06',NULL,'2026-02-02 09:54:06','2026-02-02 09:54:06'),
(26,'full_scrape','Step 1/7: Creating Database Backup','running','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}',NULL,0,0,NULL,'2026-02-02 09:56:47',NULL,'2026-02-02 09:56:47','2026-02-02 09:56:47');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php','string','urls','URL for players list scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `monitored_user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_monitors_user_id_monitored_user_id_unique` (`user_id`,`monitored_user_id`),
  KEY `user_monitors_monitored_user_id_foreign` (`monitored_user_id`),
  CONSTRAINT `user_monitors_monitored_user_id_foreign` FOREIGN KEY (`monitored_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_monitors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_monitors` WRITE;
/*!40000 ALTER TABLE `user_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_monitors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` uuid NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_fullname` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `birth_year` int(11) DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `sbtf_player_id` varchar(255) DEFAULT NULL,
  `sbtf_synced` tinyint(1) NOT NULL DEFAULT 0,
  `sbtf_synced_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 0,
  `is_active_player` tinyint(1) NOT NULL DEFAULT 1,
  `accepts_push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  KEY `users_club_id_foreign` (`club_id`),
  KEY `users_player_match_index` (`last_name`,`first_name`,`birth_year`),
  KEY `users_sbtf_player_id_index` (`sbtf_player_id`),
  CONSTRAINT `users_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(999,'b0975171-01a8-40d8-8ca6-4220270960ab','Damjan','damjan','Damjan damjan',NULL,'damjan@weboook.co.uk',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,'2026-01-30 08:42:38',1,0,0,NULL,NULL,'$2y$12$PTOPxcTlMoB9OD2fpZqX8e5CpjP3hjvKZU00ePNU8K1o38Z7og1BC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-30 08:42:19','2026-01-30 08:42:19','2026-01-30 08:42:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

