/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` enum('top_sticky','bottom_sticky','top','bottom','within_page','random','popup') NOT NULL DEFAULT 'top',
  `views` bigint(20) unsigned NOT NULL DEFAULT 0,
  `clicks` bigint(20) unsigned NOT NULL DEFAULT 0,
  `locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`locations`)),
  `link` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','scheduled') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES
(1,'Summer Tournament 2025','assets/images/landing/lastsect.png','top_sticky',1250,89,'[\"home\",\"matches\"]','https://example.com/summer-tournament','2025-11-14','2025-12-14','active','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(2,'Premium Membership','assets/images/landing/lefthero-deskt.png','bottom_sticky',3420,156,'[\"players\",\"bubbler\"]','https://example.com/premium','2025-10-25','2026-01-23','active','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(3,'New Racket Collection','assets/images/landing/pingpong.png','top',919,45,'[\"home\",\"clubs\"]','https://example.com/rackets','2025-11-24','2025-12-08','active','2025-11-24 08:36:01','2025-11-24 10:46:11'),
(4,'Winter League Registration','assets/images/landing/righthero-deskt.png','popup',2100,312,NULL,'https://example.com/winter-league','2025-11-29','2026-01-08','scheduled','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(5,'Club Sponsorship','assets/images/landing/iPhone12left.png','within_page',567,23,'[\"clubs\"]','https://example.com/sponsors','2025-11-19','2025-12-19','active','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(6,'Training Sessions','assets/images/landing/iPhone12right2.png','bottom',2459,80,'[\"matches\",\"players\"]','https://example.com/training',NULL,NULL,'active','2025-11-24 08:36:01','2026-01-28 14:06:29'),
(7,'Old Campaign','assets/images/landing/badge-appStore.png','random',4500,234,'[\"home\"]','https://example.com/old-campaign','2025-09-25','2025-10-25','inactive','2025-11-24 08:36:01','2025-11-24 08:36:01'),
(8,'App Download','assets/images/landing/badge-PlayStore.png','bottom_sticky',780,92,'[\"settings\",\"profile\"]','https://example.com/app','2025-11-09','2026-01-08','active','2025-11-24 08:36:01','2025-11-24 08:36:01');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iracket-cache-2f9ab20d6a694006c577eb20c2c958fd','i:1;',1769610979),
('iracket-cache-2f9ab20d6a694006c577eb20c2c958fd:timer','i:1769610979;',1769610979),
('iracket-cache-damjan@webook.co.uk|172.18.0.5','i:1;',1769548053),
('iracket-cache-damjan@webook.co.uk|172.18.0.5:timer','i:1769548053;',1769548053),
('iracket-cache-damjan@weboook.co.uk|172.18.0.5','i:1;',1769610979),
('iracket-cache-damjan@weboook.co.uk|172.18.0.5:timer','i:1769610979;',1769610979),
('iracket-cache-faaa644be9435742677c8cfb220a3e86','i:1;',1769548053),
('iracket-cache-faaa644be9435742677c8cfb220a3e86:timer','i:1769548053;',1769548053),
('iracket-cache-scraper_setting_schedule_export_day','N;',1769617176),
('iracket-cache-scraper_setting_schedule_export_enabled','N;',1769617176),
('iracket-cache-scraper_setting_schedule_export_time','N;',1769617176),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1769616810);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `from_club_id` bigint(20) unsigned DEFAULT NULL,
  `to_club_id` bigint(20) unsigned DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `born` date DEFAULT NULL,
  `from_club_name` varchar(255) DEFAULT NULL,
  `to_club_name` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `club_transitions_to_club_id_completion_date_index` (`to_club_id`,`completion_date`),
  KEY `club_transitions_from_club_id_completion_date_index` (`from_club_id`,`completion_date`),
  KEY `club_transitions_user_id_index` (`user_id`),
  CONSTRAINT `club_transitions_from_club_id_foreign` FOREIGN KEY (`from_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_to_club_id_foreign` FOREIGN KEY (`to_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_transitions` WRITE;
/*!40000 ALTER TABLE `club_transitions` DISABLE KEYS */;
INSERT INTO `club_transitions` VALUES
(1,'Licens 2025-26',NULL,NULL,NULL,'Eriksson','Johan','1992-07-06','Västerås Padel Club','Helsingborg Racket & Fitness','2025-12-09',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(2,'Licens 2025-26',NULL,NULL,NULL,'Nilsson','Maria','1992-04-02','Uppsala Squash Center','Örebro Tennis Society','2025-12-27',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(3,'Licens 2025-26',NULL,NULL,NULL,'Gustafsson','Emma','1991-05-08','Linköping Racket Arena','Malmö Badminton Club','2025-10-04',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(4,'Licens 2025-26',NULL,NULL,NULL,'Svensson','Per','1997-02-11','Örebro Tennis Society','Stockholm Racket Club','2026-01-11',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(5,'Licens 2025-26',NULL,NULL,NULL,'Persson','Karin','1986-01-03','Örebro Tennis Society','Uppsala Squash Center','2025-12-17',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(6,'Licens 2025-26',NULL,NULL,NULL,'Eriksson','Johan','1998-03-14','Örebro Tennis Society','Västerås Padel Club','2025-12-18',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(7,'Licens 2025-26',NULL,NULL,NULL,'Hansson','Anna','1992-08-15','Örebro Tennis Society','Linköping Racket Arena','2025-12-03',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(8,'Licens 2025-26',NULL,NULL,NULL,'Persson','Karin','1991-12-22','Helsingborg Racket & Fitness','Västerås Padel Club','2025-10-13',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(9,'Licens 2025-26',NULL,NULL,NULL,'Karlsson','Lars','1981-09-17','Malmö Badminton Club','Stockholm Racket Club','2025-10-01',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(10,'Licens 2025-26',NULL,NULL,NULL,'Karlsson','Lars','1994-05-13','Linköping Racket Arena','Uppsala Squash Center','2026-01-13',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(11,'Licens 2025-26',NULL,NULL,NULL,'Andersson','Oscar','2003-10-20','Linköping Racket Arena','Örebro Tennis Society','2025-12-31',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(12,'Licens 2025-26',NULL,NULL,NULL,'Larsson','Eva','2007-01-27','Helsingborg Racket & Fitness','Uppsala Squash Center','2025-11-06',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(13,'Licens 2025-26',NULL,NULL,NULL,'Karlsson','Lars','1997-03-11','Stockholm Racket Club','Göteborg Tennis & Padel','2025-09-02',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(14,'Licens 2025-26',NULL,NULL,NULL,'Persson','Karin','1989-12-26','Linköping Racket Arena','Malmö Badminton Club','2025-09-11',0,'2025-11-24 10:21:10','2025-11-24 10:21:10'),
(15,'Licens 2025-26',NULL,NULL,NULL,'Svensson','Per','2004-07-16','Uppsala Squash Center','Stockholm Racket Club','2025-11-10',0,'2025-11-24 10:21:10','2025-11-24 10:21:10');
/*!40000 ALTER TABLE `club_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=563 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES
(1,'Andrej Gjoshevski','info@weboook.co.uk','test hhhhhhhhhhh','replied','2025-11-23 07:16:34',NULL,'oooookookokokokokokokokok','2025-11-23 07:16:19','2025-11-23 07:16:34');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES
(5,'666b60b7-01ec-4d68-8050-a9224ce61688','database','default','{\"uuid\":\"666b60b7-01ec-4d68-8050-a9224ce61688\",\"displayName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":1,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":14400,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"command\":\"O:30:\\\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\\\":4:{s:7:\\\"timeout\\\";i:14400;s:10:\\\"\\u0000*\\u0000command\\\";s:13:\\\"scraper:start\\\";s:13:\\\"\\u0000*\\u0000parameters\\\";a:1:{s:5:\\\"month\\\";s:7:\\\"2025-12\\\";}s:10:\\\"\\u0000*\\u0000options\\\";a:1:{s:7:\\\"--force\\\";b:1;}}\"},\"createdAt\":1767181476,\"delay\":null}','Illuminate\\Queue\\MaxAttemptsExceededException: App\\Jobs\\Scraper\\RunScraperJob has been attempted too many times. in /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/MaxAttemptsExceededException.php:24\nStack trace:\n#0 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(817): Illuminate\\Queue\\MaxAttemptsExceededException::forJob()\n#1 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(537): Illuminate\\Queue\\Worker->maxAttemptsExceededException()\n#2 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(440): Illuminate\\Queue\\Worker->markJobAsFailedIfAlreadyExceedsMaxAttempts()\n#3 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(401): Illuminate\\Queue\\Worker->process()\n#4 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(187): Illuminate\\Queue\\Worker->runJob()\n#5 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#6 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#7 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#8 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#9 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#10 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#11 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/Container.php(836): Illuminate\\Container\\BoundMethod::call()\n#12 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Console/Command.php(211): Illuminate\\Container\\Container->call()\n#13 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute()\n#14 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Console/Command.php(180): Symfony\\Component\\Console\\Command\\Command->run()\n#15 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(1073): Illuminate\\Console\\Command->run()\n#16 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#17 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#18 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(197): Symfony\\Component\\Console\\Application->run()\n#19 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#20 /home/iracket/domains/dev.iracket.se/public_html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#21 {main}','2025-12-31 10:46:06'),
(6,'ccbecfd4-6db2-441f-9260-9a9ae4f47be4','database','default','{\"uuid\":\"ccbecfd4-6db2-441f-9260-9a9ae4f47be4\",\"displayName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":1,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":7200,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"command\":\"O:30:\\\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\\\":3:{s:10:\\\"\\u0000*\\u0000command\\\";s:13:\\\"scraper:start\\\";s:13:\\\"\\u0000*\\u0000parameters\\\";a:1:{s:5:\\\"month\\\";s:7:\\\"2025-12\\\";}s:10:\\\"\\u0000*\\u0000options\\\";a:3:{s:15:\\\"--limit-periods\\\";s:1:\\\"1\\\";s:11:\\\"--no-backup\\\";b:1;s:7:\\\"--force\\\";b:1;}}\"},\"createdAt\":1767182304,\"delay\":null}','Illuminate\\Queue\\MaxAttemptsExceededException: App\\Jobs\\Scraper\\RunScraperJob has been attempted too many times. in /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/MaxAttemptsExceededException.php:24\nStack trace:\n#0 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(817): Illuminate\\Queue\\MaxAttemptsExceededException::forJob()\n#1 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(537): Illuminate\\Queue\\Worker->maxAttemptsExceededException()\n#2 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(440): Illuminate\\Queue\\Worker->markJobAsFailedIfAlreadyExceedsMaxAttempts()\n#3 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(401): Illuminate\\Queue\\Worker->process()\n#4 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(187): Illuminate\\Queue\\Worker->runJob()\n#5 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#6 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#7 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#8 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::{closure:Illuminate\\Container\\BoundMethod::call():35}()\n#9 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#10 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#11 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/Container.php(836): Illuminate\\Container\\BoundMethod::call()\n#12 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Console/Command.php(211): Illuminate\\Container\\Container->call()\n#13 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute()\n#14 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Console/Command.php(180): Symfony\\Component\\Console\\Command\\Command->run()\n#15 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(1073): Illuminate\\Console\\Command->run()\n#16 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#17 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#18 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(197): Symfony\\Component\\Console\\Application->run()\n#19 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#20 /home/iracket/domains/dev.iracket.se/public_html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#21 {main}','2025-12-31 10:59:54'),
(7,'a96adaca-4765-42a9-a44b-9fcfc4336e0f','database','default','{\"uuid\":\"a96adaca-4765-42a9-a44b-9fcfc4336e0f\",\"displayName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":1,\"maxExceptions\":null,\"failOnTimeout\":false,\"backoff\":null,\"timeout\":7200,\"retryUntil\":null,\"data\":{\"commandName\":\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\",\"command\":\"O:30:\\\"App\\\\Jobs\\\\Scraper\\\\RunScraperJob\\\":3:{s:10:\\\"\\u0000*\\u0000command\\\";s:13:\\\"scraper:start\\\";s:13:\\\"\\u0000*\\u0000parameters\\\";a:1:{s:5:\\\"month\\\";s:7:\\\"2025-12\\\";}s:10:\\\"\\u0000*\\u0000options\\\";a:3:{s:15:\\\"--limit-periods\\\";s:1:\\\"1\\\";s:11:\\\"--no-backup\\\";b:1;s:7:\\\"--force\\\";b:1;}}\"},\"createdAt\":1767188826,\"delay\":null}','Illuminate\\Queue\\MaxAttemptsExceededException: App\\Jobs\\Scraper\\RunScraperJob has been attempted too many times. in /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/MaxAttemptsExceededException.php:24\nStack trace:\n#0 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(817): Illuminate\\Queue\\MaxAttemptsExceededException::forJob()\n#1 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(537): Illuminate\\Queue\\Worker->maxAttemptsExceededException()\n#2 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(440): Illuminate\\Queue\\Worker->markJobAsFailedIfAlreadyExceedsMaxAttempts()\n#3 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(401): Illuminate\\Queue\\Worker->process()\n#4 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(187): Illuminate\\Queue\\Worker->runJob()\n#5 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(148): Illuminate\\Queue\\Worker->daemon()\n#6 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(131): Illuminate\\Queue\\Console\\WorkCommand->runWorker()\n#7 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#8 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#9 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(96): Illuminate\\Container\\Util::unwrapIfClosure()\n#10 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod()\n#11 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Container/Container.php(836): Illuminate\\Container\\BoundMethod::call()\n#12 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Console/Command.php(211): Illuminate\\Container\\Container->call()\n#13 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute()\n#14 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Console/Command.php(180): Symfony\\Component\\Console\\Command\\Command->run()\n#15 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(1073): Illuminate\\Console\\Command->run()\n#16 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(356): Symfony\\Component\\Console\\Application->doRunCommand()\n#17 /home/iracket/domains/dev.iracket.se/public_html/vendor/symfony/console/Application.php(195): Symfony\\Component\\Console\\Application->doRun()\n#18 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(197): Symfony\\Component\\Console\\Application->run()\n#19 /home/iracket/domains/dev.iracket.se/public_html/vendor/laravel/framework/src/Illuminate/Foundation/Application.php(1235): Illuminate\\Foundation\\Console\\Kernel->handle()\n#20 /home/iracket/domains/dev.iracket.se/public_html/artisan(16): Illuminate\\Foundation\\Application->handleCommand()\n#21 {main}','2025-12-31 12:48:37');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source` enum('player_added','scraped') NOT NULL DEFAULT 'player_added',
  `is_unofficial` tinyint(1) NOT NULL DEFAULT 0,
  `uuid` char(36) NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `player1_points_before` int(11) DEFAULT NULL,
  `player2_points_before` int(11) DEFAULT NULL,
  `player1_points_change` int(11) DEFAULT NULL,
  `player2_points_change` int(11) DEFAULT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `is_manual` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `replaced_by_match_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  KEY `matches_replaced_by_match_id_foreign` (`replaced_by_match_id`),
  KEY `match_lookup` (`player1_id`,`player2_id`,`played_at`,`deleted_at`),
  KEY `matches_is_unofficial_index` (`is_unofficial`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_replaced_by_match_id_foreign` FOREIGN KEY (`replaced_by_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',2),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',3),
(10,'2025_11_22_173439_create_notifications_table',3),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',3),
(12,'2025_11_22_174607_add_age_to_users_table',4),
(13,'2025_11_22_180425_create_clubs_table',5),
(14,'2025_11_22_180426_create_matches_table',5),
(15,'2025_11_22_180426_create_monthly_rankings_table',5),
(16,'2025_11_22_180427_add_club_id_to_users_table',6),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',6),
(18,'2025_11_22_180433_create_permission_tables',6),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',7),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',8),
(21,'2025_11_22_183254_add_uuid_to_users_table',8),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',8),
(23,'2025_11_22_183655_make_terms_translatable',9),
(24,'2025_11_22_231254_create_scraper_tables',10),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',11),
(26,'2025_11_23_074902_add_icon_to_notifications_table',12),
(27,'2025_11_23_090000_create_contacts_table',13),
(28,'2025_11_23_084421_create_scraper_settings_table',14),
(29,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',15),
(30,'2025_11_23_103307_add_sbtf_player_fields_to_users_table',16),
(31,'2025_11_24_091012_create_banners_table',17),
(32,'2025_11_24_094538_create_user_monitors_table',18),
(33,'2025_11_24_102243_add_connection_fields_to_users_table',19),
(34,'2025_11_24_105000_add_points_tracking_to_matches_table',20),
(35,'2025_11_24_111359_create_club_transitions_table',21),
(36,'2025_12_23_132006_add_match_tracking_fields',22),
(37,'2025_12_23_133213_make_matches_created_by_nullable',22),
(38,'2025_12_23_160000_add_step_tracking_to_scraper_runs_table',22),
(39,'2026_01_23_071913_add_user_fullname_to_users_table',23),
(40,'2026_01_23_120000_add_popup_scraper_fields_to_scraped_tables',23);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',2),
(1,'App\\Models\\User',858);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2798 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES
('info@weboook.co.uk','$2y$12$TiwjkawXM3WHokKG4y25P.ODxbWdgf/q0WTUMm3oqSkVA4/HOAIQG','2025-12-12 12:44:46');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2025-11-22 17:06:07','2025-11-22 17:06:07'),
(2,'Manager','web','2025-11-22 17:06:07','2025-11-22 17:06:07');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `opponent_name` varchar(255) DEFAULT NULL,
  `result` varchar(1) DEFAULT NULL,
  `opponent_points` int(11) DEFAULT NULL,
  `match_points` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `scraped_month` varchar(7) DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=70777 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `ranking_date` date DEFAULT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_diff` varchar(255) DEFAULT NULL,
  `rmld_id` varchar(255) DEFAULT NULL,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_ranking_id` bigint(20) unsigned DEFAULT NULL,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  KEY `scraped_rankings_synced_ranking_id_foreign` (`synced_ranking_id`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_ranking_id_foreign` FOREIGN KEY (`synced_ranking_id`) REFERENCES `monthly_rankings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4791 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1982 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13465 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
INSERT INTO `scraper_logs` VALUES
(13464,116,'info','Starting: Creating Database Backup','[]','2026-01-28 14:19:37','2026-01-28 14:19:37');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `current_step` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `steps_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`steps_data`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
INSERT INTO `scraper_runs` VALUES
(116,'full_scrape','Step 1/7: Creating Database Backup','running','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}',NULL,0,0,NULL,'2026-01-28 14:19:37',NULL,'2026-01-28 14:19:37','2026-01-28 14:19:37');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php?forb=SBTF.SE.BT','string','urls','URL for players list scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` VALUES
(1,'{\"en\":\"Terms and Conditions\"}','terms-and-conditions','{\"en\":\"\\n                <h1>Terms and Conditions<\\/h1>\\n                <p><strong>Last updated:<\\/strong> November 22, 2025<\\/p>\\n\\n                <h2>1. Acceptance of Terms<\\/h2>\\n                <p>By accessing and using iRacket, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.<\\/p>\\n\\n                <h2>2. Use License<\\/h2>\\n                <p>Permission is granted to temporarily use iRacket for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:<\\/p>\\n                <ul>\\n                    <li>modify or copy the materials;<\\/li>\\n                    <li>use the materials for any commercial purpose, or for any public display (commercial or non-commercial);<\\/li>\\n                    <li>attempt to decompile or reverse engineer any software contained on iRacket;<\\/li>\\n                    <li>remove any copyright or other proprietary notations from the materials; or<\\/li>\\n                    <li>transfer the materials to another person or \\\"mirror\\\" the materials on any other server.<\\/li>\\n                <\\/ul>\\n\\n                <h2>3. User Account<\\/h2>\\n                <p>To use certain features of iRacket, you must register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.<\\/p>\\n\\n                <h2>4. User Conduct<\\/h2>\\n                <p>You agree not to use iRacket to:<\\/p>\\n                <ul>\\n                    <li>Upload, post, or transmit any content that is unlawful, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, or otherwise objectionable;<\\/li>\\n                    <li>Impersonate any person or entity;<\\/li>\\n                    <li>Upload, post, or transmit any content that infringes any patent, trademark, trade secret, copyright, or other proprietary rights;<\\/li>\\n                    <li>Upload, post, or transmit any unsolicited or unauthorized advertising, promotional materials, or any other form of solicitation.<\\/li>\\n                <\\/ul>\\n\\n                <h2>5. Disclaimer<\\/h2>\\n                <p>The materials on iRacket are provided on an \\\"as is\\\" basis. iRacket makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.<\\/p>\\n\\n                <h2>6. Limitations<\\/h2>\\n                <p>In no event shall iRacket or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use iRacket.<\\/p>\\n\\n                <h2>7. Modifications<\\/h2>\\n                <p>iRacket may revise these terms of service at any time without notice. By using this application you are agreeing to be bound by the then current version of these terms of service.<\\/p>\\n\\n                <h2>8. Governing Law<\\/h2>\\n                <p>These terms and conditions are governed by and construed in accordance with the laws and you irrevocably submit to the exclusive jurisdiction of the courts in that location.<\\/p>\\n\\n                <h2>9. Contact Us<\\/h2>\\n                <p>If you have any questions about these Terms and Conditions, please contact us at support@iracket.com.<\\/p>\\n            \"}',1,'2025-11-22 16:05:42','2025-11-22 16:05:42'),
(2,'{\"en\":\"Privacy Policy\"}','privacy-policy','{\"en\":\"\\n                <h1>Privacy Policy<\\/h1>\\n                <p><strong>Last updated:<\\/strong> November 22, 2025<\\/p>\\n\\n                <h2>1. Introduction<\\/h2>\\n                <p>Welcome to iRacket. We respect your privacy and are committed to protecting your personal data. This privacy policy will inform you about how we look after your personal data and tell you about your privacy rights.<\\/p>\\n\\n                <h2>2. Information We Collect<\\/h2>\\n                <p>We may collect, use, store and transfer different kinds of personal data about you which we have grouped together as follows:<\\/p>\\n                <ul>\\n                    <li><strong>Identity Data<\\/strong> includes first name, last name, username or similar identifier.<\\/li>\\n                    <li><strong>Contact Data<\\/strong> includes email address and telephone numbers.<\\/li>\\n                    <li><strong>Technical Data<\\/strong> includes internet protocol (IP) address, your login data, browser type and version, time zone setting and location.<\\/li>\\n                    <li><strong>Profile Data<\\/strong> includes your username and password, your interests, preferences, feedback and survey responses.<\\/li>\\n                    <li><strong>Usage Data<\\/strong> includes information about how you use our website and services.<\\/li>\\n                <\\/ul>\\n\\n                <h2>3. How We Use Your Information<\\/h2>\\n                <p>We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:<\\/p>\\n                <ul>\\n                    <li>To register you as a new customer.<\\/li>\\n                    <li>To process and deliver your service.<\\/li>\\n                    <li>To manage our relationship with you.<\\/li>\\n                    <li>To improve our website, products\\/services, marketing or customer relationships.<\\/li>\\n                    <li>To recommend products or services which may be of interest to you.<\\/li>\\n                <\\/ul>\\n\\n                <h2>4. Data Security<\\/h2>\\n                <p>We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your personal data to those employees, agents, contractors and other third parties who have a business need to know.<\\/p>\\n\\n                <h2>5. Data Retention<\\/h2>\\n                <p>We will only retain your personal data for as long as necessary to fulfil the purposes we collected it for, including for the purposes of satisfying any legal, accounting, or reporting requirements.<\\/p>\\n\\n                <h2>6. Your Legal Rights<\\/h2>\\n                <p>Under certain circumstances, you have rights under data protection laws in relation to your personal data, including the right to:<\\/p>\\n                <ul>\\n                    <li>Request access to your personal data.<\\/li>\\n                    <li>Request correction of your personal data.<\\/li>\\n                    <li>Request erasure of your personal data.<\\/li>\\n                    <li>Object to processing of your personal data.<\\/li>\\n                    <li>Request restriction of processing your personal data.<\\/li>\\n                    <li>Request transfer of your personal data.<\\/li>\\n                    <li>Right to withdraw consent.<\\/li>\\n                <\\/ul>\\n\\n                <h2>7. Third-Party Links<\\/h2>\\n                <p>This website may include links to third-party websites, plug-ins and applications. Clicking on those links or enabling those connections may allow third parties to collect or share data about you. We do not control these third-party websites and are not responsible for their privacy statements.<\\/p>\\n\\n                <h2>8. Cookies<\\/h2>\\n                <p>We use cookies to distinguish you from other users of our website. This helps us to provide you with a good experience when you browse our website and also allows us to improve our site.<\\/p>\\n\\n                <h2>9. Changes to This Privacy Policy<\\/h2>\\n                <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the \\\"Last updated\\\" date.<\\/p>\\n\\n                <h2>10. Contact Us<\\/h2>\\n                <p>If you have any questions about this Privacy Policy, please contact us at privacy@iracket.com.<\\/p>\\n            \"}',1,'2025-11-22 16:05:42','2025-11-22 16:05:42'),
(3,'{\"en\":\"Bubbler\"}','bubbler','{\"en\":\"\\n                    <h1>What is Bubbler?<\\/h1>\\n                    <p>Bubbler is about who was the best the previous month.<\\/p>\\n\\n                    <h2>How do you know if you\'ve been the best?<\\/h2>\\n                    <p>Well, it\'s about who got the most points the previous month, and it\'s the most points in their range.<\\/p>\\n\\n                    <p>The ranges are: 0-499, 500-999, 1000-1249, 1250-1499, 1500-1749, 1750-1999, 2000-2249, 2250 and up.<\\/p>\\n\\n                    <p>We show the top three in each segment and region. The default is within your own range and region.<\\/p>\\n\\n                    <h2>Interval for Women<\\/h2>\\n                    <ul>\\n                        <li><strong>Elite class:<\\/strong> At least 1750 points<\\/li>\\n                        <li><strong>Class 1:<\\/strong> 1500-1749 points<\\/li>\\n                        <li><strong>Class 2:<\\/strong> 1250-1499 points<\\/li>\\n                        <li><strong>Class 3:<\\/strong> 1000-1249 points<\\/li>\\n                        <li><strong>Class 4:<\\/strong> 750-999 points<\\/li>\\n                        <li><strong>Class 5:<\\/strong> Maximum 749 points<\\/li>\\n                    <\\/ul>\\n\\n                    <h2>Interval for Men<\\/h2>\\n                    <ul>\\n                        <li><strong>Elite:<\\/strong> At least 2250 points<\\/li>\\n                        <li><strong>Class 1:<\\/strong> 2000-2249 points<\\/li>\\n                        <li><strong>Class 2:<\\/strong> 1750-1999 points<\\/li>\\n                        <li><strong>Class 3:<\\/strong> 1500-1749 points<\\/li>\\n                        <li><strong>Class 4:<\\/strong> 1250-1499 points<\\/li>\\n                        <li><strong>Class 5:<\\/strong> 1000-1249 points<\\/li>\\n                        <li><strong>Class 6:<\\/strong> 750-999 points<\\/li>\\n                        <li><strong>Class 7:<\\/strong> Maximum 749 points<\\/li>\\n                    <\\/ul>\\n\\n                    <p>If you get, for example, 100 points one month and go over the range, you will appear in your previous range.<\\/p>\\n\\n                    <p>Bubblers are simply different lists based on rankings combined with gender, age, geography, etc. We want to build a number of lists that we publish on different pages.<\\/p>\\n\\n                    <h2>How Points are Calculated<\\/h2>\\n                    <p>When a user enters new match statistics, the system implements the following logic:<\\/p>\\n                    <ol>\\n                        <li>Calculate the ranking point difference between the players playing the match.<\\/li>\\n                        <li>Check within which ranking score difference interval the result belongs.<\\/li>\\n                        <li>Check which player is the winner and whether it was with higher ranking points or lower ranking points, before the match.<\\/li>\\n                        <li>Increase and decrease the points according to the winner and loser of the match, based on the official figures below.<\\/li>\\n                    <\\/ol>\\n\\n                    <h2>Points Table<\\/h2>\\n                    <table style=\\\"width: 100%; border-collapse: collapse; margin: 1rem 0;\\\">\\n                        <thead>\\n                            <tr style=\\\"border-bottom: 2px solid #404040;\\\">\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Point Difference<\\/th>\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Higher Ranked Wins<\\/th>\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Lower Ranked Wins<\\/th>\\n                            <\\/tr>\\n                        <\\/thead>\\n                        <tbody>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">0 - 25<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">10 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">10 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">26 - 50<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">9 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">11 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">51 - 75<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">8 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">12 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">76 - 100<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">7 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">13 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">101 - 125<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">6 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">15 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">126 - 150<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">6 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">16 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">151 - 200<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">5 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">17 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">201 - 250<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">4 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">18 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">251 - 300<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">3 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">19 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">301 - 400<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">20 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">401 - 500<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">30 points<\\/td>\\n                            <\\/tr>\\n                            <tr>\\n                                <td style=\\\"padding: 0.75rem;\\\">501 and up<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">40 points<\\/td>\\n                            <\\/tr>\\n                        <\\/tbody>\\n                    <\\/table>\\n\\n                    <p>The winner receives plus points and the loser receives the same number of minus points according to the table.<\\/p>\\n\\n                    <h2>Example<\\/h2>\\n                    <p><strong>Player 1:<\\/strong> 1100 points<br>\\n                    <strong>Player 2:<\\/strong> 1300 points<\\/p>\\n\\n                    <p>The difference in points = 1300 - 1100 = <strong>200 points<\\/strong><\\/p>\\n\\n                    <p>Based on the table above (151-200 range):<\\/p>\\n                    <ul>\\n                        <li><strong>If Player 1 wins:<\\/strong> Player 1 will have 1117 points (+17) and Player 2 will have 1283 points (-17)<\\/li>\\n                        <li><strong>If Player 2 wins:<\\/strong> Player 1 will have 1095 points (-5) and Player 2 will have 1305 points (+5)<\\/li>\\n                    <\\/ul>\\n\\n                    <p>Bubblers are lists based on different listings. We place different lists on various pages throughout the application.<\\/p>\\n                \"}',1,'2025-11-22 16:16:52','2025-11-22 16:16:52'),
(4,'{\"en\":\"About Us\"}','about','{\"en\":\"\\n                    <h1>About Us<\\/h1>\\n                    <p>Welcome to i-Racket, what rankings should be and a little more.<\\/p>\\n\\n                    <p>We are passionate table tennis players who have created this app to bring together and strengthen the table tennis community throughout Sweden. i-Racket is your ultimate companion for everything related to table tennis rankings, whether you are a beginner or an experienced player.<\\/p>\\n\\n                    <h2>Our Vision<\\/h2>\\n                    <p>We strive to promote and develop table tennis in Sweden by offering a platform that enables community, competition, ranking and engagement. Our vision is to highlight table tennis with a focus on ranking and thus encourage growth in the sport.<\\/p>\\n\\n                    <h2>What i-Racket Offers<\\/h2>\\n                    <ul>\\n                        <li><strong>Real-time rankings:<\\/strong> Every match you publish generates your new ranking. You can immediately see how you can climb the rankings or fight to maintain your position.<\\/li>\\n                        <li><strong>Monthly Rankings:<\\/strong> We retrieve and secure your ranking from the official industry body.<\\/li>\\n                        <li><strong>Follow your Favorite Players:<\\/strong> Follow your favorite players and friends. Get updates on their latest matches and achievements.<\\/li>\\n                        <li><strong>Record your own matches:<\\/strong> Record your own matches played, and note their strengths and weaknesses. The next time you meet, you can use this information.<\\/li>\\n                        <li><strong>Bubbler:<\\/strong> We highlight the most promising players and the most prominent clubs in the country.<\\/li>\\n                        <li><strong>Follow your child:<\\/strong> As a parent, you can follow your child and their friends. You can see their progress and any awards they have won.<\\/li>\\n                    <\\/ul>\\n\\n                    <h2>Our Team<\\/h2>\\n                    <p>i-Racket is created by a dedicated team of table tennis enthusiasts. We are passionate about the sport and about creating a dynamic and user-friendly platform that helps you improve your game and experience the joy of table tennis.<\\/p>\\n\\n                    <h2>Contact<\\/h2>\\n                    <p>Do you have any questions, suggestions or just want to say hello? Don\'t hesitate to contact us at <a href=\\\"mailto:info@iracket.se\\\">info@iracket.se<\\/a><\\/p>\\n                \"}',1,'2025-11-22 16:19:19','2025-11-22 16:19:19');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `monitored_user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_monitors_user_id_monitored_user_id_unique` (`user_id`,`monitored_user_id`),
  KEY `user_monitors_monitored_user_id_foreign` (`monitored_user_id`),
  CONSTRAINT `user_monitors_monitored_user_id_foreign` FOREIGN KEY (`monitored_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_monitors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_monitors` WRITE;
/*!40000 ALTER TABLE `user_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_monitors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_fullname` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `birth_year` int(11) DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `sbtf_player_id` varchar(255) DEFAULT NULL,
  `sbtf_synced` tinyint(1) NOT NULL DEFAULT 0,
  `sbtf_synced_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 0,
  `is_active_player` tinyint(1) NOT NULL DEFAULT 1,
  `accepts_push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  KEY `users_player_match_index` (`last_name`,`first_name`,`birth_year`),
  KEY `users_sbtf_player_id_index` (`sbtf_player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13385 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

