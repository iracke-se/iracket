/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` enum('top_sticky','bottom_sticky','top','bottom','within_page','random','popup') NOT NULL DEFAULT 'top',
  `views` bigint(20) unsigned NOT NULL DEFAULT 0,
  `clicks` bigint(20) unsigned NOT NULL DEFAULT 0,
  `locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`locations`)),
  `link` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','scheduled') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES
(1,'Summer Tournament 2025','assets/images/landing/lastsect.png','top_sticky',1251,89,'[\"home\",\"matches\"]','https://example.com/summer-tournament','2026-05-30','2026-06-29','active','2026-06-09 08:59:32','2026-06-09 09:00:47'),
(2,'Premium Membership','assets/images/landing/lefthero-deskt.png','bottom_sticky',3421,156,'[\"players\",\"bubbler\"]','https://example.com/premium','2026-05-10','2026-08-08','active','2026-06-09 08:59:32','2026-06-09 09:02:46'),
(3,'New Racket Collection','assets/images/landing/pingpong.png','top',890,45,'[\"home\",\"clubs\"]','https://example.com/rackets','2026-06-09','2026-06-23','active','2026-06-09 08:59:32','2026-06-09 08:59:32'),
(4,'Winter League Registration','assets/images/landing/righthero-deskt.png','popup',2100,312,NULL,'https://example.com/winter-league','2026-06-14','2026-07-24','scheduled','2026-06-09 08:59:32','2026-06-09 08:59:32'),
(5,'Club Sponsorship','assets/images/landing/iPhone12left.png','within_page',567,23,'[\"clubs\"]','https://example.com/sponsors','2026-06-04','2026-07-04','active','2026-06-09 08:59:32','2026-06-09 08:59:32'),
(6,'Training Sessions','assets/images/landing/iPhone12right2.png','bottom',1892,78,'[\"matches\",\"players\"]','https://example.com/training',NULL,NULL,'active','2026-06-09 08:59:32','2026-06-09 09:03:23'),
(7,'Old Campaign','assets/images/landing/badge-appStore.png','random',4500,234,'[\"home\"]','https://example.com/old-campaign','2026-04-10','2026-05-10','inactive','2026-06-09 08:59:32','2026-06-09 08:59:32'),
(8,'App Download','assets/images/landing/badge-PlayStore.png','bottom_sticky',780,92,'[\"settings\",\"profile\"]','https://example.com/app','2026-05-25','2026-07-24','active','2026-06-09 08:59:32','2026-06-09 08:59:32');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iracket-cache-0f65f34fda696667efa00300704428de','i:1;',1781003015),
('iracket-cache-0f65f34fda696667efa00300704428de:timer','i:1781003015;',1781003015),
('iracket-cache-scraper_setting_schedule_export_day','N;',1781006621),
('iracket-cache-scraper_setting_schedule_export_enabled','N;',1781006621),
('iracket-cache-scraper_setting_schedule_export_time','N;',1781006621),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-06-09 10:57:51\";s:10:\"updated_at\";s:19:\"2026-06-09 10:57:51\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1781006355);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `from_club_id` bigint(20) unsigned DEFAULT NULL,
  `to_club_id` bigint(20) unsigned DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `born` date DEFAULT NULL,
  `from_club_name` varchar(255) DEFAULT NULL,
  `to_club_name` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `club_transitions_to_club_id_completion_date_index` (`to_club_id`,`completion_date`),
  KEY `club_transitions_from_club_id_completion_date_index` (`from_club_id`,`completion_date`),
  KEY `club_transitions_user_id_index` (`user_id`),
  CONSTRAINT `club_transitions_from_club_id_foreign` FOREIGN KEY (`from_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_to_club_id_foreign` FOREIGN KEY (`to_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_transitions` WRITE;
/*!40000 ALTER TABLE `club_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` VALUES
(1,'Stockholm Racket Club','stockholm-racket-club','Premier racket sports club in Stockholm with world-class facilities.',NULL,'Stockholm','https://stockholmracketclub.se','info@stockholmracketclub.se','+46 8 123 4567','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(2,'Göteborg Tennis & Padel','goteborg-tennis-padel','Leading tennis and padel club on the west coast.',NULL,'Gothenburg','https://gtpadel.se','kontakt@gtpadel.se','+46 31 234 5678','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(3,'Malmö Badminton Club','malmo-badminton-club','Southern Sweden\'s premier badminton facility.',NULL,'Malmö',NULL,'info@malmobadminton.se','+46 40 345 6789','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(4,'Uppsala Squash Center','uppsala-squash-center','Modern squash center with 8 courts.',NULL,'Uppsala',NULL,'bokning@uppsalasquash.se','+46 18 456 7890','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(5,'Linköping Racket Arena','linkoping-racket-arena','Multi-sport racket arena in Östergötland.',NULL,'Linköping',NULL,'info@lkpgarena.se','+46 13 567 8901','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(6,'Västerås Padel Club','vasteras-padel-club','Dedicated padel club with indoor and outdoor courts.',NULL,'Västerås',NULL,'hej@vasteraspadel.se','+46 21 678 9012','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(7,'Örebro Tennis Society','orebro-tennis-society','Historic tennis club founded in 1920.',NULL,'Örebro',NULL,'styrelsen@orebrotennis.se','+46 19 789 0123','2026-06-09 08:59:19','2026-06-09 08:59:19'),
(8,'Helsingborg Racket & Fitness','helsingborg-racket-fitness','Combined racket sports and fitness center.',NULL,'Helsingborg',NULL,'kontakt@hbgracket.se','+46 42 890 1234','2026-06-09 08:59:19','2026-06-09 08:59:19');
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `districts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `districts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `profixio_id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `districts_profixio_id_unique` (`profixio_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `districts` WRITE;
/*!40000 ALTER TABLE `districts` DISABLE KEYS */;
INSERT INTO `districts` VALUES
(1,9000,'Blekinge Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(2,9001,'Bohuslän-Dals BTF','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(3,9002,'Dalarnas Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(4,9003,'Gotlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(5,9004,'Gästriklands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(6,9005,'Göteborgs Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(7,9006,'Hallands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(8,9007,'Hälsinglands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(9,9008,'Jämtland-Härjedalens Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(10,9009,'Medelpads Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(11,9010,'Nordvästra Götalands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(12,9011,'Nordöstra Svealands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(13,9012,'Norrbottens Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(14,9013,'Norrlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(15,9014,'Skånes Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(16,9015,'Smålands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(17,9016,'Stockholms Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(18,9017,'Sydöstra Götalands BTF','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(19,9018,'Södermanlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(20,9019,'Värmlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(21,9020,'Västerbottens Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(22,9021,'Västergötlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(23,9022,'Västmanlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(24,9023,'Ångermanlands Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(25,9024,'Örebro Läns Bordtennisförbund','2026-06-09 08:59:30','2026-06-09 08:59:30'),
(26,9025,'Östergötlands BTF','2026-06-09 08:59:30','2026-06-09 08:59:30');
/*!40000 ALTER TABLE `districts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_details` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned DEFAULT NULL,
  `division` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `team1_score` int(11) DEFAULT NULL,
  `team2_score` int(11) DEFAULT NULL,
  `played_at` date DEFAULT NULL,
  `profixio_match_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_details_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `live_match_details_played_at_division_index` (`played_at`,`division`),
  KEY `live_match_details_profixio_match_id_index` (`profixio_match_id`),
  KEY `live_match_details_is_synced_index` (`is_synced`),
  CONSTRAINT `live_match_details_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_details` WRITE;
/*!40000 ALTER TABLE `live_match_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_games`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_games` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_detail_id` bigint(20) unsigned NOT NULL,
  `game_number` varchar(255) DEFAULT NULL,
  `game_type` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) DEFAULT NULL,
  `player2_name` varchar(255) DEFAULT NULL,
  `player1_partner_name` varchar(255) DEFAULT NULL,
  `player2_partner_name` varchar(255) DEFAULT NULL,
  `player1_sets` int(11) DEFAULT NULL,
  `player2_sets` int(11) DEFAULT NULL,
  `winner_name` varchar(255) DEFAULT NULL,
  `profixio_game_id` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_games_synced_match_id_foreign` (`synced_match_id`),
  KEY `live_match_games_live_match_detail_id_game_number_index` (`live_match_detail_id`,`game_number`),
  KEY `live_match_games_profixio_game_id_index` (`profixio_game_id`),
  KEY `live_match_games_is_synced_index` (`is_synced`),
  CONSTRAINT `live_match_games_live_match_detail_id_foreign` FOREIGN KEY (`live_match_detail_id`) REFERENCES `live_match_details` (`id`) ON DELETE CASCADE,
  CONSTRAINT `live_match_games_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_games` WRITE;
/*!40000 ALTER TABLE `live_match_games` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_games` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_set_id` bigint(20) unsigned NOT NULL,
  `point_number` int(11) DEFAULT NULL,
  `player1_points` int(11) DEFAULT NULL,
  `player2_points` int(11) DEFAULT NULL,
  `serve` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_points_live_match_set_id_point_number_index` (`live_match_set_id`,`point_number`),
  CONSTRAINT `live_match_points_live_match_set_id_foreign` FOREIGN KEY (`live_match_set_id`) REFERENCES `live_match_sets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_points` WRITE;
/*!40000 ALTER TABLE `live_match_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_points` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `live_match_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `live_match_sets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_game_id` bigint(20) unsigned NOT NULL,
  `set_number` int(11) DEFAULT NULL,
  `player1_points` int(11) DEFAULT NULL,
  `player2_points` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `live_match_sets_live_match_game_id_set_number_index` (`live_match_game_id`,`set_number`),
  CONSTRAINT `live_match_sets_live_match_game_id_foreign` FOREIGN KEY (`live_match_game_id`) REFERENCES `live_match_games` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `live_match_sets` WRITE;
/*!40000 ALTER TABLE `live_match_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `live_match_sets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `live_match_game_id` bigint(20) unsigned DEFAULT NULL,
  `source` enum('player_added','scraped') NOT NULL DEFAULT 'player_added',
  `is_unofficial` tinyint(1) NOT NULL DEFAULT 0,
  `uuid` uuid NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `player1_match_points` int(11) DEFAULT NULL,
  `player2_match_points` int(11) DEFAULT NULL,
  `player1_opponent_rating` int(11) DEFAULT NULL,
  `player2_opponent_rating` int(11) DEFAULT NULL,
  `player1_points_before` int(11) DEFAULT NULL,
  `player2_points_before` int(11) DEFAULT NULL,
  `player1_points_change` int(11) DEFAULT NULL,
  `player2_points_change` int(11) DEFAULT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `is_manual` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `replaced_by_match_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  KEY `matches_replaced_by_match_id_foreign` (`replaced_by_match_id`),
  KEY `match_lookup` (`player1_id`,`player2_id`,`played_at`,`deleted_at`),
  KEY `matches_is_unofficial_index` (`is_unofficial`),
  KEY `matches_live_match_game_id_foreign` (`live_match_game_id`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_live_match_game_id_foreign` FOREIGN KEY (`live_match_game_id`) REFERENCES `live_match_games` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_replaced_by_match_id_foreign` FOREIGN KEY (`replaced_by_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',1),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',1),
(10,'2025_11_22_173439_create_notifications_table',1),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',1),
(12,'2025_11_22_174607_add_age_to_users_table',1),
(13,'2025_11_22_180425_create_clubs_table',1),
(14,'2025_11_22_180426_create_matches_table',1),
(15,'2025_11_22_180426_create_monthly_rankings_table',1),
(16,'2025_11_22_180427_add_club_id_to_users_table',1),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',1),
(18,'2025_11_22_180433_create_permission_tables',1),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',1),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',1),
(21,'2025_11_22_183254_add_uuid_to_users_table',1),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',1),
(23,'2025_11_22_183655_make_terms_translatable',1),
(24,'2025_11_22_231254_create_scraper_tables',1),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',1),
(26,'2025_11_23_074902_add_icon_to_notifications_table',1),
(27,'2025_11_23_084421_create_scraper_settings_table',1),
(28,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',1),
(29,'2025_11_23_090000_create_contacts_table',1),
(30,'2025_11_23_103307_add_sbtf_player_fields_to_users_table',1),
(31,'2025_11_24_091012_create_banners_table',1),
(32,'2025_11_24_094538_create_user_monitors_table',1),
(33,'2025_11_24_102243_add_connection_fields_to_users_table',1),
(34,'2025_11_24_105000_add_points_tracking_to_matches_table',1),
(35,'2025_11_24_111359_create_club_transitions_table',1),
(36,'2025_12_23_132006_add_match_tracking_fields',1),
(37,'2025_12_23_133213_make_matches_created_by_nullable',1),
(38,'2025_12_23_160000_add_step_tracking_to_scraper_runs_table',1),
(39,'2026_01_23_071913_add_user_fullname_to_users_table',1),
(40,'2026_01_23_120000_add_popup_scraper_fields_to_scraped_tables',1),
(41,'2026_02_01_100000_create_live_match_details_table',1),
(42,'2026_02_01_100001_create_live_match_games_table',1),
(43,'2026_02_01_100002_create_live_match_sets_table',1),
(44,'2026_02_01_100003_create_live_match_points_table',1),
(45,'2026_02_02_110300_add_match_points_to_matches_table',1),
(46,'2026_02_10_141200_alter_game_number_to_string',1),
(47,'2026_02_10_141500_add_live_match_game_id_to_matches_table',1),
(48,'2026_03_04_000001_add_locale_to_users_table',1),
(49,'2026_03_05_000001_add_district_to_users_table',1),
(50,'2026_03_12_000001_create_districts_table',1),
(51,'2026_03_12_000002_add_district_id_to_users_table',1),
(52,'2026_03_12_000003_create_scraped_district_players_table',1),
(53,'2026_03_17_000000_add_confirmed_at_to_matches_table',1),
(54,'2026_03_17_000001_confirm_scraped_matches',1),
(55,'2026_04_14_000000_add_ranking_date_to_monthly_rankings_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',1);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `ranking_date` date DEFAULT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=307 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2026-06-09 08:59:15','2026-06-09 08:59:15'),
(2,'Manager','web','2026-06-09 08:59:15','2026-06-09 08:59:15');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_district_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_district_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_district_id` int(10) unsigned NOT NULL,
  `district_name` varchar(255) NOT NULL,
  `gender` char(1) NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `birth_year` varchar(4) DEFAULT NULL,
  `club_name` varchar(255) DEFAULT NULL,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  `points` int(10) unsigned NOT NULL DEFAULT 0,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sdp_district_gender_player_unique` (`profixio_district_id`,`gender`,`profixio_player_id`),
  KEY `scraped_district_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_district_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_district_players_surname_first_name_birth_year_index` (`surname`,`first_name`,`birth_year`),
  KEY `scraped_district_players_profixio_player_id_index` (`profixio_player_id`),
  KEY `scraped_district_players_profixio_district_id_index` (`profixio_district_id`),
  KEY `scraped_district_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_district_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_district_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_district_players` WRITE;
/*!40000 ALTER TABLE `scraped_district_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_district_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `opponent_name` varchar(255) DEFAULT NULL,
  `result` varchar(1) DEFAULT NULL,
  `opponent_points` int(11) DEFAULT NULL,
  `match_points` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `scraped_month` varchar(7) DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `ranking_date` date DEFAULT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_diff` varchar(255) DEFAULT NULL,
  `rmld_id` varchar(255) DEFAULT NULL,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_ranking_id` bigint(20) unsigned DEFAULT NULL,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  KEY `scraped_rankings_synced_ranking_id_foreign` (`synced_ranking_id`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_ranking_id_foreign` FOREIGN KEY (`synced_ranking_id`) REFERENCES `monthly_rankings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
INSERT INTO `scraper_logs` VALUES
(1,1,'info','Starting: Creating Database Backup','[]','2026-06-09 09:03:41','2026-06-09 09:03:41');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `current_step` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `steps_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`steps_data`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
INSERT INTO `scraper_runs` VALUES
(1,'full_scrape','Step 1/11: Creating Database Backup','running','{\"month\":\"2026-06\",\"all\":false,\"no_backup\":false}',NULL,0,0,NULL,'2026-06-09 09:03:41',NULL,'2026-06-09 09:03:41','2026-06-09 09:03:41');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php','string','urls','URL for players list scraper','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2026-06-09 08:57:51','2026-06-09 08:57:51'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2026-06-09 08:57:51','2026-06-09 08:57:51');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` VALUES
(1,'{\"en\":\"Terms and Conditions\",\"sv\":\"Villkor\"}','terms-and-conditions','{\"en\":\"<h2><strong>1. Introduction</strong></h2><p><br></p><p>Welcome to <strong>iRacket</strong>. These Terms and Conditions govern your use of our app, and by using <strong>iRacket</strong>, you agree to comply with and be bound by the following terms. If you do not agree to these terms, please refrain from using the app.</p><p><br></p><h2><strong>2. User Accounts</strong></h2><p><br></p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>To use <strong>iRacket</strong>, you may need to create an account by providing accurate and complete information, including a valid email address and other personal details.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>You are responsible for maintaining the confidentiality of your account and password. You agree to notify us immediately if you suspect any unauthorized use of your account.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>You are responsible for all activities that occur under your account.</li></ol><p><br></p><h2><strong>3. Acceptable Use</strong></h2><p><br></p><p>By using <strong>iRacket</strong>, you agree to:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Use the app in a lawful and respectful manner.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Not engage in any activity that could harm the app\'s functionality or disrupt the experience for other users.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Not upload or share any illegal, inappropriate, or harmful content.</li></ol><p><br></p><h2><strong>4. Prohibited Activities</strong></h2><p><br></p><p>You agree not to engage in the following prohibited actions:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Hacking, attempting to gain unauthorized access, or tampering with the app\'s infrastructure.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Using the app for any fraudulent or malicious activities.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Transmitting viruses, malware, or any harmful software through the app.</li></ol><p>Violation of these terms may result in suspension or termination of your account.</p><p><br></p><h2><strong>5. Intellectual Property</strong></h2><p><br></p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>All content and materials within <strong>iRacket</strong>, including text, graphics, logos, and software, are the intellectual property of <strong>iRacket</strong> or its licensors.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>You may not copy, distribute, or create derivative works from any part of the app without explicit permission from <strong>iRacket</strong>.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>You retain ownership of any content you create and share within the app, but you grant <strong>iRacket</strong> a non-exclusive, royalty-free license to use, modify, and display this content for the purpose of providing the service.</li></ol><p><br></p><h2><strong>6. Fees and Payments</strong></h2><p><br></p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Certain features of <strong>iRacket</strong> may be offered as paid services. If you choose to access these features, you agree to pay the applicable fees.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Payments will be processed via the methods provided in the app (e.g., credit card, mobile payment), and all transactions are subject to our third-party payment processors\' terms.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>All fees are non-refundable unless otherwise stated.</li></ol><p><br></p><h2><strong>7. Third-Party Services</strong></h2><p><br></p><p><strong>iRacket</strong> may include links or integrate with third-party services that are not controlled or owned by us. We are not responsible for the content or practices of these third-party services. Use of third-party services is at your own risk, and you should review their respective terms and conditions.</p><p><br></p><h2><strong>8. Termination</strong></h2><p><br></p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>We reserve the right to suspend or terminate your access to <strong>iRacket</strong> at any time for any reason, including violation of these Terms and Conditions.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>You may terminate your account at any time by contacting us. Upon termination, your right to use the app will immediately cease, but certain provisions of these terms may survive termination (e.g., intellectual property, limitation of liability).</li></ol><p><br></p><h2><strong>9. Disclaimers</strong></h2><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>iRacket</strong> is provided on an \\\"as is\\\" and \\\"as available\\\" basis. We make no warranties, expressed or implied, about the app\'s availability, reliability, or suitability for your specific needs.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>We are not liable for any loss, damage, or disruption resulting from your use or inability to use the app.</li></ol><p><br></p><h2><strong>10. Limitation of Liability</strong></h2><p><br></p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>To the fullest extent permitted by law, <strong>iRacket</strong>, its affiliates, and licensors are not liable for any direct, indirect, incidental, special, or consequential damages arising from your use of the app.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Our total liability to you for any claims related to <strong>iRacket</strong> shall not exceed the amount you paid, if any, for using the app in the 12 months preceding the claim.</li></ol><p><br></p><h2><strong>11. Governing Law</strong></h2><p><br></p><p>These Terms and Conditions are governed by and construed in accordance with the laws of [Country/Region]. Any disputes arising from or related to the use of <strong>iRacket</strong> will be subject to the exclusive jurisdiction of the courts located in [Jurisdiction].</p><p><br></p><h2><strong>12. Changes to These Terms</strong></h2><p><br></p><p>We may update these Terms and Conditions from time to time. When changes are made, we will notify you within the app or via email. Continued use of the app after any updates indicates your acceptance of the revised terms.</p><p><br></p><h2><strong>13. Contact Us</strong></h2><p>If you have any questions or concerns regarding these Terms and Conditions, please contact us at:</p><p><strong>Email:</strong> support@iracket.se</p><p><br></p>\",\"sv\":\"<h1>Villkor</h1><h2><br></h2><h2><strong>1. Introduktion</strong></h2><p>Välkommen till iRacket. Dessa användarvillkor reglerar din användning av vår app, och genom att använda iRacket godkänner du att följa och vara bunden av följande villkor. Om du inte godkänner dessa villkor ber vi dig avstå från att använda appen.</p><p><br></p><h2><strong>2. Användarkonton</strong></h2><p><br></p><p>För att använda iRacket kan du behöva skapa ett konto genom att tillhandahålla korrekt och fullständig information, inklusive en giltig e-postadress och andra personuppgifter.</p><p>Du ansvarar för att hålla ditt konto och lösenord konfidentiella. Du samtycker till att omedelbart meddela oss om du misstänker obehörig användning av ditt konto.</p><p>Du ansvarar för alla aktiviteter som sker under ditt konto.</p><p><br></p><h2><strong>3. Godtagbar användning</strong></h2><p><br></p><p>Genom att använda iRacket samtycker du till att:</p><p>Använda appen på ett lagligt och respektfullt sätt.</p><p>Inte delta i någon aktivitet som kan skada appens funktionalitet eller störa upplevelsen för andra användare.</p><p>Inte ladda upp eller dela något olagligt, olämpligt eller skadligt innehåll.</p><p><br></p><h2><strong>4. Förbjudna aktiviteter</strong></h2><p><br></p><p>Du samtycker till att inte delta i följande förbjudna handlingar:</p><p>Hackning, försök att få obehörig åtkomst eller manipulering av appens infrastruktur.</p><p>Användning av appen för bedrägliga eller skadliga aktiviteter.</p><p>Överföring av virus, skadlig programvara eller annan skadlig mjukvara genom appen.</p><p>Överträdelse av dessa villkor kan leda till avstängning eller uppsägning av ditt konto.</p><p><br></p><h2><strong>5. Immateriella rättigheter</strong></h2><p><br></p><p>Allt innehåll och material inom iRacket, inklusive text, grafik, logotyper och programvara, är iRackets eller dess licensgivares immateriella egendom.</p><p>Du får inte kopiera, distribuera eller skapa derivatverk från någon del av appen utan uttryckligt tillstånd från iRacket.</p><p>Du behåller äganderätten till allt innehåll du skapar och delar inom appen, men du ger iRacket en icke-exklusiv, royaltyfri licens att använda, modifiera och visa detta innehåll i syfte att tillhandahålla tjänsten.</p><p><br></p><h2><strong>6. Avgifter och betalningar</strong></h2><p><br></p><p>Vissa funktioner i iRacket kan erbjudas som betaltjänster. Om du väljer att få tillgång till dessa funktioner samtycker du till att betala tillämpliga avgifter.</p><p>Betalningar kommer att behandlas via de metoder som tillhandahålls i appen (t.ex. kreditkort, mobilbetalning), och alla transaktioner omfattas av våra tredjepartsbetalningsprocessorers villkor.</p><p>Alla avgifter är icke-återbetalningsbara om inget annat anges.</p><p><br></p><h2><strong>7. Tredjepartstjänster</strong></h2><p><br></p><p>iRacket kan innehålla länkar till eller integreras med tredjepartstjänster som inte kontrolleras eller ägs av oss. Vi ansvarar inte för innehållet eller praxis hos dessa tredjepartstjänster. Användning av tredjepartstjänster sker på egen risk, och du bör granska deras respektive villkor.</p><p><br></p><h2><strong>8. Uppsägning</strong></h2><p><br></p><p>Vi förbehåller oss rätten att när som helst stänga av eller avsluta din tillgång till iRacket av vilken anledning som helst, inklusive överträdelse av dessa användarvillkor.</p><p>Du kan när som helst avsluta ditt konto genom att kontakta oss. Vid uppsägning upphör din rätt att använda appen omedelbart, men vissa bestämmelser i dessa villkor kan överleva uppsägningen (t.ex. immateriella rättigheter, ansvarsbegränsning).</p><p><br></p><h2><strong>9. Friskrivningsklausuler</strong></h2><p><br></p><p>iRacket tillhandahålls i \\\"befintligt skick\\\" och \\\"som tillgängligt\\\". Vi lämnar inga garantier, uttryckliga eller underförstådda, om appens tillgänglighet, tillförlitlighet eller lämplighet för dina specifika behov.</p><p>Vi ansvarar inte för någon förlust, skada eller störning som uppstår från din användning eller oförmåga att använda appen.</p><p><br></p><h2><strong>10. Ansvarsbegränsning</strong></h2><p><br></p><p>I den utsträckning lagen tillåter är iRacket, dess dotterbolag och licensgivare inte ansvariga för några direkta, indirekta, tillfälliga, särskilda eller följdskador som uppstår från din användning av appen.</p><p>Vårt totala ansvar gentemot dig för eventuella anspråk relaterade till iRacket ska inte överstiga det belopp du betalat, om något, för användning av appen under de 12 månader som föregår anspråket.</p><p><br></p><h2><strong>11. Tillämplig lag</strong></h2><p><br></p><p>Dessa användarvillkor regleras av och tolkas i enlighet med svensk lag. Eventuella tvister som uppstår från eller relaterar till användningen av iRacket kommer att vara föremål för exklusiv jurisdiktion av domstolar belägna i Sverige.</p><p><br></p><h2><strong>12. Ändringar av dessa villkor</strong></h2><p><br></p><p>Vi kan uppdatera dessa användarvillkor från tid till tid. När ändringar görs kommer vi att meddela dig inom appen eller via e-post. Fortsatt användning av appen efter eventuella uppdateringar indikerar ditt godkännande av de reviderade villkoren.</p><p><br></p><h2><strong>13. Kontakta oss</strong></h2><p><br></p><p>Om du har några frågor eller funderingar angående dessa användarvillkor, vänligen kontakta oss på:</p><p><strong>E-post</strong>: <a href=\\\"mailto:support@iracket.se\\\" rel=\\\"noopener noreferrer\\\" target=\\\"_blank\\\">support@iracket.se</a></p><p><br></p>\"}',1,'2026-06-09 08:59:16','2026-06-09 08:59:16'),
(2,'{\"en\":\"Privacy Policy\",\"sv\":\"Integritetspolicy\"}','privacy-policy','{\"en\":\"<h2><strong>1. Introduction</strong></h2><p><br></p><p>At <strong>iRacket</strong>, your privacy is our priority. This Privacy Policy outlines how we collect, use, and protect your personal information when you use our app. By using <strong>iRacket</strong>, you agree to the collection and use of information in accordance with this policy.</p><p><br></p><h2><strong>2. What Information We Collect</strong></h2><p><br></p><p>We collect two types of information:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Personal Information:</strong> When you register or interact with <strong>iRacket</strong>, we may collect personal details such as:</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Name</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Email address</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Contact information</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Non-Personal Information:</strong> We automatically collect information about your device and usage patterns, such as:</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Device type and operating system</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>App usage statistics</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Location data (if enabled)</li></ol><p>This information helps us improve the app\'s performance and provide a better user experience.</p><p><br></p><h2><strong>3. How We Use Your Information</strong></h2><p><br></p><p>The information collected is used for the following purposes:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Personalizing your experience within the app</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Improving the functionality of <strong>iRacket</strong></li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Providing customer support when needed</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Sending notifications, updates, or promotional offers (only if you opt-in)</li></ol><p><br></p><p>We may also use anonymized data for internal analytics to enhance app performance and user experience.</p><p><br></p><h2><strong>4. How We Share Your Information</strong></h2><p><br></p><p>We value your privacy and do not sell or rent your personal information to third parties. However, we may share your data with trusted third-party service providers to help with:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>App hosting and maintenance</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Payment processing</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Analytics and performance monitoring</li></ol><p>These third parties are obligated to keep your information secure and confidential. We may also disclose information if required by law or to protect the rights and safety of our users or the public.</p><p><br></p><h2><strong>5. How We Protect Your Information</strong></h2><p><br></p><p>We implement a variety of security measures to ensure the safety of your personal information. These measures include:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Encryption of sensitive data</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Secure data storage with restricted access</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Regular security audits and updates</li></ol><p>Despite these efforts, no online service is completely secure, and we cannot guarantee absolute security.</p><p><br></p><h2><strong>6. Your Rights</strong></h2><p><br></p><p>Depending on your location, you may have certain rights over your data, such as:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Access:</strong> You can request a copy of the personal information we hold about you.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Correction:</strong> You have the right to correct any incorrect or outdated information.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Deletion:</strong> You may request the deletion of your personal data.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Withdraw Consent:</strong> You can withdraw consent for data collection at any time, though this may affect your ability to use some features of the app.</li></ol><p>To exercise these rights, please contact us at support@iracket.se.</p><p><br></p><h2><strong>7. Cookies and Tracking Technologies</strong></h2><p><br></p><p><strong>iRacket</strong> uses cookies and similar tracking technologies to enhance your experience. Cookies help us:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Save your preferences</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Track usage patterns</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Analyze app performance</li></ol><p>You can control or disable cookies via your device settings, though this may affect your experience within the app.</p><p><br></p><h2><strong>8. Data Retention</strong></h2><p><br></p><p>We retain your personal information only for as long as necessary to fulfill the purposes outlined in this policy. If you close your account, we will delete your personal data unless we need to retain it for legal reasons.</p><p><br></p><h2><strong>9. Changes to This Privacy Policy</strong></h2><p><br></p><p>We may update this Privacy Policy from time to time. Any changes will be posted within the app, and we will notify you through the app or via email if the changes are significant. Please review this policy periodically.</p><p><br></p><h2><strong>10. Contact Us</strong></h2><p><br></p><p>If you have any questions or concerns about this Privacy Policy, please reach out to us at:</p><p><strong>Email:</strong> support@iracket.se</p><p><br></p>\",\"sv\":\"<h1>Integritetspolicy</h1><p><br></p><h2><strong>1. Introduktion</strong></h2><p><br></p><p>På <strong>iRacket</strong> är din integritet vår prioritet. Denna integritetspolicy beskriver hur vi samlar in, använder och skyddar dina personuppgifter när du använder vår app. Genom att använda <strong>iRacket</strong> godkänner du insamling och användning av information i enlighet med denna policy.</p><p><br></p><h2><strong>2. Vilken Information Vi Samlar In</strong></h2><p><br></p><p>Vi samlar in två typer av information:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Personuppgifter:</strong> När du registrerar dig eller interagerar med <strong>iRacket</strong> kan vi samla in personliga uppgifter som:</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Namn</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>E-postadress</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Kontaktinformation</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Icke-Personlig Information:</strong> Vi samlar automatiskt in information om din enhet och användningsmönster, såsom:</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Enhetstyp och operativsystem</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Appanvändningsstatistik</li><li data-list=\\\"bullet\\\" class=\\\"ql-indent-1\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Platsdata (om aktiverat) Denna information hjälper oss att förbättra appens prestanda och ge en bättre användarupplevelse.</li></ol><p><br></p><h2><strong>3. Hur Vi Använder Din Information</strong></h2><p><br></p><p>Den insamlade informationen används för följande ändamål:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Personanpassning av din upplevelse i appen</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Förbättring av <strong>iRackets</strong> funktionalitet</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Tillhandahållande av kundsupport vid behov</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Skickande av meddelanden, uppdateringar eller kampanjerbjudanden (endast om du väljer att ta emot dessa)</li></ol><p>Vi kan också använda anonymiserad data för intern analys för att förbättra appens prestanda och användarupplevelse.</p><p><br></p><h2><strong>4. Hur Vi Delar Din Information</strong></h2><p><br></p><p>Vi värdesätter din integritet och säljer eller hyr inte ut dina personuppgifter till tredje part. Dock kan vi dela din data med betrodda tredjepartsleverantörer för att hjälpa till med:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Appvärdskap och underhåll</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Betalningshantering</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Analys och prestandaövervakning</li></ol><p>Dessa tredje parter är skyldiga att hålla din information säker och konfidentiell. Vi kan också lämna ut information om det krävs enligt lag eller för att skydda våra användares eller allmänhetens rättigheter och säkerhet.</p><p><br></p><h2><strong>5. Hur Vi Skyddar Din Information</strong></h2><p><br></p><p>Vi implementerar olika säkerhetsåtgärder för att säkerställa säkerheten för dina personuppgifter. Dessa åtgärder inkluderar:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Kryptering av känslig data</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Säker datalagring med begränsad åtkomst</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Regelbundna säkerhetsgranskningar och uppdateringar</li></ol><p>Trots dessa insatser är ingen onlinetjänst helt säker, och vi kan inte garantera absolut säkerhet.</p><p><br></p><h2><strong>6. Dina Rättigheter</strong></h2><p><br></p><p>Beroende på var du befinner dig kan du ha vissa rättigheter över din data, såsom:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Tillgång:</strong> Du kan begära en kopia av de personuppgifter vi har om dig.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Rättelse:</strong> Du har rätt att korrigera felaktig eller inaktuell information.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Radering:</strong> Du kan begära radering av dina personuppgifter.</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span><strong>Återkalla Samtycke:</strong> Du kan när som helst återkalla ditt samtycke till datainsamling, även om detta kan påverka din möjlighet att använda vissa funktioner i appen. För att utöva dessa rättigheter, vänligen kontakta oss på <a href=\\\"mailto:support@iracket.se\\\" rel=\\\"noopener noreferrer\\\" target=\\\"_blank\\\">support@iracket.se</a>.</li></ol><p><br></p><h2><strong>7. Cookies och Spårningsteknologier</strong></h2><p><br></p><p><strong>iRacket</strong> använder cookies och liknande spårningsteknologier för att förbättra din upplevelse. Cookies hjälper oss att:</p><ol><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Spara dina inställningar</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Spåra användningsmönster</li><li data-list=\\\"bullet\\\"><span class=\\\"ql-ui\\\" contenteditable=\\\"false\\\"></span>Analysera appens prestanda</li></ol><p>Du kan kontrollera eller inaktivera cookies via dina enhetsinställningar, även om detta kan påverka din upplevelse i appen.</p><p><br></p><h2><strong>8. Datalagring</strong></h2><p><br></p><p>Vi behåller dina personuppgifter endast så länge som det är nödvändigt för att uppfylla de ändamål som beskrivs i denna policy. Om du avslutar ditt konto kommer vi att radera dina personuppgifter om vi inte behöver behålla dem av juridiska skäl.</p><p><br></p><h2><strong>9. Ändringar i Denna Integritetspolicy</strong></h2><p><br></p><p>Vi kan uppdatera denna integritetspolicy från tid till tid. Eventuella ändringar kommer att publiceras i appen, och vi kommer att meddela dig genom appen eller via e-post om ändringarna är betydande. Vänligen granska denna policy regelbundet.</p><p><br></p><h2><strong>10. Kontakta Oss</strong></h2><p><br></p><p>Om du har några frågor eller funderingar om denna integritetspolicy, vänligen kontakta oss på: <strong>E-post:</strong> <a href=\\\"mailto:support@iracket.se\\\" rel=\\\"noopener noreferrer\\\" target=\\\"_blank\\\">support@iracket.se</a></p><p><br></p>\"}',1,'2026-06-09 08:59:16','2026-06-09 08:59:16'),
(3,'{\"en\":\"About Us\",\"sv\":\"Om Oss\"}','about-us','{\"en\":\"<p>\\n                        </p><h1>About Us</h1><p>\\n                        </p><p>Welcome to i-Racket, how ranking should be and a little bit more.</p><p>\\n                        </p><p>We are passionate table tennis players who have created this app to gather and strengthen the table tennis community throughout Sweden. i-Racket is your ultimate companion for everything related to table tennis ranking, whether you are a beginner or an experienced player.</p><p>\\n\\n                        </p><h2>Our Vision</h2><p>\\n                        </p><p>We aim to promote and develop table tennis in Sweden by providing a platform that enables community, competition, ranking, and engagement. Our vision is to highlight table tennis with a focus on ranking, thereby encouraging growth within the sport.</p><p>\\n\\n                        </p><h2>What i-Racket Offers</h2><p>\\n                        </p><p><br></p><p>\\n\\n                        </p><h2>Our Team</h2><p>\\n                        </p><p>i-Racket is created by a dedicated team of table tennis enthusiasts. We are passionate about the sport and about creating a dynamic and user-friendly platform that helps you improve your game and experience the joy of table tennis.</p><p>\\n\\n                        </p><h2>Contact</h2><p>\\n                        </p><p>Do you have questions, suggestions, or just want to say hello? Don\'t hesitate to contact us at <a href=\\\"mailto:info@iracket.se\\\">info@iracket.se</a>.</p><p>\\n                    </p>\",\"sv\":\"<p>\\n                        </p><h1>Om Oss                  </h1><p>Välkommen till i-Racket, som ranking borde vara och lite mer.</p><p>                       </p><p>Vi är passionerade bordtennisspelare som har skapat denna app för att samla och stärka bordtennisgemenskapen i hela Sverige. i-Racket är din ultimata följeslagare för allt som rör bordtennisranking, oavsett om du är en nybörjare eller en erfaren spelare.</p><p>\\n                        </p><h2>Vår Vision                        </h2><p>Vi strävar efter att främja och utveckla bordtennis i Sverige genom att erbjuda en plattform som möjliggör gemenskap, tävling, ranking och engagemang. Vår vision är att lyfta fram bordtennisen med fokus på ranking och på så sätt uppmuntra tillväxten inom sporten.</p><p>\\n                        </p><h2>Vad i-Racket Erbjuder</h2><p>                                             </p><h2>Vårt Team                   </h2><p>i-Racket är skapat av ett dedikerat team av bordtennisentusiaster. Vi brinner för sporten och för att skapa en dynamisk och användarvänlig plattform som hjälper dig att förbättra ditt spel och uppleva glädjen i bordtennis.</p><p>                     </p><h2>Kontakt</h2><p>\\n                        </p><p>Har du frågor, förslag eller vill bara säga hej? Tveka inte att kontakta oss på <a href=\\\"mailto:info@iracket.se\\\">info@iracket.se</a></p><p>\\n                    </p>\"}',1,'2026-06-09 08:59:17','2026-06-09 08:59:17'),
(4,'{\"en\":\"What is Bubblare?\",\"sv\":\"Vad är Bubblare?\"}','bubbler','{\"en\":\"\\n                        <h1>What is Bubblare?</h1>\\n                        <p>Bubblers are about who has been the best in the previous month. How do you know if you have been the best? Well, it\'s about who got the most points in the previous month, and that\'s the most points in their interval.</p>\\n\\n                        <p>The intervals are: 0–499, 500–999, 1000–1249, 1250–1499, 1500–1749, 1750–1999, 2000–2249, 2250+.</p>\\n\\n                        <p>We show the top three in each segment and region. The default is on your own range and region.</p>\\n\\n                        <h2>Intervals for Women</h2>\\n                        <ul>\\n                            <li><strong>Elite class:</strong> at least 1750 points</li>\\n                            <li><strong>Class 1:</strong> 1500–1749 points</li>\\n                            <li><strong>Class 2:</strong> 1250–1499 points</li>\\n                            <li><strong>Class 3:</strong> 1000–1249 points</li>\\n                            <li><strong>Class 4:</strong> 750–999 points</li>\\n                            <li><strong>Class 5:</strong> 0–749 points</li>\\n                        </ul>\\n\\n                        <h2>Intervals for Men</h2>\\n                        <ul>\\n                            <li><strong>Elite:</strong> 2250+ points</li>\\n                            <li><strong>Class 1:</strong> 2000–2249 points</li>\\n                            <li><strong>Class 2:</strong> 1750–1999 points</li>\\n                            <li><strong>Class 3:</strong> 1500–1749 points</li>\\n                            <li><strong>Class 4:</strong> 1250–1499 points</li>\\n                            <li><strong>Class 5:</strong> 1000–1249 points</li>\\n                            <li><strong>Class 6:</strong> 750–999 points</li>\\n                            <li><strong>Class 7:</strong> 0–749 points</li>\\n                        </ul>\\n\\n                        <p>If you get, for example, 100 points a month and step over the interval, you will be shown in your previous interval.</p>\\n\\n                        <p>Bubblers are simply different listings based on rankings, combined with gender, age, geography, etc. We want to build a number of listings that we post on different pages.</p>\\n\\n                        <h2>How Points are Calculated</h2>\\n                        <p>When a user enters new match stats, the system implements the following logic:</p>\\n                        <ol>\\n                            <li>Calculate the ranking points difference between the players that play the match.</li>\\n                            <li>Check in which ranking point difference range the result belongs to.</li>\\n                            <li>Check which player is the winner and whether it was with higher ranking or lower ranking points, prior to the match.</li>\\n                            <li>Increase and decrease points accordingly to the winner and loser of the match, based on the official numbers below.</li>\\n                        </ol>\\n\\n                        <table>\\n                            <thead>\\n                                <tr>\\n                                    <th>Point Difference</th>\\n                                    <th>Higher Ranked Wins</th>\\n                                    <th>Lower Ranked Wins</th>\\n                                </tr>\\n                            </thead>\\n                            <tbody>\\n                                <tr><td>0 – 25</td><td>+10 points</td><td>+10 points</td></tr>\\n                                <tr><td>26 – 50</td><td>+9 points</td><td>+11 points</td></tr>\\n                                <tr><td>51 – 75</td><td>+8 points</td><td>+12 points</td></tr>\\n                                <tr><td>76 – 100</td><td>+7 points</td><td>+13 points</td></tr>\\n                                <tr><td>101 – 125</td><td>+6 points</td><td>+15 points</td></tr>\\n                                <tr><td>126 – 150</td><td>+6 points</td><td>+16 points</td></tr>\\n                                <tr><td>151 – 200</td><td>+5 points</td><td>+17 points</td></tr>\\n                                <tr><td>201 – 250</td><td>+4 points</td><td>+18 points</td></tr>\\n                                <tr><td>251 – 300</td><td>+3 points</td><td>+19 points</td></tr>\\n                                <tr><td>301 – 400</td><td>+2 points</td><td>+20 points</td></tr>\\n                                <tr><td>401 – 500</td><td>+2 points</td><td>+30 points</td></tr>\\n                                <tr><td>501+</td><td>+2 points</td><td>+40 points</td></tr>\\n                            </tbody>\\n                        </table>\\n\\n                        <p>The winner receives plus points and the loser the same number of minus points according to the table.</p>\\n\\n                        <h2>Example</h2>\\n                        <p><strong>Player 1:</strong> 1100 points<br><strong>Player 2:</strong> 1300 points</p>\\n                        <p>Difference = 1300 − 1100 = <strong>200 points</strong> → falls in the 151–200 range.</p>\\n                        <ul>\\n                            <li><strong>If Player 1 wins:</strong> Player 1 → 1117 points (+17), Player 2 → 1283 points (−17)</li>\\n                            <li><strong>If Player 2 wins:</strong> Player 1 → 1095 points (−5), Player 2 → 1305 points (+5)</li>\\n                        </ul>\\n                    \",\"sv\":\"\\n                        <h1>Vad är Bubblare?</h1>\\n                        <p>Bubblare handlar om vem som har varit bäst den föregående månaden. Hur vet du om du har varit bäst? Jo, det handlar om vem som fick flest poäng föregående månad, och det är flest poäng inom sitt intervall.</p>\\n\\n                        <p>Intervallen är: 0–499, 500–999, 1000–1249, 1250–1499, 1500–1749, 1750–1999, 2000–2249, 2250+.</p>\\n\\n                        <p>Vi visar de tre bästa i varje segment och region. Standard är inom ditt eget intervall och din region.</p>\\n\\n                        <h2>Intervall för Damer</h2>\\n                        <ul>\\n                            <li><strong>Elitklass:</strong> minst 1750 poäng</li>\\n                            <li><strong>Klass 1:</strong> 1500–1749 poäng</li>\\n                            <li><strong>Klass 2:</strong> 1250–1499 poäng</li>\\n                            <li><strong>Klass 3:</strong> 1000–1249 poäng</li>\\n                            <li><strong>Klass 4:</strong> 750–999 poäng</li>\\n                            <li><strong>Klass 5:</strong> 0–749 poäng</li>\\n                        </ul>\\n\\n                        <h2>Intervall för Herrar</h2>\\n                        <ul>\\n                            <li><strong>Elite:</strong> 2250+ poäng</li>\\n                            <li><strong>Klass 1:</strong> 2000–2249 poäng</li>\\n                            <li><strong>Klass 2:</strong> 1750–1999 poäng</li>\\n                            <li><strong>Klass 3:</strong> 1500–1749 poäng</li>\\n                            <li><strong>Klass 4:</strong> 1250–1499 poäng</li>\\n                            <li><strong>Klass 5:</strong> 1000–1249 poäng</li>\\n                            <li><strong>Klass 6:</strong> 750–999 poäng</li>\\n                            <li><strong>Klass 7:</strong> 0–749 poäng</li>\\n                        </ul>\\n\\n                        <p>Om du till exempel får 100 poäng en månad och kliver över intervallet, visas du i ditt tidigare intervall.</p>\\n\\n                        <p>Bubblare är helt enkelt olika listor baserade på rankingar kombinerat med kön, ålder, geografi m.m. Vi vill bygga ett antal listor som vi publicerar på olika sidor.</p>\\n\\n                        <h2>Hur Poäng Beräknas</h2>\\n                        <p>När en användare registrerar ny matchstatistik implementerar systemet följande logik:</p>\\n                        <ol>\\n                            <li>Beräkna rankingpoängskillnaden mellan spelarna som spelar matchen.</li>\\n                            <li>Kontrollera vilket poängskillnadsintervall resultatet tillhör.</li>\\n                            <li>Kontrollera vilken spelare som är vinnare och om det var med högre eller lägre rankingpoäng före matchen.</li>\\n                            <li>Öka och minska poängen för vinnaren och förloraren enligt den officiella tabellen nedan.</li>\\n                        </ol>\\n\\n                        <table>\\n                            <thead>\\n                                <tr>\\n                                    <th>Poängskillnad</th>\\n                                    <th>Högre rankad vinner</th>\\n                                    <th>Lägre rankad vinner</th>\\n                                </tr>\\n                            </thead>\\n                            <tbody>\\n                                <tr><td>0 – 25</td><td>+10 poäng</td><td>+10 poäng</td></tr>\\n                                <tr><td>26 – 50</td><td>+9 poäng</td><td>+11 poäng</td></tr>\\n                                <tr><td>51 – 75</td><td>+8 poäng</td><td>+12 poäng</td></tr>\\n                                <tr><td>76 – 100</td><td>+7 poäng</td><td>+13 poäng</td></tr>\\n                                <tr><td>101 – 125</td><td>+6 poäng</td><td>+15 poäng</td></tr>\\n                                <tr><td>126 – 150</td><td>+6 poäng</td><td>+16 poäng</td></tr>\\n                                <tr><td>151 – 200</td><td>+5 poäng</td><td>+17 poäng</td></tr>\\n                                <tr><td>201 – 250</td><td>+4 poäng</td><td>+18 poäng</td></tr>\\n                                <tr><td>251 – 300</td><td>+3 poäng</td><td>+19 poäng</td></tr>\\n                                <tr><td>301 – 400</td><td>+2 poäng</td><td>+20 poäng</td></tr>\\n                                <tr><td>401 – 500</td><td>+2 poäng</td><td>+30 poäng</td></tr>\\n                                <tr><td>501+</td><td>+2 poäng</td><td>+40 poäng</td></tr>\\n                            </tbody>\\n                        </table>\\n\\n                        <p>Vinnaren får pluspoäng och förloraren samma antal minuspoäng enligt tabellen.</p>\\n\\n                        <h2>Exempel</h2>\\n                        <p><strong>Spelare 1:</strong> 1100 poäng<br><strong>Spelare 2:</strong> 1300 poäng</p>\\n                        <p>Skillnad = 1300 − 1100 = <strong>200 poäng</strong> → faller i intervallet 151–200.</p>\\n                        <ul>\\n                            <li><strong>Om Spelare 1 vinner:</strong> Spelare 1 → 1117 poäng (+17), Spelare 2 → 1283 poäng (−17)</li>\\n                            <li><strong>Om Spelare 2 vinner:</strong> Spelare 1 → 1095 poäng (−5), Spelare 2 → 1305 poäng (+5)</li>\\n                        </ul>\\n                    \"}',1,'2026-06-09 08:59:18','2026-06-09 08:59:18'),
(5,'{\"en\":\"Matches\",\"sv\":\"Matcher\"}','matches','{\"en\":\"<p>Easily register matches you have played and get your updated ranking instantly.</p><p>In addition to the result, you can also add personal notes after each match. Save your thoughts about the opponent and the game, such as strengths, playing style, or what you can improve next time.</p><p>When you face the same player again, you have all the information in one place, giving you a clear advantage and better conditions to improve.</p>\",\"sv\":\"<p>Registrera enkelt matcher du har spelat och få din uppdaterade ranking direkt.</p><p>Utöver resultatet kan du även skriva egna anteckningar efter matchen. Spara dina tankar om motståndaren och spelet, till exempel vad spelaren är bra på, styrkor i spelet eller vad du själv kan göra bättre nästa gång.</p><p>När du möter samma spelare igen har du all information samlad, vilket ger dig ett tydligt försprång och bättre förutsättningar att utvecklas.</p>\"}',1,'2026-06-09 08:59:19','2026-06-09 08:59:19');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `monitored_user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_monitors_user_id_monitored_user_id_unique` (`user_id`,`monitored_user_id`),
  KEY `user_monitors_monitored_user_id_foreign` (`monitored_user_id`),
  CONSTRAINT `user_monitors_monitored_user_id_foreign` FOREIGN KEY (`monitored_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_monitors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_monitors` WRITE;
/*!40000 ALTER TABLE `user_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_monitors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` uuid NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_fullname` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `birth_year` int(11) DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `district_id` bigint(20) unsigned DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `sbtf_player_id` varchar(255) DEFAULT NULL,
  `sbtf_synced` tinyint(1) NOT NULL DEFAULT 0,
  `sbtf_synced_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 0,
  `is_active_player` tinyint(1) NOT NULL DEFAULT 1,
  `accepts_push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `locale` varchar(2) DEFAULT NULL,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  KEY `users_club_id_foreign` (`club_id`),
  KEY `users_player_match_index` (`last_name`,`first_name`,`birth_year`),
  KEY `users_sbtf_player_id_index` (`sbtf_player_id`),
  KEY `users_district_id_foreign` (`district_id`),
  CONSTRAINT `users_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_district_id_foreign` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'3ebcab24-84c4-4c36-bf29-65e73487caca','Admin','iRacket',NULL,NULL,'admin@iracket.se',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,'2026-06-09 08:59:16',1,0,0,NULL,NULL,NULL,'$2y$12$ootiGk3EzHU35DQHc1JbieutVuGHs00Yqyg9XOtv2cHHJubJj7OAS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-06-09 08:59:16','2026-06-09 08:59:16','2026-06-09 09:02:37');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

