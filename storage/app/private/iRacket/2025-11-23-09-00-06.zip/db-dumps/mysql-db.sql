/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iracket-cache-scraper_setting_schedule_live_center_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:24;s:3:\"key\";s:24:\"schedule_live_center_day\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:50:\"Day to run live center scrape (not used for daily)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:24;s:3:\"key\";s:24:\"schedule_live_center_day\";s:5:\"value\";s:0:\"\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:50:\"Day to run live center scrape (not used for daily)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_live_center_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:23;s:3:\"key\";s:30:\"schedule_live_center_frequency\";s:5:\"value\";s:5:\"daily\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:30:\"Live center scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:23;s:3:\"key\";s:30:\"schedule_live_center_frequency\";s:5:\"value\";s:5:\"daily\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:30:\"Live center scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_live_center_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:25;s:3:\"key\";s:25:\"schedule_live_center_time\";s:5:\"value\";s:5:\"05:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:38:\"Time to run live center scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:25;s:3:\"key\";s:25:\"schedule_live_center_time\";s:5:\"value\";s:5:\"05:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:38:\"Time to run live center scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_series_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:20;s:3:\"key\";s:19:\"schedule_series_day\";s:5:\"value\";s:6:\"monday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:24:\"Day to run series scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:20;s:3:\"key\";s:19:\"schedule_series_day\";s:5:\"value\";s:6:\"monday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:24:\"Day to run series scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_series_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:19;s:3:\"key\";s:25:\"schedule_series_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:25:\"Series scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:19;s:3:\"key\";s:25:\"schedule_series_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:25:\"Series scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_series_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:21;s:3:\"key\";s:20:\"schedule_series_time\";s:5:\"value\";s:5:\"04:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Time to run series scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:21;s:3:\"key\";s:20:\"schedule_series_time\";s:5:\"value\";s:5:\"04:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Time to run series scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_transitions_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:16;s:3:\"key\";s:24:\"schedule_transitions_day\";s:5:\"value\";s:6:\"monday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:29:\"Day to run transitions scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:16;s:3:\"key\";s:24:\"schedule_transitions_day\";s:5:\"value\";s:6:\"monday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:29:\"Day to run transitions scrape\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891729),
('iracket-cache-scraper_setting_schedule_transitions_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:15;s:3:\"key\";s:30:\"schedule_transitions_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:30:\"Transitions scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:15;s:3:\"key\";s:30:\"schedule_transitions_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:30:\"Transitions scraping frequency\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_schedule_transitions_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:17;s:3:\"key\";s:25:\"schedule_transitions_time\";s:5:\"value\";s:5:\"03:30\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:38:\"Time to run transitions scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:17;s:3:\"key\";s:25:\"schedule_transitions_time\";s:5:\"value\";s:5:\"03:30\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:38:\"Time to run transitions scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2025-11-23 08:55:23\";s:10:\"updated_at\";s:19:\"2025-11-23 08:55:23\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_url_live_center','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:5;s:3:\"key\";s:15:\"url_live_center\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:27:\"URL for live center scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:5;s:3:\"key\";s:15:\"url_live_center\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:27:\"URL for live center scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_url_players','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:2;s:3:\"key\";s:11:\"url_players\";s:5:\"value\";s:54:\"https://www.profixio.com/fx/lisens/public_oversikt.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:28:\"URL for players list scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:2;s:3:\"key\";s:11:\"url_players\";s:5:\"value\";s:54:\"https://www.profixio.com/fx/lisens/public_oversikt.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:28:\"URL for players list scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_url_rankings','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:1;s:3:\"key\";s:12:\"url_rankings\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:24:\"URL for rankings scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:1;s:3:\"key\";s:12:\"url_rankings\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:24:\"URL for rankings scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_url_series','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:4;s:3:\"key\";s:10:\"url_series\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:22:\"URL for series scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:4;s:3:\"key\";s:10:\"url_series\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:22:\"URL for series scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794),
('iracket-cache-scraper_setting_url_transitions','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:3;s:3:\"key\";s:15:\"url_transitions\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:27:\"URL for transitions scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:3;s:3:\"key\";s:15:\"url_transitions\";s:5:\"value\";s:62:\"https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:4:\"urls\";s:11:\"description\";s:27:\"URL for transitions scraper\";s:10:\"created_at\";s:19:\"2025-11-23 08:48:24\";s:10:\"updated_at\";s:19:\"2025-11-23 08:48:24\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1763891794);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
INSERT INTO `club_monthly_rankings` VALUES
(1,4,2025,11,1,8303,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(2,3,2025,11,2,5191,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(3,8,2025,11,3,13840,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(4,6,2025,11,4,13902,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(5,7,2025,11,5,5775,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(6,5,2025,11,6,13008,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(7,1,2025,11,7,13684,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(8,2,2025,11,8,7237,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(9,6,2025,10,1,9260,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(10,7,2025,10,2,8346,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(11,5,2025,10,3,10996,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(12,4,2025,10,4,6357,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(13,3,2025,10,5,9332,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(14,8,2025,10,6,13644,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(15,1,2025,10,7,12906,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(16,2,2025,10,8,7088,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(17,6,2025,9,1,5656,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(18,7,2025,9,2,10186,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(19,3,2025,9,3,6807,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(20,4,2025,9,4,12721,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(21,1,2025,9,5,11798,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(22,2,2025,9,6,11695,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(23,8,2025,9,7,12938,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(24,5,2025,9,8,10216,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(25,5,2025,8,1,9124,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(26,8,2025,8,2,7678,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(27,3,2025,8,3,7224,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(28,4,2025,8,4,5786,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(29,1,2025,8,5,11345,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(30,7,2025,8,6,6861,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(31,2,2025,8,7,13211,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(32,6,2025,8,8,13853,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(33,4,2025,7,1,11624,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(34,6,2025,7,2,7340,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(35,3,2025,7,3,6150,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(36,7,2025,7,4,8538,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(37,8,2025,7,5,7717,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(38,2,2025,7,6,8624,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(39,1,2025,7,7,10091,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(40,5,2025,7,8,12261,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(41,2,2025,6,1,13304,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(42,6,2025,6,2,7400,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(43,5,2025,6,3,5158,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(44,7,2025,6,4,6304,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(45,3,2025,6,5,11587,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(46,4,2025,6,6,14460,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(47,8,2025,6,7,13610,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(48,1,2025,6,8,7470,'2025-11-22 17:08:01','2025-11-22 17:08:01');
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` VALUES
(1,'Stockholm Racket Club','stockholm-racket-club','Premier racket sports club in Stockholm with world-class facilities.',NULL,'Stockholm','https://stockholmracketclub.se','info@stockholmracketclub.se','+46 8 123 4567','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(2,'Göteborg Tennis & Padel','goteborg-tennis-padel','Leading tennis and padel club on the west coast.',NULL,'Gothenburg','https://gtpadel.se','kontakt@gtpadel.se','+46 31 234 5678','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(3,'Malmö Badminton Club','malmo-badminton-club','Southern Sweden\'s premier badminton facility.',NULL,'Malmö',NULL,'info@malmobadminton.se','+46 40 345 6789','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(4,'Uppsala Squash Center','uppsala-squash-center','Modern squash center with 8 courts.',NULL,'Uppsala',NULL,'bokning@uppsalasquash.se','+46 18 456 7890','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(5,'Linköping Racket Arena','linkoping-racket-arena','Multi-sport racket arena in Östergötland.',NULL,'Linköping',NULL,'info@lkpgarena.se','+46 13 567 8901','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(6,'Västerås Padel Club','vasteras-padel-club','Dedicated padel club with indoor and outdoor courts.',NULL,'Västerås',NULL,'hej@vasteraspadel.se','+46 21 678 9012','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(7,'Örebro Tennis Society','orebro-tennis-society','Historic tennis club founded in 1920.',NULL,'Örebro',NULL,'styrelsen@orebrotennis.se','+46 19 789 0123','2025-11-22 17:08:00','2025-11-22 17:08:00'),
(8,'Helsingborg Racket & Fitness','helsingborg-racket-fitness','Combined racket sports and fitness center.',NULL,'Helsingborg',NULL,'kontakt@hbgracket.se','+46 42 890 1234','2025-11-22 17:08:00','2025-11-22 17:08:00');
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES
(1,'Andrej Gjoshevski','info@weboook.co.uk','test hhhhhhhhhhh','replied','2025-11-23 07:16:34',2,'oooookookokokokokokokokok','2025-11-23 07:16:19','2025-11-23 07:16:34');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
INSERT INTO `matches` VALUES
(1,'87377e90-b402-4e8a-88fc-ab59aa74084a',2,1,'2025-10-19',0,3,1,'[\"Fast serve\",\"Excellent net play\"]','[\"Strong forehand\",\"Fast serve\"]','Great match with lots of rallies.','confirmed',2,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(2,'bb33b0e3-3c4d-49a3-801d-304cbc5e28a4',2,1,'2025-10-14',1,3,1,'[\"Great footwork\",\"Excellent net play\"]','[\"Strong forehand\",\"Excellent net play\"]',NULL,'confirmed',2,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(3,'ef6b6133-de6d-4239-a3ba-2ee3e7349463',1,2,'2025-09-08',0,3,2,'[\"Good backhand\",\"Strong forehand\"]','[\"Fast serve\",\"Excellent net play\"]','Great match with lots of rallies.','confirmed',1,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(4,'e47d588d-0574-448c-a168-5900e2ef6d90',2,1,'2025-09-25',2,3,1,'[\"Consistent player\"]','[\"Strong forehand\"]',NULL,'confirmed',2,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(5,'8c7df4ec-49f8-4011-bc8d-00ba556f4e5a',1,2,'2025-08-28',1,2,2,'[\"Good backhand\",\"Strong forehand\",\"Fast serve\"]','[\"Fast serve\",\"Great footwork\",\"Consistent player\"]','Great match with lots of rallies.','confirmed',1,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(6,'3a6a29d1-a0ec-4ed7-ab6b-bf7dd19473ff',2,1,'2025-11-18',0,3,1,'[\"Great footwork\",\"Excellent net play\"]','[\"Strong forehand\",\"Fast serve\"]',NULL,'confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(7,'a3ae8206-eec3-440b-b105-e3ba99a9802c',1,2,'2025-10-28',1,3,2,'[]','[\"Fast serve\"]','Great match with lots of rallies.','confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(8,'fee2b430-299c-4943-abce-0b2c58af4d25',1,2,'2025-09-02',0,1,2,'[\"Fast serve\",\"Excellent net play\"]','[\"Great footwork\",\"Excellent net play\",\"Good sportsmanship\"]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(9,'063cc30c-e907-43e7-a171-5bca3f9c45b1',2,1,'2025-09-30',1,0,2,'[]','[\"Good backhand\",\"Strong forehand\"]','Great match with lots of rallies.','confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(10,'27603647-700e-4417-b07e-7b267b9e643d',2,1,'2025-08-26',2,3,1,'[\"Fast serve\",\"Consistent player\"]','[\"Excellent net play\"]',NULL,'confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(11,'0ba0a1e5-7380-4768-95e6-5234190ef466',2,1,'2025-09-24',0,1,1,'[\"Good backhand\",\"Excellent net play\",\"Good sportsmanship\"]','[]','Great match with lots of rallies.','confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(12,'25636875-7f20-4ab3-a9c5-f8c10f9998a0',1,2,'2025-09-03',2,1,1,'[]','[\"Fast serve\",\"Excellent net play\",\"Consistent player\"]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(13,'92f943b9-c536-4a16-87c6-1e6cf8c248c2',1,2,'2025-10-09',0,2,2,'[\"Strong forehand\",\"Great footwork\"]','[\"Good sportsmanship\"]','Great match with lots of rallies.','confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(14,'afcac2a4-1e1a-42b0-85c4-16679bde39c5',1,2,'2025-10-28',4,3,1,'[\"Fast serve\",\"Great footwork\",\"Excellent net play\"]','[]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(15,'6478d087-cd27-4a8c-ae9f-7dd746de5a2c',1,2,'2025-11-08',1,3,2,'[\"Good sportsmanship\"]','[]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(16,'49914c3c-eabd-4541-81c5-57b2a03a566f',2,1,'2025-11-08',1,2,1,'[]','[\"Good backhand\"]','Great match with lots of rallies.','confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(17,'29592bc3-529e-436e-b054-f603547e3f4a',2,1,'2025-11-14',2,3,1,'[\"Strong forehand\",\"Great footwork\",\"Excellent net play\"]','[\"Strong forehand\",\"Excellent net play\",\"Consistent player\"]',NULL,'confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(18,'54543d16-d802-420a-99a0-230d861174c1',1,2,'2025-11-13',2,3,2,'[\"Great footwork\",\"Good sportsmanship\",\"Consistent player\"]','[\"Excellent net play\"]','Great match with lots of rallies.','confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(19,'d075b86d-d23d-4579-b343-82f2d160e8c4',1,2,'2025-10-07',2,0,1,'[]','[\"Good sportsmanship\"]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(20,'2c7aefba-e7c7-471c-a1ee-bd5a84b79266',1,2,'2025-11-18',0,3,2,'[\"Great footwork\",\"Good sportsmanship\"]','[\"Fast serve\",\"Great footwork\",\"Consistent player\"]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(21,'074ea007-5794-4580-a3d0-07e67b2deca1',2,1,'2025-10-18',1,2,1,'[]','[\"Excellent net play\",\"Great sportsmanship\",\"Good forehand\"]',NULL,'pending',2,'2025-11-22 17:08:15','2025-11-22 22:14:15'),
(22,'7f267c6a-2f57-43e9-b40b-2ab2909d9a0c',1,2,'2025-10-09',1,3,2,'[\"Excellent net play\",\"Good sportsmanship\"]','[\"Good backhand\",\"Excellent net play\",\"Good sportsmanship\"]','Great match with lots of rallies.','confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(23,'5f817f96-f4c7-487c-a7f4-cf25c03c38f8',1,2,'2025-10-02',1,0,1,'[\"Good sportsmanship\"]','[\"Great footwork\",\"Excellent net play\",\"Good sportsmanship\"]',NULL,'confirmed',1,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(24,'3e429567-2e8e-4c8b-a7c0-c17141a6651d',2,1,'2025-09-07',2,1,2,'[\"Fast serve\",\"Great footwork\",\"Excellent net play\"]','[\"Good sportsmanship\"]',NULL,'confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15'),
(25,'02a7ee87-d776-44cf-9e65-d04fa0a0e881',2,1,'2025-10-21',0,3,1,'[\"Great footwork\"]','[]',NULL,'confirmed',2,'2025-11-22 17:08:15','2025-11-22 17:08:15');
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',2),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',3),
(10,'2025_11_22_173439_create_notifications_table',3),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',3),
(12,'2025_11_22_174607_add_age_to_users_table',4),
(13,'2025_11_22_180425_create_clubs_table',5),
(14,'2025_11_22_180426_create_matches_table',5),
(15,'2025_11_22_180426_create_monthly_rankings_table',5),
(16,'2025_11_22_180427_add_club_id_to_users_table',6),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',6),
(18,'2025_11_22_180433_create_permission_tables',6),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',7),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',8),
(21,'2025_11_22_183254_add_uuid_to_users_table',8),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',8),
(23,'2025_11_22_183655_make_terms_translatable',9),
(24,'2025_11_22_231254_create_scraper_tables',10),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',11),
(26,'2025_11_23_074902_add_icon_to_notifications_table',12),
(27,'2025_11_23_090000_create_contacts_table',13),
(28,'2025_11_23_084421_create_scraper_settings_table',14),
(29,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',15);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',2);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=563 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
INSERT INTO `monthly_rankings` VALUES
(1,2,2025,11,1,1244,58,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(2,1,2025,11,2,1567,-25,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(3,2,2025,10,1,1977,87,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(4,1,2025,10,2,1924,45,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(5,1,2025,9,1,1597,56,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(6,2,2025,9,2,1236,81,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(7,1,2025,8,1,1449,82,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(8,2,2025,8,2,1388,-26,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(9,2,2025,7,1,1178,85,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(10,1,2025,7,2,1321,39,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(11,1,2025,6,1,1488,64,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(12,2,2025,6,2,1672,42,'2025-11-22 17:08:01','2025-11-22 17:08:01'),
(13,3,2025,11,20,1327,-55,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(14,3,2025,1,47,1633,247,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(15,3,2025,2,3,908,39,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(16,3,2025,3,31,2329,139,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(17,3,2025,4,6,2219,-83,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(18,3,2025,5,18,2399,193,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(19,3,2025,6,40,1930,-119,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(20,3,2025,7,44,2093,226,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(21,3,2025,8,9,749,-101,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(22,3,2025,9,8,2188,-99,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(23,3,2025,10,1,762,127,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(24,4,2025,11,21,1279,-2,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(25,4,2025,1,9,1068,84,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(26,4,2025,2,29,1102,-149,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(27,4,2025,3,12,2034,34,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(28,4,2025,4,48,2389,169,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(29,4,2025,5,26,1353,-14,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(30,4,2025,6,40,2339,53,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(31,4,2025,7,31,1496,-56,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(32,4,2025,8,29,1856,39,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(33,4,2025,9,49,1253,174,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(34,4,2025,10,31,1284,-105,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(35,5,2025,11,14,1529,-91,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(36,5,2025,1,25,1761,70,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(37,5,2025,2,9,2248,-79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(38,5,2025,3,19,2131,-134,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(39,5,2025,4,47,1885,-33,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(40,5,2025,5,34,1830,148,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(41,5,2025,6,33,1891,110,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(42,5,2025,7,26,2128,-62,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(43,5,2025,8,24,1659,172,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(44,5,2025,9,22,1223,180,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(45,5,2025,10,30,2024,-136,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(46,6,2025,11,9,2070,49,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(47,6,2025,1,25,2328,41,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(48,6,2025,2,47,1985,103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(49,6,2025,3,34,1533,-40,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(50,6,2025,4,14,2027,77,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(51,6,2025,5,11,1537,-113,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(52,6,2025,6,36,1894,185,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(53,6,2025,7,50,1169,-103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(54,6,2025,8,22,2104,10,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(55,6,2025,9,3,1998,186,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(56,6,2025,10,30,790,12,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(57,7,2025,11,16,1467,196,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(58,7,2025,1,29,1988,138,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(59,7,2025,2,9,859,-22,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(60,7,2025,3,10,911,33,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(61,7,2025,4,13,1425,-101,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(62,7,2025,5,1,1477,-136,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(63,7,2025,6,28,1126,154,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(64,7,2025,7,49,1413,-53,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(65,7,2025,8,7,1849,222,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(66,7,2025,9,29,1691,-29,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(67,7,2025,10,39,2224,-10,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(68,8,2025,11,22,1087,103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(69,8,2025,1,30,1302,52,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(70,8,2025,2,35,1446,-59,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(71,8,2025,3,25,2290,-141,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(72,8,2025,4,19,2218,-15,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(73,8,2025,5,22,2078,-2,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(74,8,2025,6,9,2302,-133,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(75,8,2025,7,29,937,17,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(76,8,2025,8,15,1420,20,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(77,8,2025,9,22,733,-102,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(78,8,2025,10,13,733,-87,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(79,9,2025,11,7,2136,79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(80,9,2025,1,21,1976,-48,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(81,9,2025,2,17,1951,151,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(82,9,2025,3,21,707,-27,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(83,9,2025,4,10,1208,-103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(84,9,2025,5,13,2158,-69,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(85,9,2025,6,41,1341,-63,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(86,9,2025,7,21,1210,-59,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(87,9,2025,8,40,983,30,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(88,9,2025,9,50,1672,93,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(89,9,2025,10,30,1125,13,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(90,10,2025,11,12,1759,-17,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(91,10,2025,1,36,1095,-31,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(92,10,2025,2,43,1085,-77,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(93,10,2025,3,31,2379,200,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(94,10,2025,4,14,1051,120,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(95,10,2025,5,8,1729,-73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(96,10,2025,6,5,2247,-13,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(97,10,2025,7,47,1254,72,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(98,10,2025,8,19,1656,-101,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(99,10,2025,9,2,1268,-61,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(100,10,2025,10,7,2386,223,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(101,11,2025,11,17,1452,-41,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(102,11,2025,1,19,1275,-5,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(103,11,2025,2,4,1559,-139,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(104,11,2025,3,43,881,54,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(105,11,2025,4,18,1620,-11,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(106,11,2025,5,40,1773,-136,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(107,11,2025,6,24,2095,-46,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(108,11,2025,7,32,896,-40,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(109,11,2025,8,14,2136,239,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(110,11,2025,9,1,1972,130,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(111,11,2025,10,21,824,218,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(112,12,2025,11,1,2482,-98,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(113,12,2025,1,36,1204,72,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(114,12,2025,2,21,2325,166,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(115,12,2025,3,35,712,215,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(116,12,2025,4,8,799,149,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(117,12,2025,5,50,1067,-90,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(118,12,2025,6,17,1206,-131,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(119,12,2025,7,21,2144,-23,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(120,12,2025,8,22,1643,-150,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(121,12,2025,9,5,1019,142,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(122,12,2025,10,1,1222,59,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(123,13,2025,11,24,984,-12,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(124,13,2025,1,19,1673,145,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(125,13,2025,2,7,761,207,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(126,13,2025,3,20,1197,-113,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(127,13,2025,4,4,1896,17,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(128,13,2025,5,24,2227,84,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(129,13,2025,6,33,801,-132,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(130,13,2025,7,17,1007,53,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(131,13,2025,8,41,1047,16,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(132,13,2025,9,21,1142,-19,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(133,13,2025,10,19,1849,111,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(134,14,2025,11,8,2100,-95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(135,14,2025,1,1,1093,-38,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(136,14,2025,2,48,1475,-67,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(137,14,2025,3,13,2373,98,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(138,14,2025,4,40,1001,-136,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(139,14,2025,5,27,2373,-128,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(140,14,2025,6,34,1604,43,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(141,14,2025,7,4,1523,-93,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(142,14,2025,8,31,2294,-78,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(143,14,2025,9,6,1025,-127,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(144,14,2025,10,20,1300,213,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(145,15,2025,11,23,1022,-95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(146,15,2025,1,28,2371,55,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(147,15,2025,2,42,1455,54,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(148,15,2025,3,44,2257,59,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(149,15,2025,4,4,869,152,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(150,15,2025,5,29,1463,-93,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(151,15,2025,6,17,2288,224,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(152,15,2025,7,18,2036,-32,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(153,15,2025,8,11,1926,13,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(154,15,2025,9,22,1109,-113,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(155,15,2025,10,11,877,213,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(156,16,2025,11,15,1526,163,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(157,16,2025,1,37,1618,132,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(158,16,2025,2,11,1399,73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(159,16,2025,3,6,1399,-39,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(160,16,2025,4,37,2393,45,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(161,16,2025,5,20,2348,158,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(162,16,2025,6,39,2108,166,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(163,16,2025,7,45,1940,143,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(164,16,2025,8,27,1052,-122,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(165,16,2025,9,6,1190,-97,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(166,16,2025,10,14,1813,160,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(167,17,2025,11,2,2428,129,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(168,17,2025,1,15,2290,-103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(169,17,2025,2,49,1602,126,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(170,17,2025,3,19,1435,188,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(171,17,2025,4,48,1063,150,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(172,17,2025,5,7,1449,-88,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(173,17,2025,6,37,2141,190,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(174,17,2025,7,12,1375,123,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(175,17,2025,8,1,1747,29,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(176,17,2025,9,5,840,218,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(177,17,2025,10,27,773,24,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(178,18,2025,11,18,1451,103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(179,18,2025,1,8,1218,-15,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(180,18,2025,2,38,1215,80,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(181,18,2025,3,2,2106,-102,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(182,18,2025,4,3,2142,127,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(183,18,2025,5,6,1330,72,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(184,18,2025,6,39,2276,177,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(185,18,2025,7,39,1376,245,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(186,18,2025,8,13,1701,-121,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(187,18,2025,9,36,2026,24,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(188,18,2025,10,29,1997,190,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(189,19,2025,11,25,805,162,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(190,19,2025,1,22,2193,171,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(191,19,2025,2,49,2184,-6,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(192,19,2025,3,43,1039,-23,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(193,19,2025,4,42,1599,146,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(194,19,2025,5,44,1969,-3,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(195,19,2025,6,15,2062,122,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(196,19,2025,7,48,1211,-15,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(197,19,2025,8,15,1241,245,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(198,19,2025,9,24,1096,72,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(199,19,2025,10,31,1674,236,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(200,20,2025,11,6,2160,197,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(201,20,2025,1,50,1233,161,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(202,20,2025,2,36,2088,-8,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(203,20,2025,3,46,1336,90,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(204,20,2025,4,44,2141,189,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(205,20,2025,5,21,844,21,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(206,20,2025,6,14,1283,-13,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(207,20,2025,7,44,1305,158,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(208,20,2025,8,17,1464,123,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(209,20,2025,9,7,1038,-70,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(210,20,2025,10,40,792,104,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(211,21,2025,11,5,2164,57,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(212,21,2025,1,28,949,-6,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(213,21,2025,2,35,1546,114,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(214,21,2025,3,27,2071,-138,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(215,21,2025,4,45,1119,169,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(216,21,2025,5,4,798,86,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(217,21,2025,6,7,2098,200,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(218,21,2025,7,22,2382,90,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(219,21,2025,8,22,1573,77,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(220,21,2025,9,15,1703,35,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(221,21,2025,10,24,2092,153,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(222,22,2025,11,13,1742,165,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(223,22,2025,1,41,1068,95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(224,22,2025,2,29,1518,51,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(225,22,2025,3,4,1854,165,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(226,22,2025,4,21,1047,145,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(227,22,2025,5,49,1805,197,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(228,22,2025,6,21,1000,-89,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(229,22,2025,7,27,1728,-7,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(230,22,2025,8,44,1329,-22,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(231,22,2025,9,43,963,-78,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(232,22,2025,10,22,1645,178,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(233,23,2025,11,4,2338,18,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(234,23,2025,1,47,1243,-64,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(235,23,2025,2,43,1028,-125,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(236,23,2025,3,25,1223,93,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(237,23,2025,4,5,974,186,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(238,23,2025,5,37,2334,67,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(239,23,2025,6,17,1201,0,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(240,23,2025,7,36,2397,243,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(241,23,2025,8,3,830,28,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(242,23,2025,9,49,708,47,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(243,23,2025,10,33,2272,138,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(244,24,2025,11,3,2388,-18,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(245,24,2025,1,50,1929,-149,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(246,24,2025,2,5,1662,194,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(247,24,2025,3,7,730,-144,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(248,24,2025,4,49,1028,-50,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(249,24,2025,5,40,1436,116,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(250,24,2025,6,9,728,-143,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(251,24,2025,7,45,1560,250,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(252,24,2025,8,27,1684,145,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(253,24,2025,9,42,889,26,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(254,24,2025,10,1,1258,56,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(255,25,2025,11,11,1801,-12,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(256,25,2025,1,15,1891,-78,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(257,25,2025,2,4,1023,124,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(258,25,2025,3,9,1824,223,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(259,25,2025,4,50,2101,82,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(260,25,2025,5,44,2351,131,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(261,25,2025,6,18,2108,239,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(262,25,2025,7,4,2320,71,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(263,25,2025,8,1,1552,-82,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(264,25,2025,9,21,778,-95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(265,25,2025,10,7,1300,-140,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(266,26,2025,11,10,1946,109,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(267,26,2025,1,26,1853,246,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(268,26,2025,2,2,1695,104,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(269,26,2025,3,14,1436,32,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(270,26,2025,4,17,1705,220,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(271,26,2025,5,2,1251,-19,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(272,26,2025,6,49,2108,-22,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(273,26,2025,7,3,2355,171,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(274,26,2025,8,46,858,56,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(275,26,2025,9,17,828,-84,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(276,26,2025,10,32,1573,241,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(277,27,2025,11,19,1363,118,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(278,27,2025,1,25,1948,-8,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(279,27,2025,2,19,953,11,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(280,27,2025,3,1,2065,-27,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(281,27,2025,4,41,1914,-93,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(282,27,2025,5,40,935,32,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(283,27,2025,6,31,891,201,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(284,27,2025,7,28,990,17,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(285,27,2025,8,13,709,201,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(286,27,2025,9,16,1707,64,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(287,27,2025,10,3,720,71,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(288,28,2025,11,20,1023,154,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(289,28,2025,1,49,1052,147,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(290,28,2025,2,38,1707,-80,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(291,28,2025,3,21,2087,84,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(292,28,2025,4,40,1024,90,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(293,28,2025,5,39,2316,-136,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(294,28,2025,6,3,1472,27,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(295,28,2025,7,48,2069,-132,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(296,28,2025,8,12,2268,135,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(297,28,2025,9,26,758,168,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(298,28,2025,10,43,2006,172,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(299,29,2025,11,13,1655,158,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(300,29,2025,1,42,1554,195,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(301,29,2025,2,30,1442,-141,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(302,29,2025,3,50,1366,72,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(303,29,2025,4,12,1777,-77,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(304,29,2025,5,30,2375,87,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(305,29,2025,6,20,2150,-102,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(306,29,2025,7,13,1483,171,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(307,29,2025,8,41,1608,-64,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(308,29,2025,9,36,1608,-105,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(309,29,2025,10,41,1673,133,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(310,30,2025,11,6,2005,134,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(311,30,2025,1,18,2026,113,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(312,30,2025,2,9,1812,189,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(313,30,2025,3,49,2202,90,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(314,30,2025,4,11,2300,-2,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(315,30,2025,5,45,984,62,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(316,30,2025,6,44,1246,180,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(317,30,2025,7,42,1145,-14,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(318,30,2025,8,28,764,-24,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(319,30,2025,9,24,1763,208,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(320,30,2025,10,29,993,167,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(321,31,2025,11,2,2410,-80,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(322,31,2025,1,37,1720,-21,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(323,31,2025,2,8,1987,-20,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(324,31,2025,3,14,2301,36,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(325,31,2025,4,4,2053,161,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(326,31,2025,5,8,2210,-129,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(327,31,2025,6,27,773,-133,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(328,31,2025,7,47,2083,174,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(329,31,2025,8,32,807,162,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(330,31,2025,9,47,705,-2,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(331,31,2025,10,15,976,114,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(332,32,2025,11,21,1019,-79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(333,32,2025,1,24,1589,115,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(334,32,2025,2,2,1498,221,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(335,32,2025,3,9,2278,-121,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(336,32,2025,4,38,1855,188,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(337,32,2025,5,47,904,210,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(338,32,2025,6,47,1153,226,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(339,32,2025,7,23,1031,-65,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(340,32,2025,8,46,2073,193,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(341,32,2025,9,40,1464,-48,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(342,32,2025,10,47,1563,-51,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(343,33,2025,11,18,1426,1,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(344,33,2025,1,30,741,173,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(345,33,2025,2,6,755,92,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(346,33,2025,3,47,1605,-129,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(347,33,2025,4,31,1611,154,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(348,33,2025,5,34,1117,161,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(349,33,2025,6,29,2177,27,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(350,33,2025,7,17,2086,-87,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(351,33,2025,8,30,800,-58,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(352,33,2025,9,11,2306,230,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(353,33,2025,10,1,1520,-12,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(354,34,2025,11,22,1015,-48,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(355,34,2025,1,34,1059,123,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(356,34,2025,2,22,1298,-124,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(357,34,2025,3,45,999,-6,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(358,34,2025,4,24,1761,142,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(359,34,2025,5,10,1529,199,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(360,34,2025,6,14,1634,190,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(361,34,2025,7,43,2115,-79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(362,34,2025,8,36,1504,171,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(363,34,2025,9,47,1262,-21,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(364,34,2025,10,34,853,-145,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(365,35,2025,11,11,1789,200,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(366,35,2025,1,47,1360,-90,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(367,35,2025,2,29,2256,224,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(368,35,2025,3,19,932,79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(369,35,2025,4,49,1711,-85,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(370,35,2025,5,48,2318,229,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(371,35,2025,6,25,900,130,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(372,35,2025,7,42,1033,61,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(373,35,2025,8,30,2126,52,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(374,35,2025,9,21,1854,-45,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(375,35,2025,10,16,820,-122,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(376,36,2025,11,16,1546,78,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(377,36,2025,1,8,1718,-24,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(378,36,2025,2,43,1300,-79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(379,36,2025,3,25,1751,-143,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(380,36,2025,4,35,1163,153,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(381,36,2025,5,3,2066,-49,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(382,36,2025,6,50,762,150,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(383,36,2025,7,28,943,-135,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(384,36,2025,8,40,1325,-73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(385,36,2025,9,35,2032,191,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(386,36,2025,10,10,1503,49,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(387,37,2025,11,5,2104,134,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(388,37,2025,1,12,795,-69,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(389,37,2025,2,30,1726,86,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(390,37,2025,3,47,2046,183,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(391,37,2025,4,28,2368,1,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(392,37,2025,5,43,1512,-24,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(393,37,2025,6,8,1099,34,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(394,37,2025,7,43,1153,158,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(395,37,2025,8,38,792,-110,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(396,37,2025,9,35,1765,-150,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(397,37,2025,10,34,1522,-92,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(398,38,2025,11,3,2394,162,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(399,38,2025,1,36,2121,-73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(400,38,2025,2,45,1476,-41,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(401,38,2025,3,15,2152,186,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(402,38,2025,4,41,2349,247,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(403,38,2025,5,18,2001,-103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(404,38,2025,6,30,1815,237,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(405,38,2025,7,5,863,147,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(406,38,2025,8,7,2037,-79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(407,38,2025,9,4,1524,-65,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(408,38,2025,10,16,1386,-64,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(409,39,2025,11,7,2004,9,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(410,39,2025,1,8,1255,-8,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(411,39,2025,2,27,2049,116,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(412,39,2025,3,33,1663,-105,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(413,39,2025,4,12,1871,-132,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(414,39,2025,5,44,1682,220,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(415,39,2025,6,11,1760,-146,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(416,39,2025,7,45,1967,-136,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(417,39,2025,8,8,2041,121,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(418,39,2025,9,47,767,-123,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(419,39,2025,10,25,734,-79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(420,40,2025,11,14,1631,79,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(421,40,2025,1,30,1421,19,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(422,40,2025,2,21,1685,-99,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(423,40,2025,3,18,1523,96,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(424,40,2025,4,41,773,235,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(425,40,2025,5,35,2211,-33,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(426,40,2025,6,16,2110,-95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(427,40,2025,7,37,1160,-146,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(428,40,2025,8,2,1206,148,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(429,40,2025,9,42,1453,238,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(430,40,2025,10,26,1350,74,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(431,41,2025,11,23,1006,-96,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(432,41,2025,1,7,1960,142,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(433,41,2025,2,12,1484,49,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(434,41,2025,3,35,2031,17,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(435,41,2025,4,26,1322,-21,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(436,41,2025,5,38,710,-100,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(437,41,2025,6,37,1794,73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(438,41,2025,7,7,1557,-97,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(439,41,2025,8,2,1289,179,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(440,41,2025,9,4,1565,95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(441,41,2025,10,45,1498,247,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(442,42,2025,11,17,1528,-47,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(443,42,2025,1,41,915,-148,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(444,42,2025,2,37,1143,25,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(445,42,2025,3,1,924,22,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(446,42,2025,4,39,1738,-54,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(447,42,2025,5,40,1269,201,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(448,42,2025,6,45,1169,157,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(449,42,2025,7,37,2240,67,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(450,42,2025,8,34,1215,25,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(451,42,2025,9,32,1887,114,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(452,42,2025,10,22,1532,-105,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(453,43,2025,11,10,1941,-95,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(454,43,2025,1,17,2090,242,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(455,43,2025,2,21,1547,116,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(456,43,2025,3,15,2259,142,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(457,43,2025,4,13,1655,43,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(458,43,2025,5,46,2025,4,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(459,43,2025,6,42,764,204,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(460,43,2025,7,30,1462,78,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(461,43,2025,8,34,749,84,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(462,43,2025,9,41,734,233,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(463,43,2025,10,35,1123,-97,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(464,44,2025,11,24,845,102,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(465,44,2025,1,32,1866,63,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(466,44,2025,2,13,1270,-21,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(467,44,2025,3,20,2169,-17,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(468,44,2025,4,40,902,53,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(469,44,2025,5,25,2238,-110,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(470,44,2025,6,16,1317,46,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(471,44,2025,7,25,1002,215,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(472,44,2025,8,33,2174,247,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(473,44,2025,9,19,1206,73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(474,44,2025,10,33,1072,-40,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(475,45,2025,11,8,1997,69,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(476,45,2025,1,23,2165,-6,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(477,45,2025,2,27,2114,205,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(478,45,2025,3,30,864,172,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(479,45,2025,4,30,1646,86,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(480,45,2025,5,26,2279,-11,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(481,45,2025,6,36,1798,129,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(482,45,2025,7,20,2017,119,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(483,45,2025,8,29,2239,-39,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(484,45,2025,9,30,1517,250,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(485,45,2025,10,36,2357,-103,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(486,46,2025,11,9,1947,87,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(487,46,2025,1,12,765,-149,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(488,46,2025,2,13,792,204,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(489,46,2025,3,10,2162,35,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(490,46,2025,4,33,2022,168,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(491,46,2025,5,10,1217,85,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(492,46,2025,6,21,1822,215,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(493,46,2025,7,33,1924,232,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(494,46,2025,8,1,2222,235,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(495,46,2025,9,9,1981,157,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(496,46,2025,10,26,1225,20,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(497,47,2025,11,19,1290,50,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(498,47,2025,1,39,1523,165,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(499,47,2025,2,1,1758,64,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(500,47,2025,3,45,731,163,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(501,47,2025,4,7,2366,217,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(502,47,2025,5,27,1553,-110,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(503,47,2025,6,13,1954,228,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(504,47,2025,7,20,765,-38,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(505,47,2025,8,8,2176,-12,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(506,47,2025,9,43,1479,57,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(507,47,2025,10,2,1958,230,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(508,48,2025,11,1,2418,-65,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(509,48,2025,1,50,1380,-111,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(510,48,2025,2,40,2250,-141,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(511,48,2025,3,49,832,25,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(512,48,2025,4,1,2086,55,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(513,48,2025,5,14,1918,-137,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(514,48,2025,6,48,2160,177,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(515,48,2025,7,42,2033,-99,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(516,48,2025,8,26,1970,239,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(517,48,2025,9,7,1886,197,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(518,48,2025,10,13,1253,144,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(519,49,2025,11,4,2215,111,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(520,49,2025,1,6,2294,177,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(521,49,2025,2,1,701,140,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(522,49,2025,3,37,770,173,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(523,49,2025,4,2,1752,128,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(524,49,2025,5,15,751,-97,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(525,49,2025,6,2,2019,8,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(526,49,2025,7,18,1064,181,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(527,49,2025,8,12,1625,166,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(528,49,2025,9,49,831,89,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(529,49,2025,10,16,1634,169,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(530,50,2025,11,12,1744,135,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(531,50,2025,1,38,2386,204,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(532,50,2025,2,26,2083,81,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(533,50,2025,3,7,1133,1,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(534,50,2025,4,17,715,-142,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(535,50,2025,5,2,2035,41,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(536,50,2025,6,24,1095,13,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(537,50,2025,7,11,1265,213,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(538,50,2025,8,20,1909,15,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(539,50,2025,9,40,742,30,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(540,50,2025,10,35,758,105,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(541,51,2025,11,25,841,-13,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(542,51,2025,1,29,945,93,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(543,51,2025,2,39,1531,1,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(544,51,2025,3,4,1325,230,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(545,51,2025,4,35,2009,-130,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(546,51,2025,5,35,785,96,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(547,51,2025,6,6,2184,-138,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(548,51,2025,7,19,784,203,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(549,51,2025,8,27,1983,234,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(550,51,2025,9,4,1188,212,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(551,51,2025,10,49,796,-73,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(552,52,2025,11,15,1603,7,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(553,52,2025,1,43,926,168,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(554,52,2025,2,1,1279,-108,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(555,52,2025,3,16,1007,-39,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(556,52,2025,4,2,1781,168,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(557,52,2025,5,45,2359,129,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(558,52,2025,6,22,2083,237,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(559,52,2025,7,24,866,246,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(560,52,2025,8,41,1555,28,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(561,52,2025,9,20,1760,98,'2025-11-22 17:26:20','2025-11-22 17:26:20'),
(562,52,2025,10,44,1367,-55,'2025-11-22 17:26:20','2025-11-22 17:26:20');
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,1,'match_result','Match Result','You won against Erik Lindqvist! Your ranking increased by 15 points.','{\"match_id\":1,\"opponent\":\"Erik Lindqvist\",\"points\":15}',NULL,NULL,'2025-11-22 16:32:08','2025-11-22 16:37:08'),
(2,1,'ranking_update','Ranking Update','Your monthly ranking has been updated. You are now ranked #42 in your region.','{\"rank\":42,\"region\":\"Stockholm\"}',NULL,NULL,'2025-11-22 14:37:08','2025-11-22 16:37:08'),
(3,1,'achievement','Achievement Unlocked!','Congratulations! You\'ve won 10 matches this month. Keep it up!','{\"achievement\":\"win_streak_10\"}',NULL,NULL,'2025-11-22 11:37:08','2025-11-22 16:37:08'),
(4,1,'match_result','Match Result','You lost against Anna Svensson. Your ranking decreased by 8 points.','{\"match_id\":2,\"opponent\":\"Anna Svensson\",\"points\":-8}',NULL,'2025-11-22 15:37:08','2025-11-21 16:37:08','2025-11-22 16:37:08'),
(5,1,'system','Welcome to iRacket!','Welcome to iRacket! Start by recording your first match to see your ranking.',NULL,NULL,'2025-11-20 16:37:08','2025-11-19 16:37:08','2025-11-22 16:37:08'),
(6,1,'bubbler','Bubbler Update','You made it to the top 3 in your class last month! Check out the Bubbler rankings.','{\"position\":2,\"class\":\"Class 4\"}',NULL,NULL,'2025-11-22 08:37:08','2025-11-22 16:37:08'),
(7,1,'follow','New Follower','Marcus Johansson started following you.','{\"follower_id\":5,\"follower_name\":\"Marcus Johansson\"}',NULL,'2025-11-22 04:37:08','2025-11-20 16:37:08','2025-11-22 16:37:08'),
(8,2,'match_result','Match Result','You won against Erik Lindqvist! Your ranking increased by 15 points.','\"{\\\"match_id\\\":1,\\\"opponent\\\":\\\"Erik Lindqvist\\\",\\\"points\\\":15}\"',NULL,'2025-11-23 06:58:33','2025-11-22 16:39:46','2025-11-23 06:58:33'),
(9,2,'ranking_update','Ranking Update','Your monthly ranking has been updated. You are now ranked #42 in your region.','\"{\\\"rank\\\":42,\\\"region\\\":\\\"Stockholm\\\"}\"',NULL,'2025-11-23 06:58:33','2025-11-22 16:39:46','2025-11-23 06:58:33'),
(10,2,'achievement','Achievement Unlocked!','Congratulations! You\'ve won 10 matches this month. Keep it up!','\"{\\\"achievement\\\":\\\"win_streak_10\\\"}\"',NULL,'2025-11-22 16:58:29','2025-11-22 16:39:46','2025-11-22 16:58:29'),
(11,2,'match_result','Match Result','You lost against Anna Svensson. Your ranking decreased by 8 points.','\"{\\\"match_id\\\":2,\\\"opponent\\\":\\\"Anna Svensson\\\",\\\"points\\\":-8}\"',NULL,'2025-11-22 15:39:46','2025-11-22 16:39:46','2025-11-22 16:39:46'),
(12,2,'system','Welcome to iRacket!','Welcome to iRacket! Start by recording your first match to see your ranking.',NULL,NULL,'2025-11-20 16:39:46','2025-11-22 16:39:46','2025-11-22 16:39:46'),
(13,2,'bubbler','Bubbler Update','You made it to the top 3 in your class last month! Check out the Bubbler rankings.','\"{\\\"position\\\":2,\\\"class\\\":\\\"Class 4\\\"}\"',NULL,'2025-11-23 06:58:33','2025-11-22 16:39:46','2025-11-23 06:58:33'),
(14,2,'follow','New Follower','Marcus Johansson started following you.','\"{\\\"follower_id\\\":5,\\\"follower_name\\\":\\\"Marcus Johansson\\\"}\"',NULL,'2025-11-22 04:39:46','2025-11-22 16:39:46','2025-11-22 16:39:46');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES
('info@weboook.co.uk','$2y$12$vqywvpr/EJnBRvatb2VP4.RQ4hWPLIpqfBFogkWy5E9l8W4uA7k56','2025-11-22 16:23:41');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2025-11-22 17:06:07','2025-11-22 17:06:07'),
(2,'Manager','web','2025-11-22 17:06:07','2025-11-22 17:06:07');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=147798 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=751 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
INSERT INTO `scraper_logs` VALUES
(196,202,'info','Starting scrape','{\"gender\":\"male\",\"period\":\"2025.11.01\"}','2025-11-22 23:10:10','2025-11-22 23:10:10'),
(197,202,'info','Starting rankings scrape for gender: male','[]','2025-11-22 23:10:10','2025-11-22 23:10:10'),
(198,202,'warning','Retry attempt 1/3','{\"context\":\"Click rankings menu\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/sbtf\\\\\\/\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function () {\\\\n    const element = document.querySelector(\'\\\\\'\'#hoved-meny > li:nth-child(4) > a\'\\\\\'\');\\\\n    if (element) {\\\\n        element.click();\\\\n        await new Promise(resolve => setTimeout(resolve, 500));\\\\n    }\\\\n    return true;\\\\n})();\\\",\\\"args\\\":[],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\/public\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Failed to launch the browser process:  Code: null\\n\\nstderr:\\nrosetta error: failed to open elf at \\/lib64\\/ld-linux-x86-64.so.2\\n\\nTROUBLESHOOTING: https:\\/\\/pptr.dev\\/troubleshooting\\n\\n    at ChildProcess.onClose (\\/usr\\/local\\/lib\\/node_modules\\/puppeteer\\/node_modules\\/@puppeteer\\/browsers\\/lib\\/cjs\\/launch.js:340:24)\\n    at ChildProcess.emit (node:events:531:35)\\n    at ChildProcess._handle.onexit (node:internal\\/child_process:293:12)\\n\",\"delay_seconds\":60}','2025-11-22 23:10:10','2025-11-22 23:10:10'),
(199,202,'warning','Retry attempt 2/3','{\"context\":\"Click rankings menu\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/sbtf\\\\\\/\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function () {\\\\n    const element = document.querySelector(\'\\\\\'\'#hoved-meny > li:nth-child(4) > a\'\\\\\'\');\\\\n    if (element) {\\\\n        element.click();\\\\n        await new Promise(resolve => setTimeout(resolve, 500));\\\\n    }\\\\n    return true;\\\\n})();\\\",\\\"args\\\":[],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\/public\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Failed to launch the browser process:  Code: null\\n\\nstderr:\\nrosetta error: failed to open elf at \\/lib64\\/ld-linux-x86-64.so.2\\n\\nTROUBLESHOOTING: https:\\/\\/pptr.dev\\/troubleshooting\\n\\n    at ChildProcess.onClose (\\/usr\\/local\\/lib\\/node_modules\\/puppeteer\\/node_modules\\/@puppeteer\\/browsers\\/lib\\/cjs\\/launch.js:340:24)\\n    at ChildProcess.emit (node:events:531:35)\\n    at ChildProcess._handle.onexit (node:internal\\/child_process:293:12)\\n\",\"delay_seconds\":300}','2025-11-22 23:11:11','2025-11-22 23:11:11'),
(209,202,'error','Scrape failed','{\"message\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/sbtf\\\\\\/\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function () {\\\\n    const element = document.querySelector(\'\\\\\'\'#hoved-meny > li:nth-child(4) > a\'\\\\\'\');\\\\n    if (element) {\\\\n        element.click();\\\\n        await new Promise(resolve => setTimeout(resolve, 500));\\\\n    }\\\\n    return true;\\\\n})();\\\",\\\"args\\\":[],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\/public\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Could not find Chrome (ver. 142.0.7444.175). This can occur if either\\n 1. you did not perform an installation before running the script (e.g. `npx puppeteer browsers install chrome-headless-shell`) or\\n 2. your cache path is incorrectly configured (which is: \\/home\\/jovanamihajlovikj\\/.cache\\/puppeteer).\\nFor (2), check out our guide on configuring puppeteer at https:\\/\\/pptr.dev\\/guides\\/configuration.\\n    at ChromeLauncher.resolveExecutablePath (\\/usr\\/local\\/lib\\/node_modules\\/puppeteer\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:333:27)\\n    at ChromeLauncher.computeLaunchArguments (\\/usr\\/local\\/lib\\/node_modules\\/puppeteer\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/ChromeLauncher.js:93:24)\\n    at async ChromeLauncher.launch (\\/usr\\/local\\/lib\\/node_modules\\/puppeteer\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:85:28)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"trace\":\"#0 \\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/Browsershot.php(757): Spatie\\\\Browsershot\\\\Browsershot->callBrowser()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(38): Spatie\\\\Browsershot\\\\Browsershot->evaluate()\\n#2 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(91): App\\\\Services\\\\Scraper\\\\RankingsScraper->App\\\\Services\\\\Scraper\\\\{closure}()\\n#3 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(37): App\\\\Services\\\\Scraper\\\\BaseScraperService->withRetry()\\n#4 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#5 \\/var\\/www\\/html\\/app\\/Jobs\\/Scraper\\/ScrapeRankingsJob.php(30): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Jobs\\\\Scraper\\\\ScrapeRankingsJob->handle()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::Illuminate\\\\Container\\\\{closure}()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Bus\\/Dispatcher.php(129): Illuminate\\\\Container\\\\Container->call()\\n#12 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(180): Illuminate\\\\Bus\\\\Dispatcher->Illuminate\\\\Bus\\\\{closure}()\\n#13 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(137): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Bus\\/Dispatcher.php(133): Illuminate\\\\Pipeline\\\\Pipeline->then()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Queue\\/CallQueuedHandler.php(134): Illuminate\\\\Bus\\\\Dispatcher->dispatchNow()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(180): Illuminate\\\\Queue\\\\CallQueuedHandler->Illuminate\\\\Queue\\\\{closure}()\\n#17 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(137): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#18 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Queue\\/CallQueuedHandler.php(127): Illuminate\\\\Pipeline\\\\Pipeline->then()\\n#19 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Queue\\/CallQueuedHandler.php(68): Illuminate\\\\Queue\\\\CallQueuedHandler->dispatchThroughMiddleware()\\n#20 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Queue\\/Jobs\\/Job.php(102): Illuminate\\\\Queue\\\\CallQueuedHandler->call()\\n#21 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Queue\\/SyncQueue.php(130): Illuminate\\\\Queue\\\\Jobs\\\\Job->fire()\\n#22 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Queue\\/SyncQueue.php(110): Illuminate\\\\Queue\\\\SyncQueue->executeJob()\\n#23 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Bus\\/Dispatcher.php(246): Illuminate\\\\Queue\\\\SyncQueue->push()\\n#24 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Bus\\/Dispatcher.php(230): Illuminate\\\\Bus\\\\Dispatcher->pushCommandToQueue()\\n#25 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Bus\\/Dispatcher.php(80): Illuminate\\\\Bus\\\\Dispatcher->dispatchToQueue()\\n#26 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Bus\\/PendingDispatch.php(251): Illuminate\\\\Bus\\\\Dispatcher->dispatch()\\n#27 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Bus\\/Dispatchable.php(19): Illuminate\\\\Foundation\\\\Bus\\\\PendingDispatch->__destruct()\\n#28 \\/var\\/www\\/html\\/app\\/Livewire\\/Admin\\/Scraper\\/Index.php(136): App\\\\Jobs\\\\Scraper\\\\ScrapeRankingsJob::dispatch()\\n#29 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Livewire\\\\Admin\\\\Scraper\\\\Index->triggerFullScrape()\\n#30 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::Illuminate\\\\Container\\\\{closure}()\\n#31 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#32 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#33 \\/var\\/www\\/html\\/vendor\\/livewire\\/livewire\\/src\\/Wrapped.php(23): Illuminate\\\\Container\\\\BoundMethod::call()\\n#34 \\/var\\/www\\/html\\/vendor\\/livewire\\/livewire\\/src\\/Mechanisms\\/HandleComponents\\/HandleComponents.php(492): Livewire\\\\Wrapped->__call()\\n#35 \\/var\\/www\\/html\\/vendor\\/livewire\\/livewire\\/src\\/Mechanisms\\/HandleComponents\\/HandleComponents.php(101): Livewire\\\\Mechanisms\\\\HandleComponents\\\\HandleComponents->callMethods()\\n#36 \\/var\\/www\\/html\\/vendor\\/livewire\\/livewire\\/src\\/LivewireManager.php(102): Livewire\\\\Mechanisms\\\\HandleComponents\\\\HandleComponents->update()\\n#37 \\/var\\/www\\/html\\/vendor\\/livewire\\/volt\\/src\\/LivewireManager.php(35): Livewire\\\\LivewireManager->update()\\n#38 \\/var\\/www\\/html\\/vendor\\/livewire\\/livewire\\/src\\/Mechanisms\\/HandleRequests\\/HandleRequests.php(94): Livewire\\\\Volt\\\\LivewireManager->update()\\n#39 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/ControllerDispatcher.php(46): Livewire\\\\Mechanisms\\\\HandleRequests\\\\HandleRequests->handleUpdate()\\n#40 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php(265): Illuminate\\\\Routing\\\\ControllerDispatcher->dispatch()\\n#41 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Route.php(211): Illuminate\\\\Routing\\\\Route->runController()\\n#42 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php(822): Illuminate\\\\Routing\\\\Route->run()\\n#43 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(180): Illuminate\\\\Routing\\\\Router->Illuminate\\\\Routing\\\\{closure}()\\n#44 \\/var\\/www\\/html\\/app\\/Http\\/Middleware\\/SetLocale.php(20): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#45 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): App\\\\Http\\\\Middleware\\\\SetLocale->handle()\\n#46 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Middleware\\/SubstituteBindings.php(50): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#47 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Routing\\\\Middleware\\\\SubstituteBindings->handle()\\n#48 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/VerifyCsrfToken.php(87): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#49 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Foundation\\\\Http\\\\Middleware\\\\VerifyCsrfToken->handle()\\n#50 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/View\\/Middleware\\/ShareErrorsFromSession.php(48): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#51 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\View\\\\Middleware\\\\ShareErrorsFromSession->handle()\\n#52 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Session\\/Middleware\\/StartSession.php(120): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#53 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Session\\/Middleware\\/StartSession.php(63): Illuminate\\\\Session\\\\Middleware\\\\StartSession->handleStatefulRequest()\\n#54 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Session\\\\Middleware\\\\StartSession->handle()\\n#55 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Cookie\\/Middleware\\/AddQueuedCookiesToResponse.php(36): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#56 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Cookie\\\\Middleware\\\\AddQueuedCookiesToResponse->handle()\\n#57 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Cookie\\/Middleware\\/EncryptCookies.php(74): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#58 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Cookie\\\\Middleware\\\\EncryptCookies->handle()\\n#59 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(137): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#60 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php(821): Illuminate\\\\Pipeline\\\\Pipeline->then()\\n#61 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php(800): Illuminate\\\\Routing\\\\Router->runRouteWithinStack()\\n#62 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php(764): Illuminate\\\\Routing\\\\Router->runRoute()\\n#63 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Routing\\/Router.php(753): Illuminate\\\\Routing\\\\Router->dispatchToRoute()\\n#64 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php(200): Illuminate\\\\Routing\\\\Router->dispatch()\\n#65 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(180): Illuminate\\\\Foundation\\\\Http\\\\Kernel->Illuminate\\\\Foundation\\\\Http\\\\{closure}()\\n#66 \\/var\\/www\\/html\\/vendor\\/livewire\\/livewire\\/src\\/Features\\/SupportDisablingBackButtonCache\\/DisableBackButtonCacheMiddleware.php(19): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#67 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Livewire\\\\Features\\\\SupportDisablingBackButtonCache\\\\DisableBackButtonCacheMiddleware->handle()\\n#68 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/ConvertEmptyStringsToNull.php(27): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#69 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Foundation\\\\Http\\\\Middleware\\\\ConvertEmptyStringsToNull->handle()\\n#70 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/TrimStrings.php(47): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#71 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Foundation\\\\Http\\\\Middleware\\\\TrimStrings->handle()\\n#72 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/ValidatePostSize.php(27): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#73 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Http\\\\Middleware\\\\ValidatePostSize->handle()\\n#74 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/PreventRequestsDuringMaintenance.php(109): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#75 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Foundation\\\\Http\\\\Middleware\\\\PreventRequestsDuringMaintenance->handle()\\n#76 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/HandleCors.php(48): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#77 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Http\\\\Middleware\\\\HandleCors->handle()\\n#78 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/TrustProxies.php(58): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#79 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Http\\\\Middleware\\\\TrustProxies->handle()\\n#80 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Middleware\\/InvokeDeferredCallbacks.php(22): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#81 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Foundation\\\\Http\\\\Middleware\\\\InvokeDeferredCallbacks->handle()\\n#82 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Http\\/Middleware\\/ValidatePathEncoding.php(26): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#83 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(219): Illuminate\\\\Http\\\\Middleware\\\\ValidatePathEncoding->handle()\\n#84 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Pipeline\\/Pipeline.php(137): Illuminate\\\\Pipeline\\\\Pipeline->Illuminate\\\\Pipeline\\\\{closure}()\\n#85 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php(175): Illuminate\\\\Pipeline\\\\Pipeline->then()\\n#86 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Http\\/Kernel.php(144): Illuminate\\\\Foundation\\\\Http\\\\Kernel->sendRequestThroughRouter()\\n#87 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1220): Illuminate\\\\Foundation\\\\Http\\\\Kernel->handle()\\n#88 \\/var\\/www\\/html\\/public\\/index.php(20): Illuminate\\\\Foundation\\\\Application->handleRequest()\\n#89 {main}\"}','2025-11-22 23:16:11','2025-11-22 23:16:11');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
INSERT INTO `scraper_runs` VALUES
(202,'rankings','failed','{\"gender\":\"male\",\"period\":\"2025.11.01\"}',0,1,'The command \"PATH=$PATH:/usr/local/bin:/opt/homebrew/bin NODE_PATH=$(\"/usr/local/bin/node\" \"/usr/local/bin/npm\" root -g) \"/usr/local/bin/node\" \'/var/www/html/vendor/spatie/browsershot/src/../bin/browser.cjs\' \'{\"url\":\"https:\\/\\/www.profixio.com\\/fx\\/sbtf\\/\",\"action\":\"evaluate\",\"options\":{\"pageFunction\":\"(async function () {\\n    const element = document.querySelector(\'\\\'\'#hoved-meny > li:nth-child(4) > a\'\\\'\');\\n    if (element) {\\n        element.click();\\n        await new Promise(resolve => setTimeout(resolve, 500));\\n    }\\n    return true;\\n})();\",\"args\":[],\"viewport\":{\"width\":800,\"height\":600},\"timeout\":60000000,\"waitUntil\":\"networkidle0\"}}\'\" failed.\n\nExit Code: 1(General error)\n\nWorking directory: /var/www/html/public\n\nOutput:\n================\n\n\nError Output:\n================\nError: Could not find Chrome (ver. 142.0.7444.175). This can occur if either\n 1. you did not perform an installation before running the script (e.g. `npx puppeteer browsers install chrome-headless-shell`) or\n 2. your cache path is incorrectly configured (which is: /home/jovanamihajlovikj/.cache/puppeteer).\nFor (2), check out our guide on configuring puppeteer at https://pptr.dev/guides/configuration.\n    at ChromeLauncher.resolveExecutablePath (/usr/local/lib/node_modules/puppeteer/node_modules/puppeteer-core/lib/cjs/puppeteer/node/BrowserLauncher.js:333:27)\n    at ChromeLauncher.computeLaunchArguments (/usr/local/lib/node_modules/puppeteer/node_modules/puppeteer-core/lib/cjs/puppeteer/node/ChromeLauncher.js:93:24)\n    at async ChromeLauncher.launch (/usr/local/lib/node_modules/puppeteer/node_modules/puppeteer-core/lib/cjs/puppeteer/node/BrowserLauncher.js:85:28)\n    at async callChrome (/var/www/html/vendor/spatie/browsershot/bin/browser.cjs:102:23)\n','2025-11-22 23:10:10','2025-11-22 23:16:11','2025-11-22 23:10:10','2025-11-22 23:16:11');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php','string','urls','URL for players list scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2025-11-23 07:48:24','2025-11-23 07:48:24'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2025-11-23 07:55:23','2025-11-23 07:55:23'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2025-11-23 07:55:23','2025-11-23 07:55:23');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
INSERT INTO `terms` VALUES
(1,'{\"en\":\"Terms and Conditions\"}','terms-and-conditions','{\"en\":\"\\n                <h1>Terms and Conditions<\\/h1>\\n                <p><strong>Last updated:<\\/strong> November 22, 2025<\\/p>\\n\\n                <h2>1. Acceptance of Terms<\\/h2>\\n                <p>By accessing and using iRacket, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.<\\/p>\\n\\n                <h2>2. Use License<\\/h2>\\n                <p>Permission is granted to temporarily use iRacket for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:<\\/p>\\n                <ul>\\n                    <li>modify or copy the materials;<\\/li>\\n                    <li>use the materials for any commercial purpose, or for any public display (commercial or non-commercial);<\\/li>\\n                    <li>attempt to decompile or reverse engineer any software contained on iRacket;<\\/li>\\n                    <li>remove any copyright or other proprietary notations from the materials; or<\\/li>\\n                    <li>transfer the materials to another person or \\\"mirror\\\" the materials on any other server.<\\/li>\\n                <\\/ul>\\n\\n                <h2>3. User Account<\\/h2>\\n                <p>To use certain features of iRacket, you must register for an account. You agree to provide accurate, current, and complete information during the registration process and to update such information to keep it accurate, current, and complete.<\\/p>\\n\\n                <h2>4. User Conduct<\\/h2>\\n                <p>You agree not to use iRacket to:<\\/p>\\n                <ul>\\n                    <li>Upload, post, or transmit any content that is unlawful, harmful, threatening, abusive, harassing, defamatory, vulgar, obscene, or otherwise objectionable;<\\/li>\\n                    <li>Impersonate any person or entity;<\\/li>\\n                    <li>Upload, post, or transmit any content that infringes any patent, trademark, trade secret, copyright, or other proprietary rights;<\\/li>\\n                    <li>Upload, post, or transmit any unsolicited or unauthorized advertising, promotional materials, or any other form of solicitation.<\\/li>\\n                <\\/ul>\\n\\n                <h2>5. Disclaimer<\\/h2>\\n                <p>The materials on iRacket are provided on an \\\"as is\\\" basis. iRacket makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.<\\/p>\\n\\n                <h2>6. Limitations<\\/h2>\\n                <p>In no event shall iRacket or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use iRacket.<\\/p>\\n\\n                <h2>7. Modifications<\\/h2>\\n                <p>iRacket may revise these terms of service at any time without notice. By using this application you are agreeing to be bound by the then current version of these terms of service.<\\/p>\\n\\n                <h2>8. Governing Law<\\/h2>\\n                <p>These terms and conditions are governed by and construed in accordance with the laws and you irrevocably submit to the exclusive jurisdiction of the courts in that location.<\\/p>\\n\\n                <h2>9. Contact Us<\\/h2>\\n                <p>If you have any questions about these Terms and Conditions, please contact us at support@iracket.com.<\\/p>\\n            \"}',1,'2025-11-22 16:05:42','2025-11-22 16:05:42'),
(2,'{\"en\":\"Privacy Policy\"}','privacy-policy','{\"en\":\"\\n                <h1>Privacy Policy<\\/h1>\\n                <p><strong>Last updated:<\\/strong> November 22, 2025<\\/p>\\n\\n                <h2>1. Introduction<\\/h2>\\n                <p>Welcome to iRacket. We respect your privacy and are committed to protecting your personal data. This privacy policy will inform you about how we look after your personal data and tell you about your privacy rights.<\\/p>\\n\\n                <h2>2. Information We Collect<\\/h2>\\n                <p>We may collect, use, store and transfer different kinds of personal data about you which we have grouped together as follows:<\\/p>\\n                <ul>\\n                    <li><strong>Identity Data<\\/strong> includes first name, last name, username or similar identifier.<\\/li>\\n                    <li><strong>Contact Data<\\/strong> includes email address and telephone numbers.<\\/li>\\n                    <li><strong>Technical Data<\\/strong> includes internet protocol (IP) address, your login data, browser type and version, time zone setting and location.<\\/li>\\n                    <li><strong>Profile Data<\\/strong> includes your username and password, your interests, preferences, feedback and survey responses.<\\/li>\\n                    <li><strong>Usage Data<\\/strong> includes information about how you use our website and services.<\\/li>\\n                <\\/ul>\\n\\n                <h2>3. How We Use Your Information<\\/h2>\\n                <p>We will only use your personal data when the law allows us to. Most commonly, we will use your personal data in the following circumstances:<\\/p>\\n                <ul>\\n                    <li>To register you as a new customer.<\\/li>\\n                    <li>To process and deliver your service.<\\/li>\\n                    <li>To manage our relationship with you.<\\/li>\\n                    <li>To improve our website, products\\/services, marketing or customer relationships.<\\/li>\\n                    <li>To recommend products or services which may be of interest to you.<\\/li>\\n                <\\/ul>\\n\\n                <h2>4. Data Security<\\/h2>\\n                <p>We have put in place appropriate security measures to prevent your personal data from being accidentally lost, used or accessed in an unauthorized way, altered or disclosed. In addition, we limit access to your personal data to those employees, agents, contractors and other third parties who have a business need to know.<\\/p>\\n\\n                <h2>5. Data Retention<\\/h2>\\n                <p>We will only retain your personal data for as long as necessary to fulfil the purposes we collected it for, including for the purposes of satisfying any legal, accounting, or reporting requirements.<\\/p>\\n\\n                <h2>6. Your Legal Rights<\\/h2>\\n                <p>Under certain circumstances, you have rights under data protection laws in relation to your personal data, including the right to:<\\/p>\\n                <ul>\\n                    <li>Request access to your personal data.<\\/li>\\n                    <li>Request correction of your personal data.<\\/li>\\n                    <li>Request erasure of your personal data.<\\/li>\\n                    <li>Object to processing of your personal data.<\\/li>\\n                    <li>Request restriction of processing your personal data.<\\/li>\\n                    <li>Request transfer of your personal data.<\\/li>\\n                    <li>Right to withdraw consent.<\\/li>\\n                <\\/ul>\\n\\n                <h2>7. Third-Party Links<\\/h2>\\n                <p>This website may include links to third-party websites, plug-ins and applications. Clicking on those links or enabling those connections may allow third parties to collect or share data about you. We do not control these third-party websites and are not responsible for their privacy statements.<\\/p>\\n\\n                <h2>8. Cookies<\\/h2>\\n                <p>We use cookies to distinguish you from other users of our website. This helps us to provide you with a good experience when you browse our website and also allows us to improve our site.<\\/p>\\n\\n                <h2>9. Changes to This Privacy Policy<\\/h2>\\n                <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the \\\"Last updated\\\" date.<\\/p>\\n\\n                <h2>10. Contact Us<\\/h2>\\n                <p>If you have any questions about this Privacy Policy, please contact us at privacy@iracket.com.<\\/p>\\n            \"}',1,'2025-11-22 16:05:42','2025-11-22 16:05:42'),
(3,'{\"en\":\"Bubbler\"}','bubbler','{\"en\":\"\\n                    <h1>What is Bubbler?<\\/h1>\\n                    <p>Bubbler is about who was the best the previous month.<\\/p>\\n\\n                    <h2>How do you know if you\'ve been the best?<\\/h2>\\n                    <p>Well, it\'s about who got the most points the previous month, and it\'s the most points in their range.<\\/p>\\n\\n                    <p>The ranges are: 0-499, 500-999, 1000-1249, 1250-1499, 1500-1749, 1750-1999, 2000-2249, 2250 and up.<\\/p>\\n\\n                    <p>We show the top three in each segment and region. The default is within your own range and region.<\\/p>\\n\\n                    <h2>Interval for Women<\\/h2>\\n                    <ul>\\n                        <li><strong>Elite class:<\\/strong> At least 1750 points<\\/li>\\n                        <li><strong>Class 1:<\\/strong> 1500-1749 points<\\/li>\\n                        <li><strong>Class 2:<\\/strong> 1250-1499 points<\\/li>\\n                        <li><strong>Class 3:<\\/strong> 1000-1249 points<\\/li>\\n                        <li><strong>Class 4:<\\/strong> 750-999 points<\\/li>\\n                        <li><strong>Class 5:<\\/strong> Maximum 749 points<\\/li>\\n                    <\\/ul>\\n\\n                    <h2>Interval for Men<\\/h2>\\n                    <ul>\\n                        <li><strong>Elite:<\\/strong> At least 2250 points<\\/li>\\n                        <li><strong>Class 1:<\\/strong> 2000-2249 points<\\/li>\\n                        <li><strong>Class 2:<\\/strong> 1750-1999 points<\\/li>\\n                        <li><strong>Class 3:<\\/strong> 1500-1749 points<\\/li>\\n                        <li><strong>Class 4:<\\/strong> 1250-1499 points<\\/li>\\n                        <li><strong>Class 5:<\\/strong> 1000-1249 points<\\/li>\\n                        <li><strong>Class 6:<\\/strong> 750-999 points<\\/li>\\n                        <li><strong>Class 7:<\\/strong> Maximum 749 points<\\/li>\\n                    <\\/ul>\\n\\n                    <p>If you get, for example, 100 points one month and go over the range, you will appear in your previous range.<\\/p>\\n\\n                    <p>Bubblers are simply different lists based on rankings combined with gender, age, geography, etc. We want to build a number of lists that we publish on different pages.<\\/p>\\n\\n                    <h2>How Points are Calculated<\\/h2>\\n                    <p>When a user enters new match statistics, the system implements the following logic:<\\/p>\\n                    <ol>\\n                        <li>Calculate the ranking point difference between the players playing the match.<\\/li>\\n                        <li>Check within which ranking score difference interval the result belongs.<\\/li>\\n                        <li>Check which player is the winner and whether it was with higher ranking points or lower ranking points, before the match.<\\/li>\\n                        <li>Increase and decrease the points according to the winner and loser of the match, based on the official figures below.<\\/li>\\n                    <\\/ol>\\n\\n                    <h2>Points Table<\\/h2>\\n                    <table style=\\\"width: 100%; border-collapse: collapse; margin: 1rem 0;\\\">\\n                        <thead>\\n                            <tr style=\\\"border-bottom: 2px solid #404040;\\\">\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Point Difference<\\/th>\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Higher Ranked Wins<\\/th>\\n                                <th style=\\\"text-align: left; padding: 0.75rem; color: #fafafa;\\\">Lower Ranked Wins<\\/th>\\n                            <\\/tr>\\n                        <\\/thead>\\n                        <tbody>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">0 - 25<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">10 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">10 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">26 - 50<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">9 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">11 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">51 - 75<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">8 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">12 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">76 - 100<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">7 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">13 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">101 - 125<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">6 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">15 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">126 - 150<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">6 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">16 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">151 - 200<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">5 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">17 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">201 - 250<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">4 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">18 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">251 - 300<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">3 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">19 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">301 - 400<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">20 points<\\/td>\\n                            <\\/tr>\\n                            <tr style=\\\"border-bottom: 1px solid #404040;\\\">\\n                                <td style=\\\"padding: 0.75rem;\\\">401 - 500<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">30 points<\\/td>\\n                            <\\/tr>\\n                            <tr>\\n                                <td style=\\\"padding: 0.75rem;\\\">501 and up<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">2 points<\\/td>\\n                                <td style=\\\"padding: 0.75rem;\\\">40 points<\\/td>\\n                            <\\/tr>\\n                        <\\/tbody>\\n                    <\\/table>\\n\\n                    <p>The winner receives plus points and the loser receives the same number of minus points according to the table.<\\/p>\\n\\n                    <h2>Example<\\/h2>\\n                    <p><strong>Player 1:<\\/strong> 1100 points<br>\\n                    <strong>Player 2:<\\/strong> 1300 points<\\/p>\\n\\n                    <p>The difference in points = 1300 - 1100 = <strong>200 points<\\/strong><\\/p>\\n\\n                    <p>Based on the table above (151-200 range):<\\/p>\\n                    <ul>\\n                        <li><strong>If Player 1 wins:<\\/strong> Player 1 will have 1117 points (+17) and Player 2 will have 1283 points (-17)<\\/li>\\n                        <li><strong>If Player 2 wins:<\\/strong> Player 1 will have 1095 points (-5) and Player 2 will have 1305 points (+5)<\\/li>\\n                    <\\/ul>\\n\\n                    <p>Bubblers are lists based on different listings. We place different lists on various pages throughout the application.<\\/p>\\n                \"}',1,'2025-11-22 16:16:52','2025-11-22 16:16:52'),
(4,'{\"en\":\"About Us\"}','about','{\"en\":\"\\n                    <h1>About Us<\\/h1>\\n                    <p>Welcome to i-Racket, what rankings should be and a little more.<\\/p>\\n\\n                    <p>We are passionate table tennis players who have created this app to bring together and strengthen the table tennis community throughout Sweden. i-Racket is your ultimate companion for everything related to table tennis rankings, whether you are a beginner or an experienced player.<\\/p>\\n\\n                    <h2>Our Vision<\\/h2>\\n                    <p>We strive to promote and develop table tennis in Sweden by offering a platform that enables community, competition, ranking and engagement. Our vision is to highlight table tennis with a focus on ranking and thus encourage growth in the sport.<\\/p>\\n\\n                    <h2>What i-Racket Offers<\\/h2>\\n                    <ul>\\n                        <li><strong>Real-time rankings:<\\/strong> Every match you publish generates your new ranking. You can immediately see how you can climb the rankings or fight to maintain your position.<\\/li>\\n                        <li><strong>Monthly Rankings:<\\/strong> We retrieve and secure your ranking from the official industry body.<\\/li>\\n                        <li><strong>Follow your Favorite Players:<\\/strong> Follow your favorite players and friends. Get updates on their latest matches and achievements.<\\/li>\\n                        <li><strong>Record your own matches:<\\/strong> Record your own matches played, and note their strengths and weaknesses. The next time you meet, you can use this information.<\\/li>\\n                        <li><strong>Bubbler:<\\/strong> We highlight the most promising players and the most prominent clubs in the country.<\\/li>\\n                        <li><strong>Follow your child:<\\/strong> As a parent, you can follow your child and their friends. You can see their progress and any awards they have won.<\\/li>\\n                    <\\/ul>\\n\\n                    <h2>Our Team<\\/h2>\\n                    <p>i-Racket is created by a dedicated team of table tennis enthusiasts. We are passionate about the sport and about creating a dynamic and user-friendly platform that helps you improve your game and experience the joy of table tennis.<\\/p>\\n\\n                    <h2>Contact<\\/h2>\\n                    <p>Do you have any questions, suggestions or just want to say hello? Don\'t hesitate to contact us at <a href=\\\"mailto:info@iracket.se\\\">info@iracket.se<\\/a><\\/p>\\n                \"}',1,'2025-11-22 16:19:19','2025-11-22 16:19:19');
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'a3a73b6b-816f-477c-aec8-1c09720392e9','Test','User',NULL,'test@example.com',NULL,NULL,NULL,3,1,NULL,NULL,'2025-11-22 16:05:41',NULL,NULL,'$2y$12$9qTwC5fmdy4DVprL68YmIebg/1SRRTkbGAXGDuld1yV6B08ZSS6Cm','3EAQdFN57H','TbjAsPFr9p','2025-11-22 16:05:41','NipgpgjE3L',NULL,NULL,NULL,1,'2025-11-22 16:05:41','2025-11-22 16:05:42','2025-11-22 17:08:01'),
(2,'db312c7b-1b97-439f-93b8-4ca9b49fc489','Andrej','Gjoshevski',NULL,'info@weboook.co.uk',NULL,NULL,NULL,2,1,NULL,NULL,'2025-11-22 21:28:18',NULL,NULL,'$2y$12$qm7.BhwkwuuB32afo7AEq.u6.ZHQlo4CKhFGdiJMawpwFB9MT.UkW',NULL,NULL,NULL,'Iabz9g7ClA5dvi2HbvAbhzdYuNt2Z5g2pBR51ub460Ii8BAuX92RBRzEOoDQ',NULL,NULL,NULL,1,'2025-11-22 16:15:48','2025-11-22 16:15:48','2025-11-22 21:28:18'),
(3,'c0ab7b6a-ff99-4ea5-aaf1-1aa7cf12fef7','Lars','Axelsson',NULL,'lars.axelsson0@example.com',NULL,'male',50,7,1,NULL,NULL,'2025-11-22 17:26:11',NULL,NULL,'$2y$12$P3juaDqGmvTNRhJ5nASCk.Bl2bZUrU8N1yij4lHWcGlt/tMIxcYF2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:11','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(4,'046a5e19-5f21-4d3f-94f2-70813e638938','Magnus','Bergström',NULL,'magnus.bergström1@example.com',NULL,'male',49,4,1,NULL,NULL,'2025-11-22 17:26:11',NULL,NULL,'$2y$12$dpPoF1sc4F3CSqta76nZMODlMe13OfFAM87yDMe5IvtZx95u3R36e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:11','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(5,'6d654a3f-f080-4235-8073-3d993012796f','Niklas','Berg',NULL,'niklas.berg2@example.com',NULL,'male',36,6,1,NULL,NULL,'2025-11-22 17:26:11',NULL,NULL,'$2y$12$05.kf.liC3Kg4K2eSCAm/.yT8rZEYYLT99b1SRWREIIzzY0/stZ3O',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:11','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(6,'ffd0a782-6873-4e22-b2df-45a61d9706dd','Oscar','Axelsson',NULL,'oscar.axelsson3@example.com',NULL,'male',48,3,1,NULL,NULL,'2025-11-22 17:26:12',NULL,NULL,'$2y$12$I5U.B1e14fbIHpcuG3n1hOmIev0s2RtwZfiFtE7W36PfUViFJaYme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:12','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(7,'b64f14b2-fec4-4e18-a8eb-5bd608c70b3d','Daniel','Hansson',NULL,'daniel.hansson4@example.com',NULL,'male',30,6,1,NULL,NULL,'2025-11-22 17:26:12',NULL,NULL,'$2y$12$CV.KIHaJjmrivpC4uUoSDeZ42qYZf/.NpDgVIU7HCUo3Tk2afBRIa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:12','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(8,'cc77c879-5a37-4160-817f-71c539107c65','Marcus','Olsson',NULL,'marcus.olsson5@example.com',NULL,'male',23,7,1,NULL,NULL,'2025-11-22 17:26:12',NULL,NULL,'$2y$12$oX8MpW1F2gQoCNN0a0LSQ.Tgu2HssaGlaodlv8Q38Y5yx.z0nycsW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:12','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(9,'1badefd5-a88d-4236-8d50-637633ec9c42','Anders','Lindström',NULL,'anders.lindström6@example.com',NULL,'male',21,4,1,NULL,NULL,'2025-11-22 17:26:12',NULL,NULL,'$2y$12$70mz7dXmHjfBJG3KztK50O90mUW./S6jh61HmF0RWltmcYnP.d/em',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:12','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(10,'0a189e83-2d2e-474d-ad59-191491db9674','Karl','Olsson',NULL,'karl.olsson7@example.com',NULL,'male',28,8,1,NULL,NULL,'2025-11-22 17:26:12',NULL,NULL,'$2y$12$7exMjwVjdYYrb5AIHIzk5uoMyXDSRewP6u5VJkOsIE97dCHRlI96C',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:12','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(11,'5e0d10da-feb3-47d5-a400-b20a6793ee9c','Peter','Pettersson',NULL,'peter.pettersson8@example.com',NULL,'male',37,3,1,NULL,NULL,'2025-11-22 17:26:12',NULL,NULL,'$2y$12$IgYb36N0A6ZeUhvPL54OweILj3CYQHqvmphtAAkLeupFReODhlqOi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:12','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(12,'461ede71-ca21-4a15-941d-161742353a28','Henrik','Lund',NULL,'henrik.lund9@example.com',NULL,'male',53,2,1,NULL,NULL,'2025-11-22 17:26:13',NULL,NULL,'$2y$12$jgYrKPh1BdUZ3ZIrs2INEurql0m4S70Vd5OwmjqwlrLS5UiVahg8y',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:13','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(13,'12213760-d8d8-4ec0-8165-8fd54690ed1c','Magnus','Karlsson',NULL,'magnus.karlsson10@example.com',NULL,'male',43,5,1,NULL,NULL,'2025-11-22 17:26:13',NULL,NULL,'$2y$12$QgqAhuBlTV6/JfC6z/tnHeJdpRbmLyy10Na8o2anWbvK8yrSNNWo.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:13','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(14,'cbaca258-ee0b-4d43-b80a-a885d3923032','Henrik','Jönsson',NULL,'henrik.jönsson11@example.com',NULL,'male',47,6,1,NULL,NULL,'2025-11-22 17:26:13',NULL,NULL,'$2y$12$SiZlj1NOnsChN3bQIt8ANunUFg3.cT1rD1.Zr1wd5gSm.GdUehc9m',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:13','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(15,'0352ca9e-4a8b-4682-a2ee-e9b65224339a','Jan','Jonsson',NULL,'jan.jonsson12@example.com',NULL,'male',22,3,1,NULL,NULL,'2025-11-22 17:26:13',NULL,NULL,'$2y$12$fN6lKCoc15rhWc53fCqmYeKuyocyqZvnll2iGR1GGp8uCCOWEQgoi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:13','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(16,'2908b305-8824-4f46-ae41-3a1e2a8084ca','Jonas','Olsson',NULL,'jonas.olsson13@example.com',NULL,'male',44,3,1,NULL,NULL,'2025-11-22 17:26:13',NULL,NULL,'$2y$12$UEOgtljicGTnkTxIhvTWFOcR0jakcAJfFIuk6evdKmR4oZDYmJdNS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:13','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(17,'b5e85cce-e2f2-4b01-b10b-41c590d6b462','David','Mattsson',NULL,'david.mattsson14@example.com',NULL,'male',19,3,1,NULL,NULL,'2025-11-22 17:26:13',NULL,NULL,'$2y$12$jpoZWMSDJ.9wofAUkRrAS.wSZETqHpiUiILLUJwYHKWiG9CC1NUSS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:13','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(18,'c27a12d5-bf48-4d06-a504-03336eb42238','David','Berg',NULL,'david.berg15@example.com',NULL,'male',33,8,1,NULL,NULL,'2025-11-22 17:26:14',NULL,NULL,'$2y$12$Gi19OysafS2l12qnIJbm.OR4NtVDdio34sYOb2W2WXR0iW01/z1vi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:14','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(19,'8d6fad54-20bb-413a-bc74-e9fcf6929285','Per','Pettersson',NULL,'per.pettersson16@example.com',NULL,'male',19,2,1,NULL,NULL,'2025-11-22 17:26:14',NULL,NULL,'$2y$12$2ZrZ9I5Ra8Yj/MvdkhP6hOai/AM7PTGg.7qfQT91YzkZCCGFAzaPq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:14','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(20,'46844e18-6118-4522-a6a7-b5c195010937','Karl','Gustafsson',NULL,'karl.gustafsson17@example.com',NULL,'male',18,3,1,NULL,NULL,'2025-11-22 17:26:14',NULL,NULL,'$2y$12$QbGNTmeaiblk8JVdgKKPPOPzhDNR2B2z1hE0YGSa0MEFhC4y5rAbm',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:14','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(21,'b42ba067-d1a4-4dd5-ab5a-60ba7bedfa90','Per','Berglund',NULL,'per.berglund18@example.com',NULL,'male',51,6,1,NULL,NULL,'2025-11-22 17:26:14',NULL,NULL,'$2y$12$2bQQ2keFef5vI5P4C49eEOOx8ylGhddxOpv9VcU30sAnJ3tDRsdR2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:14','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(22,'81aa67e8-5617-472c-87d3-470355cb3a82','Mikael','Berg',NULL,'mikael.berg19@example.com',NULL,'male',46,7,1,NULL,NULL,'2025-11-22 17:26:14',NULL,NULL,'$2y$12$1ycPzhSHg4uAgQ9YliVTj.0WlxF0mFAQaA0rvB6xb/F0y8VpeFah2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:14','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(23,'b602dfbe-089c-4eb5-a3a0-ace257a8836d','Anders','Larsson',NULL,'anders.larsson20@example.com',NULL,'male',51,2,1,NULL,NULL,'2025-11-22 17:26:14',NULL,NULL,'$2y$12$ni4NdAMYO1kHxQv2Ngg/wO11aXeG8eoVy0gBS9xQxuFgLKEPDaEtS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:14','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(24,'c50a921c-95dc-4d7e-a101-94b581dab391','Mattias','Fredriksson',NULL,'mattias.fredriksson21@example.com',NULL,'male',54,1,1,NULL,NULL,'2025-11-22 17:26:15',NULL,NULL,'$2y$12$8L7X2psXjAXwIq6ggKcRXesO/9MCBcGvOrJJrO91fL7VPyy/.F82i',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:15','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(25,'e339a744-92a7-41e4-8bc4-cbe0e958cbad','Fredrik','Fredriksson',NULL,'fredrik.fredriksson22@example.com',NULL,'male',19,5,1,NULL,NULL,'2025-11-22 17:26:15',NULL,NULL,'$2y$12$NdQU5.9DEbnpuMyqTBt04.1NIZCtnQ/JqFDsapaovOiDHhoJzHoUK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:15','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(26,'a14a49a1-6016-4831-8b46-c6581b39e22c','Henrik','Bengtsson',NULL,'henrik.bengtsson23@example.com',NULL,'male',24,1,1,NULL,NULL,'2025-11-22 17:26:15',NULL,NULL,'$2y$12$CMuPDbui3S6E5hRvzp5tZ.ar98T/lHK3gjTGQl4nLARPYlY/8OkCO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:15','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(27,'e0fa5aa9-9bc7-402f-b1e3-f5e8a10e920f','Oscar','Olsson',NULL,'oscar.olsson24@example.com',NULL,'male',33,4,1,NULL,NULL,'2025-11-22 17:26:15',NULL,NULL,'$2y$12$xfyMCKk5rtRH/z6aiYtH9u1hOG9TdHMkbh6vvYXDd.kZAb24B6VSu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:15','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(28,'0c82449f-aec5-4447-946c-0c133bcb5e8f','Lena','Eriksson',NULL,'lena.eriksson0@example.com',NULL,'female',43,3,1,NULL,NULL,'2025-11-22 17:26:15',NULL,NULL,'$2y$12$u4j1/58HDSTQ5nmPVlsuOuy0vIpGt2IQPXywNrMuJP9TculqFG/bW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:15','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(29,'43119daa-6915-4431-ad49-4fc26e79a310','Ebba','Lundberg',NULL,'ebba.lundberg1@example.com',NULL,'female',54,2,1,NULL,NULL,'2025-11-22 17:26:16',NULL,NULL,'$2y$12$FUR/9U0thuk.643MKHcz7.ip8evMwvqyRHZGdCWGrCWRBRWGJgNFa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:16','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(30,'09eea8ae-1b2f-4a05-aa5a-360f04325fa6','Amanda','Lindberg',NULL,'amanda.lindberg2@example.com',NULL,'female',30,2,1,NULL,NULL,'2025-11-22 17:26:16',NULL,NULL,'$2y$12$3/JHbfaowi.9FM/g.hIDT.DzZTXdnUjYMmzSf/3dr2PvZf9Zb7Xuq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:16','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(31,'680d7145-ae7d-4a4f-ba19-91c50a6e6469','Lisa','Berglund',NULL,'lisa.berglund3@example.com',NULL,'female',29,7,1,NULL,NULL,'2025-11-22 17:26:16',NULL,NULL,'$2y$12$ANx9NkqgLpH/CcqXtBZ.2eIX8jdDyJn6Hq1oT35Txmk3QYEFQhH3e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:16','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(32,'831d87d3-7aa7-4c47-a72b-1c2aa87cba0f','Frida','Berglund',NULL,'frida.berglund4@example.com',NULL,'female',41,8,1,NULL,NULL,'2025-11-22 17:26:16',NULL,NULL,'$2y$12$SKiyWOyaESmqB91XXm1hGeCl7DfkIWtXOBi6.4FWKUdnEdvZW8be6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:16','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(33,'05fdf864-a867-4e3e-91d6-115e5b87d37d','Sofia','Johansson',NULL,'sofia.johansson5@example.com',NULL,'female',52,2,1,NULL,NULL,'2025-11-22 17:26:16',NULL,NULL,'$2y$12$hwaDotFZ6gUC7bvvQzNWVuLwEtFN3Dl7ze1miIQB4mbTzpNaFdHHO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:16','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(34,'e2ccda4d-ce8a-4373-8a68-e4f305d66b86','Ida','Lundqvist',NULL,'ida.lundqvist6@example.com',NULL,'female',52,6,1,NULL,NULL,'2025-11-22 17:26:16',NULL,NULL,'$2y$12$S.UHGcfDPhfZ8hZn1tYUMOgGmIMXEXL4jUo39CZpBDaSVi26D2U02',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:16','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(35,'97fda3d5-a9dd-4b9f-824a-e94408068088','Emma','Pettersson',NULL,'emma.pettersson7@example.com',NULL,'female',18,3,1,NULL,NULL,'2025-11-22 17:26:17',NULL,NULL,'$2y$12$.F2HGhgPfLXYxg5sul96tue4LBKXpwNy7866dTOnM0KUh6Hc6XKXe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:17','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(36,'a1c5ba5f-9448-473b-9af5-c8a633b4653e','Frida','Lindberg',NULL,'frida.lindberg8@example.com',NULL,'female',33,6,1,NULL,NULL,'2025-11-22 17:26:17',NULL,NULL,'$2y$12$n3mQ38LNZkU.KfrVWdZKT.NFvwZhhl7xMmVApbHVqdtyKDxb7wsNu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:17','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(37,'d0d92cc8-f8a6-4da2-be55-8d7a097f7a35','Kristina','Olsson',NULL,'kristina.olsson9@example.com',NULL,'female',27,7,1,NULL,NULL,'2025-11-22 17:26:17',NULL,NULL,'$2y$12$0xoWV4MS66919gyZYzA9.uJQ0DWrhXo43HVC6ilDV8u.n20IIrjWS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:17','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(38,'c0e7cbea-69f8-4f4f-a77d-2796339ae857','Wilma','Lund',NULL,'wilma.lund10@example.com',NULL,'female',18,3,1,NULL,NULL,'2025-11-22 17:26:17',NULL,NULL,'$2y$12$VxvPJuM4SiShjU9KmE1utuhmNsh4Z.65kmNTucuetzY9aA7R6Ph8i',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:17','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(39,'f4748c40-086e-437e-ab73-0c93c7739db9','Johanna','Olsson',NULL,'johanna.olsson11@example.com',NULL,'female',41,2,1,NULL,NULL,'2025-11-22 17:26:17',NULL,NULL,'$2y$12$TvcVJ/LS5QKfEVpCxoYXEuh2up94YnIQOZbyGcJoV6chPVbhANkbG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:17','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(40,'9a4c8b99-207c-408a-817c-eaa6faf6e68d','Maria','Bergström',NULL,'maria.bergström12@example.com',NULL,'female',39,1,1,NULL,NULL,'2025-11-22 17:26:17',NULL,NULL,'$2y$12$TabKk6IoHh3F.kPcs2lGzOnrCYP9DtLIhaAy3ZlLIFlnSrL5fK4Fy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:17','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(41,'be545549-39a5-43c1-96ab-b15d1bcbdc64','Hanna','Lindqvist',NULL,'hanna.lindqvist13@example.com',NULL,'female',30,2,1,NULL,NULL,'2025-11-22 17:26:18',NULL,NULL,'$2y$12$rUjpWMOIRcd6vVTr4pbVqehJfkKI7BjtlgeNcNbR6M7Hsj.qE2kAu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:18','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(42,'1db7ea54-82bb-4a44-9333-c250d8b7051c','Frida','Gustafsson',NULL,'frida.gustafsson14@example.com',NULL,'female',50,6,1,NULL,NULL,'2025-11-22 17:26:18',NULL,NULL,'$2y$12$z/LLEVZEHtPhIKgLcyIc/Od0MD8qXxNmPJLQpk0lJ5HXxrNqJH0wy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:18','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(43,'54f3d48d-a48a-4a1d-b02f-89c0c4a35d2e','Hanna','Hansson',NULL,'hanna.hansson15@example.com',NULL,'female',38,8,1,NULL,NULL,'2025-11-22 17:26:18',NULL,NULL,'$2y$12$w4FGyYSoskoRqJGIYcHNqOb/Ej7y9/Fqv2vnsLwmoC/4998c7/G6G',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:18','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(44,'f76ac005-256c-4e92-b5fd-f7a2f4f5d095','Amanda','Hansson',NULL,'amanda.hansson16@example.com',NULL,'female',23,2,1,NULL,NULL,'2025-11-22 17:26:18',NULL,NULL,'$2y$12$OctM3ufde2sdjkBVEUbxW.ngbQtdfSkySPyV0raaIincMu3v6Gxhu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:18','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(45,'f2729925-c7cc-4543-8257-f7d8f6c174fb','Amanda','Gustafsson',NULL,'amanda.gustafsson17@example.com',NULL,'female',49,5,1,NULL,NULL,'2025-11-22 17:26:18',NULL,NULL,'$2y$12$ppNCHMXbKUcH/0WzYBvIGOCNQdj4g18txsS84Nv3B2.9FwO8h9TxK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:18','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(46,'d0a579bc-4ffe-4e58-8fb0-8c70dc441f3b','Elin','Gustafsson',NULL,'elin.gustafsson18@example.com',NULL,'female',45,8,1,NULL,NULL,'2025-11-22 17:26:19',NULL,NULL,'$2y$12$pJqwXvPhoXM/g8KTsJhdheSizR4ECY0MWcbSFJULnb5gDBUVkvjcO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:19','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(47,'e4a90fec-1080-4506-b6e2-c88bc720fe24','Emma','Mattsson',NULL,'emma.mattsson19@example.com',NULL,'female',55,8,1,NULL,NULL,'2025-11-22 17:26:19',NULL,NULL,'$2y$12$yEWGy6YjoiddM4elSpbHDus1Q2cHnFLllOsFXAbil6F/kjs5KPSLO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:19','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(48,'5c144a04-cb7e-416d-9545-538f5f731deb','Wilma','Fredriksson',NULL,'wilma.fredriksson20@example.com',NULL,'female',54,1,1,NULL,NULL,'2025-11-22 17:26:19',NULL,NULL,'$2y$12$YdKioAfp5KI/bvF8dpyl4OVhOQhDZ/hNFGH995YFURCze0/YmGnQq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:19','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(49,'6895400c-5555-4b36-b6ec-034daee41abe','Emma','Lund',NULL,'emma.lund21@example.com',NULL,'female',51,5,1,NULL,NULL,'2025-11-22 17:26:19',NULL,NULL,'$2y$12$HIQHSuYQYjyx.Q3Zf0RCmuNH6H9QtuUP3.ek0dzXBgZ8Tqj8uo/dK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:19','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(50,'e80759aa-4657-499c-9a73-ba6234fb1dfe','Johanna','Berg',NULL,'johanna.berg22@example.com',NULL,'female',19,8,1,NULL,NULL,'2025-11-22 17:26:19',NULL,NULL,'$2y$12$ysiiP9yWrhWLQ7wIrMFT9.K8L.9pPYpExEK2tY7gy11Bdb4qfbk2O',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:19','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(51,'2f1c5a7b-fc7c-41a2-8273-4279b9d10072','Karin','Karlsson',NULL,'karin.karlsson23@example.com',NULL,'female',40,7,1,NULL,NULL,'2025-11-22 17:26:19',NULL,NULL,'$2y$12$/95ySfaTcbT5nTQMx6ly4.i7CFWn.pmvwDt42V8ckjRXxR3XlX6QO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:19','2025-11-22 17:26:20','2025-11-22 17:26:20'),
(52,'338fb66b-cf5a-4577-8f9c-e1409fd9b842','Sara','Lindberg',NULL,'sara.lindberg24@example.com',NULL,'female',29,2,1,NULL,NULL,'2025-11-22 17:26:20',NULL,NULL,'$2y$12$hOlk/tBA0.QG0Xg7UQRR8.SQRgE06B.U7.5t6VDvuEmkNBWvVVeVq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-22 17:26:20','2025-11-22 17:26:20','2025-11-22 17:26:20');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

