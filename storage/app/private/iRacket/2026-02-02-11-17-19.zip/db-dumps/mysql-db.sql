/*M!999999\- enable the sandbox mode */ 

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `position` enum('top_sticky','bottom_sticky','top','bottom','within_page','random','popup') NOT NULL DEFAULT 'top',
  `views` bigint(20) unsigned NOT NULL DEFAULT 0,
  `clicks` bigint(20) unsigned NOT NULL DEFAULT 0,
  `locations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`locations`)),
  `link` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','inactive','scheduled') NOT NULL DEFAULT 'inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('iracket-cache-2bebca41af7f98bb7d5ab842f1499cba','i:1;',1770024495),
('iracket-cache-2bebca41af7f98bb7d5ab842f1499cba:timer','i:1770024495;',1770024495),
('iracket-cache-scraper_setting_schedule_export_day','N;',1770034639),
('iracket-cache-scraper_setting_schedule_export_enabled','N;',1770034639),
('iracket-cache-scraper_setting_schedule_export_time','N;',1770034639),
('iracket-cache-scraper_setting_schedule_live_center_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:22;s:3:\"key\";s:28:\"schedule_live_center_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic live center scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:8;s:3:\"key\";s:20:\"schedule_players_day\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:72:\"Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:6;s:3:\"key\";s:24:\"schedule_players_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:33:\"Enable automatic players scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:7;s:3:\"key\";s:26:\"schedule_players_frequency\";s:5:\"value\";s:7:\"monthly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Players scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_players_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:9;s:3:\"key\";s:21:\"schedule_players_time\";s:5:\"value\";s:5:\"03:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Time to run players scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_day','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:12;s:3:\"key\";s:21:\"schedule_rankings_day\";s:5:\"value\";s:6:\"sunday\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:26:\"Day to run rankings scrape\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:10;s:3:\"key\";s:25:\"schedule_rankings_enabled\";s:5:\"value\";s:1:\"1\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:34:\"Enable automatic rankings scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_frequency','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:11;s:3:\"key\";s:27:\"schedule_rankings_frequency\";s:5:\"value\";s:6:\"weekly\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:27:\"Rankings scraping frequency\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_rankings_time','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:13;s:3:\"key\";s:22:\"schedule_rankings_time\";s:5:\"value\";s:5:\"02:00\";s:4:\"type\";s:6:\"string\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:35:\"Time to run rankings scrape (HH:MM)\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_series_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:18;s:3:\"key\";s:23:\"schedule_series_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:32:\"Enable automatic series scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609),
('iracket-cache-scraper_setting_schedule_transitions_enabled','O:33:\"App\\Models\\Scraper\\ScraperSetting\":33:{s:13:\"\0*\0connection\";s:7:\"mariadb\";s:8:\"\0*\0table\";s:16:\"scraper_settings\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:19:\"preventsLazyLoading\";b:0;s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:28:\"\0*\0escapeWhenCastingToString\";b:0;s:13:\"\0*\0attributes\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:11:\"\0*\0original\";a:8:{s:2:\"id\";i:14;s:3:\"key\";s:28:\"schedule_transitions_enabled\";s:5:\"value\";s:1:\"0\";s:4:\"type\";s:7:\"boolean\";s:5:\"group\";s:8:\"schedule\";s:11:\"description\";s:37:\"Enable automatic transitions scraping\";s:10:\"created_at\";s:19:\"2026-01-29 16:24:42\";s:10:\"updated_at\";s:19:\"2026-01-29 16:24:42\";}s:10:\"\0*\0changes\";a:0:{}s:11:\"\0*\0previous\";a:0:{}s:8:\"\0*\0casts\";a:0:{}s:17:\"\0*\0classCastCache\";a:0:{}s:21:\"\0*\0attributeCastCache\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:19:\"\0*\0dispatchesEvents\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:27:\"\0*\0relationAutoloadCallback\";N;s:26:\"\0*\0relationAutoloadContext\";N;s:10:\"timestamps\";b:1;s:13:\"usesUniqueIds\";b:0;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:11:\"\0*\0fillable\";a:5:{i:0;s:3:\"key\";i:1;s:5:\"value\";i:2;s:4:\"type\";i:3;s:5:\"group\";i:4;s:11:\"description\";}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}',1770031609);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `club_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `total_points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `club_monthly_rankings_club_id_year_month_unique` (`club_id`,`year`,`month`),
  CONSTRAINT `club_monthly_rankings_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_monthly_rankings` WRITE;
/*!40000 ALTER TABLE `club_monthly_rankings` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `club_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `club_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `period` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `from_club_id` bigint(20) unsigned DEFAULT NULL,
  `to_club_id` bigint(20) unsigned DEFAULT NULL,
  `surname` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `born` date DEFAULT NULL,
  `from_club_name` varchar(255) DEFAULT NULL,
  `to_club_name` varchar(255) DEFAULT NULL,
  `completion_date` date NOT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `club_transitions_to_club_id_completion_date_index` (`to_club_id`,`completion_date`),
  KEY `club_transitions_from_club_id_completion_date_index` (`from_club_id`,`completion_date`),
  KEY `club_transitions_user_id_index` (`user_id`),
  CONSTRAINT `club_transitions_from_club_id_foreign` FOREIGN KEY (`from_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_to_club_id_foreign` FOREIGN KEY (`to_club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL,
  CONSTRAINT `club_transitions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `club_transitions` WRITE;
/*!40000 ALTER TABLE `club_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `club_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clubs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clubs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clubs_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=189 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clubs` WRITE;
/*!40000 ALTER TABLE `clubs` DISABLE KEYS */;
INSERT INTO `clubs` VALUES
(187,'Eslövs AI BTK','eslovs-ai-btk',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(188,'Ängby SK','angby-sk',NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-02 09:57:54','2026-02-02 09:57:54');
/*!40000 ALTER TABLE `clubs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `replied_at` timestamp NULL DEFAULT NULL,
  `replied_by` bigint(20) unsigned DEFAULT NULL,
  `reply_message` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_replied_by_foreign` (`replied_by`),
  CONSTRAINT `contacts_replied_by_foreign` FOREIGN KEY (`replied_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `source` enum('player_added','scraped') NOT NULL DEFAULT 'player_added',
  `is_unofficial` tinyint(1) NOT NULL DEFAULT 0,
  `uuid` uuid NOT NULL,
  `player1_id` bigint(20) unsigned NOT NULL,
  `player2_id` bigint(20) unsigned NOT NULL,
  `played_at` date NOT NULL,
  `player1_sets` tinyint(3) unsigned NOT NULL,
  `player2_sets` tinyint(3) unsigned NOT NULL,
  `player1_points_before` int(11) DEFAULT NULL,
  `player2_points_before` int(11) DEFAULT NULL,
  `player1_points_change` int(11) DEFAULT NULL,
  `player2_points_change` int(11) DEFAULT NULL,
  `winner_id` bigint(20) unsigned DEFAULT NULL,
  `player1_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player1_comments`)),
  `player2_comments` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`player2_comments`)),
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','disputed') NOT NULL DEFAULT 'pending',
  `is_manual` tinyint(1) NOT NULL DEFAULT 1,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `replaced_by_match_id` bigint(20) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `matches_uuid_unique` (`uuid`),
  KEY `matches_winner_id_foreign` (`winner_id`),
  KEY `matches_created_by_foreign` (`created_by`),
  KEY `matches_player1_id_played_at_index` (`player1_id`,`played_at`),
  KEY `matches_player2_id_played_at_index` (`player2_id`,`played_at`),
  KEY `matches_replaced_by_match_id_foreign` (`replaced_by_match_id`),
  KEY `match_lookup` (`player1_id`,`player2_id`,`played_at`,`deleted_at`),
  KEY `matches_is_unofficial_index` (`is_unofficial`),
  CONSTRAINT `matches_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player1_id_foreign` FOREIGN KEY (`player1_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_player2_id_foreign` FOREIGN KEY (`player2_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `matches_replaced_by_match_id_foreign` FOREIGN KEY (`replaced_by_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `matches_winner_id_foreign` FOREIGN KEY (`winner_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3375 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `matches` WRITE;
/*!40000 ALTER TABLE `matches` DISABLE KEYS */;
/*!40000 ALTER TABLE `matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_22_145432_add_two_factor_columns_to_users_table',1),
(5,'2025_11_22_165510_add_social_ids_to_users_table',1),
(6,'2025_11_22_165838_update_users_table_add_profile_fields',1),
(7,'2025_11_22_165843_create_terms_table',1),
(8,'2025_11_22_170643_add_verification_code_to_users_table',1),
(9,'2025_11_22_173409_add_fcm_token_to_users_table',1),
(10,'2025_11_22_173439_create_notifications_table',1),
(11,'2025_11_22_173505_add_phone_and_gender_to_users_table',1),
(12,'2025_11_22_174607_add_age_to_users_table',1),
(13,'2025_11_22_180425_create_clubs_table',1),
(14,'2025_11_22_180426_create_matches_table',1),
(15,'2025_11_22_180426_create_monthly_rankings_table',1),
(16,'2025_11_22_180427_add_club_id_to_users_table',1),
(17,'2025_11_22_180428_create_club_monthly_rankings_table',1),
(18,'2025_11_22_180433_create_permission_tables',1),
(19,'2025_11_22_180537_add_visible_in_players_to_users_table',1),
(20,'2025_11_22_183254_add_uuid_to_game_matches_table',1),
(21,'2025_11_22_183254_add_uuid_to_users_table',1),
(22,'2025_11_22_183256_add_points_change_to_club_monthly_rankings_table',1),
(23,'2025_11_22_183655_make_terms_translatable',1),
(24,'2025_11_22_231254_create_scraper_tables',1),
(25,'2025_11_23_073613_add_fcm_fields_to_users_table',1),
(26,'2025_11_23_074902_add_icon_to_notifications_table',1),
(27,'2025_11_23_084421_create_scraper_settings_table',1),
(28,'2025_11_23_085201_add_schedule_settings_to_scraper_settings',1),
(29,'2025_11_23_090000_create_contacts_table',1),
(30,'2025_11_23_103307_add_sbtf_player_fields_to_users_table',1),
(31,'2025_11_24_091012_create_banners_table',1),
(32,'2025_11_24_094538_create_user_monitors_table',1),
(33,'2025_11_24_102243_add_connection_fields_to_users_table',1),
(34,'2025_11_24_105000_add_points_tracking_to_matches_table',1),
(35,'2025_11_24_111359_create_club_transitions_table',1),
(36,'2025_12_23_132006_add_match_tracking_fields',1),
(37,'2025_12_23_133213_make_matches_created_by_nullable',1),
(38,'2025_12_23_160000_add_step_tracking_to_scraper_runs_table',1),
(39,'2026_01_23_071913_add_user_fullname_to_users_table',1),
(40,'2026_01_23_120000_add_popup_scraper_fields_to_scraped_tables',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES
(1,'App\\Models\\User',999);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `monthly_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `monthly_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `year` smallint(5) unsigned NOT NULL,
  `month` tinyint(3) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `points` int(11) NOT NULL,
  `points_change` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `monthly_rankings_user_id_year_month_unique` (`user_id`,`year`,`month`),
  KEY `monthly_rankings_year_month_rank_index` (`year`,`month`,`rank`),
  CONSTRAINT `monthly_rankings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=110080 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `monthly_rankings` WRITE;
/*!40000 ALTER TABLE `monthly_rankings` DISABLE KEYS */;
INSERT INTO `monthly_rankings` VALUES
(109715,1000,2010,11,3604,350,0,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109716,1000,2010,12,4471,389,39,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109717,1000,2011,1,4424,492,103,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109718,1000,2011,2,4419,542,50,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109719,1000,2011,3,4255,625,83,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109720,1000,2011,4,4314,625,0,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109721,1000,2011,5,4140,625,0,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109722,1000,2011,7,4139,625,0,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109723,1000,2011,8,4192,625,0,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109724,1000,2011,9,3954,749,124,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109725,1000,2011,10,4144,767,18,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109726,1000,2011,11,4617,824,57,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109727,1000,2011,12,2601,1224,400,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(109728,1000,2012,1,2620,1224,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109729,1000,2012,2,2703,1214,-10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109730,1000,2012,3,2161,1317,103,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109731,1000,2012,4,2125,1305,-12,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109732,1000,2012,5,2061,1319,14,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109733,1000,2012,6,2062,1319,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109734,1000,2012,7,2062,1319,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109735,1000,2012,8,1800,1378,59,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109736,1000,2012,9,1542,1445,67,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109737,1000,2012,10,1426,1481,36,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109738,1000,2012,11,1541,1455,-26,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109739,1000,2012,12,1443,1491,36,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109740,1000,2013,1,1112,1588,97,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109741,1000,2013,2,843,1679,91,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109742,1000,2013,3,778,1702,23,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109743,1000,2013,4,797,1683,-19,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109744,1000,2013,5,840,1666,-17,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109745,1000,2013,6,683,1731,65,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109746,1000,2013,7,683,1731,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109747,1000,2013,8,502,1815,84,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109748,1000,2013,9,391,1881,66,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109749,1000,2013,10,272,1985,104,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109750,1000,2013,11,365,1928,-57,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109751,1000,2013,12,292,1998,70,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109752,1000,2014,1,201,2083,85,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109753,1000,2014,2,237,2059,-24,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109754,1000,2014,3,192,2116,57,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109755,1000,2014,4,203,2110,-6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109756,1000,2014,5,188,2128,18,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109757,1000,2014,6,139,2180,52,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109758,1000,2014,7,134,2194,14,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109759,1000,2014,8,138,2194,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109760,1000,2014,9,139,2194,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109761,1000,2014,10,110,2278,84,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109762,1000,2014,11,107,2316,38,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109763,1000,2014,12,121,2290,-26,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109764,1000,2015,1,85,2377,87,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109765,1000,2015,2,95,2376,-1,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109766,1000,2015,3,101,2365,-11,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109767,1000,2015,4,113,2348,-17,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109768,1000,2015,5,82,2421,73,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109769,1000,2015,6,66,2460,39,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109770,1000,2015,7,67,2460,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109771,1000,2015,8,68,2460,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109772,1000,2015,9,44,2512,52,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109773,1000,2015,10,50,2509,-3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109774,1000,2015,11,53,2509,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109775,1000,2015,12,69,2488,-21,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109776,1000,2016,1,61,2505,17,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109777,1000,2016,2,60,2517,12,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109778,1000,2016,3,64,2510,-7,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109779,1000,2016,4,69,2507,-3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109780,1000,2016,5,58,2555,48,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109781,1000,2016,6,38,2593,38,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109782,1000,2016,7,38,2593,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109783,1000,2016,8,39,2593,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109784,1000,2016,9,37,2617,24,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109785,1000,2016,10,45,2598,-19,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109786,1000,2016,11,51,2598,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109787,1000,2016,12,55,2592,-6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109788,1000,2017,1,55,2592,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109789,1000,2017,2,60,2592,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109790,1000,2017,3,65,2592,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109791,1000,2017,4,64,2592,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109792,1000,2017,5,63,2592,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109793,1000,2017,6,51,2619,27,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109794,1000,2017,7,51,2619,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109795,1000,2017,8,52,2619,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109796,1000,2017,9,52,2619,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109797,1000,2017,10,41,2651,32,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109798,1000,2017,11,39,2664,13,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109799,1000,2017,12,41,2664,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109800,1000,2018,1,43,2667,3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109801,1000,2018,2,37,2691,24,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109802,1000,2018,3,18,2832,141,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109803,1000,2018,4,17,2846,14,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109804,1000,2018,5,14,2846,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109805,1000,2018,6,13,2857,11,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109806,1000,2018,7,13,2857,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109807,1000,2018,8,13,2857,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109808,1000,2018,9,9,2890,33,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109809,1000,2018,10,8,2923,33,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109810,1000,2018,11,8,2931,8,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109811,1000,2018,12,8,2939,8,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109812,1000,2019,1,9,2917,-22,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109813,1000,2019,2,8,2978,61,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109814,1000,2019,3,6,3109,131,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109815,1000,2019,4,6,3139,30,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109816,1000,2019,5,6,3139,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109817,1000,2019,6,6,3139,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109818,1000,2019,7,7,3139,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109819,1000,2019,8,5,3139,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109820,1000,2019,9,5,3136,-3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109821,1000,2019,10,6,3145,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109822,1000,2019,11,7,3145,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109823,1000,2019,12,7,3145,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109824,1000,2020,1,7,3163,18,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109825,1000,2020,2,7,3169,6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109826,1000,2020,3,6,3173,4,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109827,1000,2020,4,5,3176,3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109828,1000,2020,9,5,3167,-9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109829,1000,2020,10,5,3176,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109830,1000,2020,11,5,3163,-13,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109831,1000,2020,12,5,3163,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109832,1000,2021,2,6,3163,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109833,1000,2021,3,6,3163,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109834,1000,2021,4,5,3174,11,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109835,1000,2021,5,5,3174,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109836,1000,2021,6,5,3174,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109837,1000,2021,7,5,3207,33,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109838,1000,2021,8,5,3207,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109839,1000,2021,9,5,3226,19,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109840,1000,2021,10,3,3226,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109841,1000,2021,11,3,3238,12,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109842,1000,2021,12,3,3250,12,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109843,1000,2022,1,3,3265,15,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109844,1000,2022,2,2,3309,44,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109845,1000,2022,3,1,3331,22,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109846,1000,2022,4,1,3331,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109847,1000,2022,5,1,3358,27,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109848,1000,2022,6,1,3391,33,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109849,1000,2022,7,1,3391,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109850,1000,2022,8,1,3391,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109851,1000,2022,9,1,3407,16,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109852,1000,2022,10,1,3407,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109853,1000,2022,11,1,3407,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109854,1000,2022,12,1,3407,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109855,1000,2023,1,1,3407,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109856,1000,2023,2,1,3413,6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109857,1000,2023,3,1,3422,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109858,1000,2023,4,1,3451,29,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109859,1000,2023,5,1,3485,34,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109860,1000,2023,6,1,3485,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109861,1000,2023,7,1,3485,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109862,1000,2023,8,1,3485,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109863,1000,2023,9,1,3485,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109864,1000,2023,10,1,3485,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109865,1000,2023,11,2,3488,3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109866,1000,2023,12,2,3500,12,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109867,1000,2024,1,2,3503,3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109868,1000,2024,2,1,3512,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109869,1000,2024,3,1,3512,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109870,1000,2024,4,2,3532,20,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109871,1000,2024,5,2,3541,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109872,1000,2024,6,2,3555,14,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109873,1000,2024,7,1,2486,-1069,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109874,1000,2024,8,2,2486,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109875,1000,2024,9,1,2486,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109876,1000,2024,10,1,2486,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109877,1000,2024,11,1,2492,6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109878,1000,2024,12,1,2492,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109879,1000,2025,1,1,2521,29,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109880,1000,2025,2,1,2531,10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109881,1000,2025,3,1,2571,40,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109882,1000,2025,4,1,2571,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109883,1000,2025,5,1,2609,38,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109884,1000,2025,6,1,2609,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109885,1000,2025,7,1,2500,-109,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109886,1000,2025,8,1,2500,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109887,1000,2025,9,1,2500,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109888,1000,2025,10,1,2531,31,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109889,1000,2025,11,1,2531,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109890,1000,2025,12,1,2536,5,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109891,1000,2026,1,1,2545,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109892,1001,2009,8,175,1270,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109893,1001,2009,10,4695,1218,-52,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109894,1001,2009,11,2681,1308,90,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109895,1001,2009,12,2691,1308,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109896,1001,2010,1,2693,1308,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109897,1001,2010,2,2710,1308,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109898,1001,2010,3,2716,1308,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109899,1001,2010,4,2718,1308,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109900,1001,2010,5,2719,1318,10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109901,1001,2010,8,1511,1318,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109902,1001,2010,10,120,1334,16,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109903,1001,2010,11,1879,1331,-3,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109904,1001,2010,12,1857,1373,42,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109905,1001,2011,1,1846,1373,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109906,1001,2011,2,1844,1372,-1,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109907,1001,2011,3,1733,1403,31,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109908,1001,2011,4,1634,1432,29,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109909,1001,2011,5,1345,1484,52,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109910,1001,2011,7,1345,1484,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109911,1001,2011,8,1365,1484,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109912,1001,2011,9,905,1661,177,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109913,1001,2011,10,856,1681,20,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109914,1001,2011,11,772,1710,29,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109915,1001,2011,12,771,1710,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109916,1001,2012,1,729,1725,15,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109917,1001,2012,2,1039,1618,-107,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109918,1001,2012,3,748,1708,90,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109919,1001,2012,4,700,1714,6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109920,1001,2012,5,918,1632,-82,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109921,1001,2012,6,922,1632,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109922,1001,2012,7,922,1632,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109923,1001,2012,8,918,1632,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109924,1001,2012,9,891,1642,10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109925,1001,2012,10,640,1746,104,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109926,1001,2012,11,620,1764,18,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109927,1001,2012,12,514,1811,47,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109928,1001,2013,1,441,1849,38,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109929,1001,2013,2,465,1840,-9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109930,1001,2013,3,582,1781,-59,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109931,1001,2013,4,560,1785,4,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109932,1001,2013,5,577,1773,-12,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109933,1001,2013,6,605,1763,-10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109934,1001,2013,7,605,1763,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109935,1001,2013,8,607,1763,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109936,1001,2013,9,562,1787,24,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109937,1001,2013,10,526,1821,34,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109938,1001,2013,11,466,1857,36,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109939,1001,2013,12,364,1938,81,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109940,1001,2014,1,11,1948,10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109941,1001,2014,2,6,2040,92,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109942,1001,2014,3,275,2035,-5,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109943,1001,2014,4,311,2007,-28,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109944,1001,2014,5,350,1974,-33,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109945,1001,2014,6,10,1974,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109946,1001,2014,7,10,1974,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109947,1001,2014,8,338,1990,16,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109948,1001,2014,9,313,2013,23,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109949,1001,2014,10,9,2019,6,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109950,1001,2014,11,281,2065,46,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109951,1001,2014,12,296,2064,-1,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109952,1001,2015,1,10,2098,34,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109953,1001,2015,2,264,2119,21,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109954,1001,2015,3,234,2161,42,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109955,1001,2015,4,248,2156,-5,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109956,1001,2015,5,247,2146,-10,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109957,1001,2015,6,230,2162,16,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109958,1001,2015,7,227,2166,4,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109959,1001,2015,8,212,2183,17,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109960,1001,2015,9,219,2183,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109961,1001,2015,10,231,2183,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109962,1001,2015,11,204,2220,37,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109963,1001,2015,12,5,2240,20,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109964,1001,2016,1,6,2240,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109965,1001,2016,2,220,2240,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109966,1001,2016,3,210,2249,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109967,1001,2016,4,6,2248,-1,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109968,1001,2016,5,216,2248,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109969,1001,2016,6,238,2222,-26,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109970,1001,2016,7,238,2222,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109971,1001,2016,8,8,2222,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109972,1001,2016,9,8,2238,16,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109973,1001,2016,10,242,2238,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109974,1001,2016,11,260,2238,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109975,1001,2016,12,263,2238,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109976,1001,2017,1,262,2238,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109977,1001,2017,2,264,2238,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109978,1001,2017,3,252,2257,19,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109979,1001,2017,4,253,2257,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109980,1001,2017,5,242,2257,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109981,1001,2017,6,13,2257,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109982,1001,2017,7,11,2257,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109983,1001,2017,8,9,2283,26,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109984,1001,2017,9,9,2283,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109985,1001,2017,10,9,2283,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109986,1001,2017,11,9,2301,18,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109987,1001,2017,12,8,2301,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109988,1001,2018,1,7,2301,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109989,1001,2018,2,8,2301,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109990,1001,2018,3,5,2349,48,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109991,1001,2018,4,7,2349,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109992,1001,2018,5,7,2349,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109993,1001,2018,6,7,2349,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109994,1001,2018,7,6,2349,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109995,1001,2018,8,6,2396,47,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109996,1001,2018,9,6,2396,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109997,1001,2018,10,6,2396,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109998,1001,2018,11,6,2396,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(109999,1001,2018,12,6,2396,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110000,1001,2019,1,5,2396,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110001,1001,2019,2,8,2396,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110002,1001,2019,3,7,2436,40,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110003,1001,2019,4,7,2436,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110004,1001,2019,5,6,2436,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110005,1001,2019,6,6,2436,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110006,1001,2019,7,4,2436,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110007,1001,2019,8,4,2454,18,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110008,1001,2019,9,2,2475,21,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110009,1001,2019,10,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110010,1001,2019,11,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110011,1001,2019,12,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110012,1001,2020,1,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110013,1001,2020,2,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110014,1001,2020,3,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110015,1001,2020,4,2,2475,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110016,1001,2020,9,2,2473,-2,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110017,1001,2020,10,2,2491,18,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110018,1001,2020,11,2,2491,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110019,1001,2020,12,2,2491,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110020,1001,2021,2,2,2491,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110021,1001,2021,3,2,2491,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110022,1001,2021,4,2,2500,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110023,1001,2021,5,2,2500,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110024,1001,2021,6,2,2500,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110025,1001,2021,7,2,2538,38,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110026,1001,2021,8,2,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110027,1001,2021,9,2,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110028,1001,2021,10,2,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110029,1001,2021,11,2,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110030,1001,2021,12,2,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110031,1001,2022,1,2,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110032,1001,2022,2,1,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110033,1001,2022,3,1,2538,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110034,1001,2022,4,1,2547,9,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110035,1001,2022,5,1,2547,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110036,1001,2022,6,2,2604,57,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110037,1001,2022,7,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110038,1001,2022,8,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110039,1001,2022,9,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110040,1001,2022,10,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110041,1001,2022,11,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110042,1001,2022,12,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110043,1001,2023,1,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110044,1001,2023,2,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110045,1001,2023,3,2,2604,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110046,1001,2023,4,2,2635,31,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110047,1001,2023,5,2,2635,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110048,1001,2023,6,2,2635,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110049,1001,2023,7,2,2635,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110050,1001,2023,8,2,2635,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110051,1001,2023,9,2,2635,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110052,1001,2023,10,2,2635,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110053,1001,2023,11,2,2630,-5,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110054,1001,2023,12,2,2630,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110055,1001,2024,1,2,2630,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110056,1001,2024,2,1,2630,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110057,1001,2024,3,1,2630,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110058,1001,2024,4,1,2653,23,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110059,1001,2024,5,1,2653,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110060,1001,2024,6,1,2653,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110061,1001,2024,7,2,2180,-473,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110062,1001,2024,8,2,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110063,1001,2024,9,1,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110064,1001,2024,10,1,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110065,1001,2024,11,1,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110066,1001,2024,12,1,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110067,1001,2025,1,1,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110068,1001,2025,2,1,2180,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110069,1001,2025,3,1,2233,53,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110070,1001,2025,4,1,2233,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110071,1001,2025,5,1,2233,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110072,1001,2025,6,1,2233,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110073,1001,2025,7,1,2214,-19,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110074,1001,2025,8,1,2214,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110075,1001,2025,9,1,2214,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110076,1001,2025,10,1,2214,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110077,1001,2025,11,1,2240,26,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110078,1001,2025,12,1,2240,0,'2026-02-02 09:57:55','2026-02-02 09:57:55'),
(110079,1001,2026,1,1,2240,0,'2026-02-02 09:57:55','2026-02-02 09:57:55');
/*!40000 ALTER TABLE `monthly_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `type` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`data`)),
  `icon` varchar(255) DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_user_id_read_at_index` (`user_id`,`read_at`),
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'Admin','web','2026-02-02 08:34:07','2026-02-02 08:34:07'),
(2,'Manager','web','2026-02-02 08:34:07','2026-02-02 08:34:07'),
(3,'User','web','2026-02-02 08:34:07','2026-02-02 08:34:07');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_matches` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `player_name` varchar(255) DEFAULT NULL,
  `opponent_name` varchar(255) DEFAULT NULL,
  `result` varchar(1) DEFAULT NULL,
  `opponent_points` int(11) DEFAULT NULL,
  `match_points` int(11) DEFAULT NULL,
  `match_date` date DEFAULT NULL,
  `scraped_month` varchar(7) DEFAULT NULL,
  `source` varchar(255) NOT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) DEFAULT NULL,
  `series_name` varchar(255) DEFAULT NULL,
  `team1_name` varchar(255) DEFAULT NULL,
  `team2_name` varchar(255) DEFAULT NULL,
  `player1_name` varchar(255) NOT NULL,
  `player2_name` varchar(255) NOT NULL,
  `score` varchar(255) DEFAULT NULL,
  `sets` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`sets`)),
  `played_at` varchar(255) DEFAULT NULL,
  `winner` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_match_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_matches_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_matches_synced_match_id_foreign` (`synced_match_id`),
  KEY `scraped_matches_player1_name_player2_name_index` (`player1_name`,`player2_name`),
  KEY `scraped_matches_period_division_index` (`period`,`division`),
  KEY `scraped_matches_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_matches_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_matches_synced_match_id_foreign` FOREIGN KEY (`synced_match_id`) REFERENCES `matches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_matches` WRITE;
/*!40000 ALTER TABLE `scraped_matches` DISABLE KEYS */;
INSERT INTO `scraped_matches` VALUES
(1,27,'14450','Möregårdh, Truls','Sebastian Loso','W',2257,3,'2025-11-11','2025-12','rankings_popup_python','2025-11','','','','','Möregårdh, Truls','Sebastian Loso','',NULL,'2025-11-11','Möregårdh, Truls',1,NULL,'2026-02-02 09:57:20','2026-02-02 09:57:55'),
(2,27,'14450','Möregårdh, Truls','Masaki Kayama','W',2116,2,'2025-11-11','2025-12','rankings_popup_python','2025-11','','','','','Möregårdh, Truls','Masaki Kayama','',NULL,'2025-11-11','Möregårdh, Truls',1,NULL,'2026-02-02 09:57:20','2026-02-02 09:57:55');
/*!40000 ALTER TABLE `scraped_matches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_players` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `club_name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `date_of_birth` varchar(255) DEFAULT NULL,
  `license_type` varchar(255) DEFAULT NULL,
  `player_class` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_players_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_players_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_players_surname_first_name_index` (`surname`,`first_name`),
  KEY `scraped_players_club_name_index` (`club_name`),
  KEY `scraped_players_is_synced_index` (`is_synced`),
  CONSTRAINT `scraped_players_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_players_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_players` WRITE;
/*!40000 ALTER TABLE `scraped_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_players` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_rankings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_rankings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `profixio_player_id` varchar(255) DEFAULT NULL,
  `ranking_date` date DEFAULT NULL,
  `period` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `position_change` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `club` varchar(255) DEFAULT NULL,
  `points` int(11) NOT NULL DEFAULT 0,
  `points_diff` varchar(255) DEFAULT NULL,
  `rmld_id` varchar(255) DEFAULT NULL,
  `points_change` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `synced_ranking_id` bigint(20) unsigned DEFAULT NULL,
  `synced_user_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_rankings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_rankings_synced_user_id_foreign` (`synced_user_id`),
  KEY `scraped_rankings_period_gender_division_index` (`period`,`gender`,`division`),
  KEY `scraped_rankings_name_index` (`name`),
  KEY `scraped_rankings_is_synced_index` (`is_synced`),
  KEY `scraped_rankings_synced_ranking_id_foreign` (`synced_ranking_id`),
  CONSTRAINT `scraped_rankings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `scraped_rankings_synced_ranking_id_foreign` FOREIGN KEY (`synced_ranking_id`) REFERENCES `monthly_rankings` (`id`) ON DELETE SET NULL,
  CONSTRAINT `scraped_rankings_synced_user_id_foreign` FOREIGN KEY (`synced_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=381 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_rankings` WRITE;
/*!40000 ALTER TABLE `scraped_rankings` DISABLE KEYS */;
INSERT INTO `scraped_rankings` VALUES
(1,27,'14450','2026-01-05','2026-01','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2545,'+9','rmld:14450:391:0','+9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(2,27,'14450','2025-12-01','2025-12','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2536,'+5','rmld:14450:390:0','+5',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(3,27,'14450','2025-11-03','2025-11','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2531,'0','rmld:14450:389:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(4,27,'14450','2025-10-06','2025-10','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2531,'+31','rmld:14450:387:0','+31',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(5,27,'14450','2025-09-01','2025-09','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2500,'0','rmld:14450:386:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(6,27,'14450','2025-08-04','2025-08','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2500,'0','rmld:14450:385:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(7,27,'14450','2025-07-08','2025-07','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2500,'-109','rmld:14450:384:0','-109',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(8,27,'14450','2025-07-07','2025-07','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2609,'0','rmld:14450:383:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(9,27,'14450','2025-06-02','2025-06','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2609,'0','rmld:14450:382:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(10,27,'14450','2025-05-05','2025-05','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2609,'+38','rmld:14450:379:0','+38',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(11,27,'14450','2025-04-07','2025-04','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2571,'0','rmld:14450:378:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(12,27,'14450','2025-03-03','2025-03','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2571,'+40','rmld:14450:377:0','+40',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(13,27,'14450','2025-02-03','2025-02','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2531,'+10','rmld:14450:376:0','+10',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(14,27,'14450','2025-01-07','2025-01','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2521,'+29','rmld:14450:374:0','+29',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(15,27,'14450','2024-12-02','2024-12','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2492,'0','rmld:14450:373:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(16,27,'14450','2024-11-04','2024-11','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2492,'+6','rmld:14450:372:0','+6',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(17,27,'14450','2024-10-07','2024-10','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2486,'0','rmld:14450:368:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(18,27,'14450','2024-09-02','2024-09','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2486,'0','rmld:14450:365:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(19,27,'14450','2024-08-05','2024-08','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',2486,'0','rmld:14450:364:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(20,27,'14450','2024-07-02','2024-07','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',2486,'-1069','rmld:14450:363:0','-1069',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(21,27,'14450','2024-07-01','2024-07','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3555,'0','rmld:14450:361:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(22,27,'14450','2024-06-03','2024-06','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3555,'+14','rmld:14450:360:0','+14',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(23,27,'14450','2024-05-06','2024-05','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3541,'+9','rmld:14450:356:0','+9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(24,27,'14450','2024-04-01','2024-04','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3532,'+20','rmld:14450:355:0','+20',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(25,27,'14450','2024-03-04','2024-03','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3512,'0','rmld:14450:353:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(26,27,'14450','2024-02-05','2024-02','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3512,'+9','rmld:14450:351:0','+9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(27,27,'14450','2024-01-02','2024-01','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3503,'+3','rmld:14450:350:0','+3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(28,27,'14450','2023-12-04','2023-12','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3500,'+12','rmld:14450:348:0','+12',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(29,27,'14450','2023-11-06','2023-11','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3488,'+3','rmld:14450:347:0','+3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(30,27,'14450','2023-10-02','2023-10','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'0','rmld:14450:345:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(31,27,'14450','2023-10-02','2023-10','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'0','rmld:14450:346:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(32,27,'14450','2023-09-04','2023-09','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'0','rmld:14450:344:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(33,27,'14450','2023-08-07','2023-08','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'0','rmld:14450:343:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(34,27,'14450','2023-07-03','2023-07','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'0','rmld:14450:341:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(35,27,'14450','2023-06-06','2023-06','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'0','rmld:14450:340:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(36,27,'14450','2023-05-05','2023-05','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3485,'+34','rmld:14450:336:0','+34',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(37,27,'14450','2023-04-03','2023-04','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3451,'+29','rmld:14450:332:0','+29',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(38,27,'14450','2023-03-06','2023-03','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3422,'+9','rmld:14450:331:0','+9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(39,27,'14450','2023-02-06','2023-02','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3413,'+6','rmld:14450:330:0','+6',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(40,27,'14450','2023-01-03','2023-01','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3407,'0','rmld:14450:329:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(41,27,'14450','2023-01-02','2023-01','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3407,'0','rmld:14450:328:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(42,27,'14450','2022-12-05','2022-12','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3407,'0','rmld:14450:327:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(43,27,'14450','2022-11-07','2022-11','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3407,'0','rmld:14450:326:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(44,27,'14450','2022-10-03','2022-10','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3407,'0','rmld:14450:325:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(45,27,'14450','2022-09-05','2022-09','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3407,'+16','rmld:14450:324:0','+16',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(46,27,'14450','2022-08-01','2022-08','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3391,'0','rmld:14450:323:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(47,27,'14450','2022-07-04','2022-07','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3391,'0','rmld:14450:322:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(48,27,'14450','2022-06-07','2022-06','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3391,'+33','rmld:14450:321:0','+33',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(49,27,'14450','2022-05-02','2022-05','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3358,'+27','rmld:14450:319:0','+27',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(50,27,'14450','2022-04-04','2022-04','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3331,'0','rmld:14450:318:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(51,27,'14450','2022-03-07','2022-03','','male',1,'','Möregårdh, Truls','2002','Eslövs AI BTK',3331,'+22','rmld:14450:317:0','+22',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(52,27,'14450','2022-02-07','2022-02','','male',2,'','Möregårdh, Truls','2002','Eslövs AI BTK',3309,'+44','rmld:14450:316:0','+44',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(53,27,'14450','2022-01-03','2022-01','','male',3,'','Möregårdh, Truls','2002','Eslövs AI BTK',3265,'+15','rmld:14450:315:0','+15',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(54,27,'14450','2021-12-06','2021-12','','male',3,'','Möregårdh, Truls','2002','Eslövs AI BTK',3250,'+12','rmld:14450:313:0','+12',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(55,27,'14450','2021-11-01','2021-11','','male',3,'','Möregårdh, Truls','2002','Eslövs AI BTK',3238,'+12','rmld:14450:312:0','+12',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(56,27,'14450','2021-10-04','2021-10','','male',3,'','Möregårdh, Truls','2002','Eslövs AI BTK',3226,'0','rmld:14450:311:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(57,27,'14450','2021-09-06','2021-09','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3226,'+19','rmld:14450:305:0','+19',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(58,27,'14450','2021-08-21','2021-08','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3207,'0','rmld:14450:304:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(59,27,'14450','2021-08-02','2021-08','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3207,'0','rmld:14450:303:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(60,27,'14450','2021-07-05','2021-07','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3207,'+33','rmld:14450:302:0','+33',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(61,27,'14450','2021-06-07','2021-06','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3174,'0','rmld:14450:301:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(62,27,'14450','2021-05-03','2021-05','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3174,'0','rmld:14450:300:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(63,27,'14450','2021-04-06','2021-04','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3174,'+11','rmld:14450:299:0','+11',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(64,27,'14450','2021-03-01','2021-03','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3163,'0','rmld:14450:297:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(65,27,'14450','2021-02-03','2021-02','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3163,'0','rmld:14450:296:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(66,27,'14450','2020-12-07','2020-12','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3163,'0','rmld:14450:293:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(67,27,'14450','2020-11-02','2020-11','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3163,'-13','rmld:14450:292:0','-13',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(68,27,'14450','2020-10-05','2020-10','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3176,'+9','rmld:14450:289:0','+9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(69,27,'14450','2020-09-07','2020-09','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3167,'-9','rmld:14450:288:0','-9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(70,27,'14450','2020-04-06','2020-04','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3176,'+3','rmld:14450:287:0','+3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(71,27,'14450','2020-03-02','2020-03','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3173,'+4','rmld:14450:286:0','+4',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(72,27,'14450','2020-02-03','2020-02','','male',7,'','Möregårdh, Truls','2002','Eslövs AI BTK',3169,'+6','rmld:14450:285:0','+6',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(73,27,'14450','2020-01-06','2020-01','','male',7,'','Möregårdh, Truls','2002','Eslövs AI BTK',3163,'+18','rmld:14450:283:0','+18',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(74,27,'14450','2019-12-02','2019-12','','male',7,'','Möregårdh, Truls','2002','Eslövs AI BTK',3145,'0','rmld:14450:282:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(75,27,'14450','2019-11-04','2019-11','','male',7,'','Möregårdh, Truls','2002','Eslövs AI BTK',3145,'0','rmld:14450:281:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(76,27,'14450','2019-10-07','2019-10','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3145,'+9','rmld:14450:280:0','+9',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(77,27,'14450','2019-09-02','2019-09','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3136,'-3','rmld:14450:279:0','-3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(78,27,'14450','2019-08-05','2019-08','','male',5,'','Möregårdh, Truls','2002','Eslövs AI BTK',3139,'0','rmld:14450:278:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(79,27,'14450','2019-07-01','2019-07','','male',7,'','Möregårdh, Truls','2002','Eslövs AI BTK',3139,'0','rmld:14450:276:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(80,27,'14450','2019-06-03','2019-06','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3139,'0','rmld:14450:274:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(81,27,'14450','2019-05-06','2019-05','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3139,'0','rmld:14450:273:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(82,27,'14450','2019-04-01','2019-04','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3139,'+30','rmld:14450:272:0','+30',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(83,27,'14450','2019-03-04','2019-03','','male',6,'','Möregårdh, Truls','2002','Eslövs AI BTK',3109,'+131','rmld:14450:271:0','+131',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(84,27,'14450','2019-02-04','2019-02','','male',8,'','Möregårdh, Truls','2002','Eslövs AI BTK',2978,'+61','rmld:14450:270:0','+61',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(85,27,'14450','2019-01-07','2019-01','','male',9,'','Möregårdh, Truls','2002','Eslövs AI BTK',2917,'-22','rmld:14450:269:0','-22',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(86,27,'14450','2018-12-03','2018-12','','male',8,'','Möregårdh, Truls','2002','Eslövs AI BTK',2939,'+8','rmld:14450:268:0','+8',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(87,27,'14450','2018-11-05','2018-11','','male',8,'','Möregårdh, Truls','2002','Eslövs AI BTK',2931,'+8','rmld:14450:267:0','+8',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(88,27,'14450','2018-10-01','2018-10','','male',8,'','Möregårdh, Truls','2002','Eslövs AI BTK',2923,'+33','rmld:14450:266:0','+33',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(89,27,'14450','2018-09-03','2018-09','','male',9,'','Möregårdh, Truls','2002','Eslövs AI BTK',2890,'+33','rmld:14450:264:0','+33',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(90,27,'14450','2018-08-06','2018-08','','male',13,'','Möregårdh, Truls','2002','Eslövs AI BTK',2857,'0','rmld:14450:263:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(91,27,'14450','2018-07-02','2018-07','','male',13,'','Möregårdh, Truls','2002','Eslövs AI BTK',2857,'0','rmld:14450:261:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(92,27,'14450','2018-06-04','2018-06','','male',13,'','Möregårdh, Truls','2002','Eslövs AI BTK',2857,'+11','rmld:14450:260:0','+11',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(93,27,'14450','2018-05-07','2018-05','','male',14,'','Möregårdh, Truls','2002','Eslövs AI BTK',2846,'0','rmld:14450:259:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(94,27,'14450','2018-04-02','2018-04','','male',17,'','Möregårdh, Truls','2002','Eslövs AI BTK',2846,'+14','rmld:14450:258:0','+14',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(95,27,'14450','2018-03-05','2018-03','','male',18,'','Möregårdh, Truls','2002','Eslövs AI BTK',2832,'+141','rmld:14450:256:0','+141',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(96,27,'14450','2018-02-05','2018-02','','male',37,'','Möregårdh, Truls','2002','Eslövs AI BTK',2691,'+24','rmld:14450:255:0','+24',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(97,27,'14450','2018-01-02','2018-01','','male',43,'','Möregårdh, Truls','2002','Eslövs AI BTK',2667,'+3','rmld:14450:251:0','+3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(98,27,'14450','2017-12-04','2017-12','','male',41,'','Möregårdh, Truls','2002','Eslövs AI BTK',2664,'0','rmld:14450:247:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(99,27,'14450','2017-11-06','2017-11','','male',39,'','Möregårdh, Truls','2002','Eslövs AI BTK',2664,'+13','rmld:14450:246:0','+13',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(100,27,'14450','2017-10-02','2017-10','','male',41,'','Möregårdh, Truls','2002','Eslövs AI BTK',2651,'+32','rmld:14450:245:0','+32',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(101,27,'14450','2017-09-04','2017-09','','male',52,'','Möregårdh, Truls','2002','Eslövs AI BTK',2619,'0','rmld:14450:242:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(102,27,'14450','2017-08-07','2017-08','','male',52,'','Möregårdh, Truls','2002','Eslövs AI BTK',2619,'0','rmld:14450:241:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(103,27,'14450','2017-07-03','2017-07','','male',51,'','Möregårdh, Truls','2002','Eslövs AI BTK',2619,'0','rmld:14450:240:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(104,27,'14450','2017-06-05','2017-06','','male',51,'','Möregårdh, Truls','2002','Eslövs AI BTK',2619,'+27','rmld:14450:239:0','+27',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(105,27,'14450','2017-05-01','2017-05','','male',63,'','Möregårdh, Truls','2002','Eslövs AI BTK',2592,'0','rmld:14450:238:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(106,27,'14450','2017-04-03','2017-04','','male',64,'','Möregårdh, Truls','2002','Eslövs AI BTK',2592,'0','rmld:14450:237:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(107,27,'14450','2017-03-06','2017-03','','male',65,'','Möregårdh, Truls','2002','Eslövs AI BTK',2592,'0','rmld:14450:236:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(108,27,'14450','2017-02-06','2017-02','','male',60,'','Möregårdh, Truls','2002','Eslövs AI BTK',2592,'0','rmld:14450:235:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(109,27,'14450','2017-01-02','2017-01','','male',55,'','Möregårdh, Truls','2002','Eslövs AI BTK',2592,'0','rmld:14450:234:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(110,27,'14450','2016-12-05','2016-12','','male',55,'','Möregårdh, Truls','2002','Eslövs AI BTK',2592,'-6','rmld:14450:233:0','-6',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(111,27,'14450','2016-11-07','2016-11','','male',51,'','Möregårdh, Truls','2002','Eslövs AI BTK',2598,'0','rmld:14450:232:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(112,27,'14450','2016-10-03','2016-10','','male',45,'','Möregårdh, Truls','2002','Eslövs AI BTK',2598,'-19','rmld:14450:230:0','-19',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(113,27,'14450','2016-09-05','2016-09','','male',37,'','Möregårdh, Truls','2002','Eslövs AI BTK',2617,'+24','rmld:14450:229:0','+24',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(114,27,'14450','2016-08-01','2016-08','','male',39,'','Möregårdh, Truls','2002','Eslövs AI BTK',2593,'0','rmld:14450:228:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(115,27,'14450','2016-07-04','2016-07','','male',38,'','Möregårdh, Truls','2002','Eslövs AI BTK',2593,'0','rmld:14450:227:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(116,27,'14450','2016-06-06','2016-06','','male',38,'','Möregårdh, Truls','2002','Eslövs AI BTK',2593,'+38','rmld:14450:226:0','+38',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(117,27,'14450','2016-05-02','2016-05','','male',58,'','Möregårdh, Truls','2002','Eslövs AI BTK',2555,'+48','rmld:14450:225:0','+48',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(118,27,'14450','2016-04-04','2016-04','','male',69,'','Möregårdh, Truls','2002','Eslövs AI BTK',2507,'-3','rmld:14450:224:0','-3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(119,27,'14450','2016-03-07','2016-03','','male',64,'','Möregårdh, Truls','2002','Eslövs AI BTK',2510,'-7','rmld:14450:223:0','-7',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(120,27,'14450','2016-02-01','2016-02','','male',60,'','Möregårdh, Truls','2002','Eslövs AI BTK',2517,'+12','rmld:14450:222:0','+12',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(121,27,'14450','2016-01-04','2016-01','','male',61,'','Möregårdh, Truls','2002','Eslövs AI BTK',2505,'+17','rmld:14450:221:0','+17',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(122,27,'14450','2015-12-07','2015-12','','male',69,'','Möregårdh, Truls','2002','Eslövs AI BTK',2488,'-21','rmld:14450:220:0','-21',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(123,27,'14450','2015-11-02','2015-11','','male',53,'','Möregårdh, Truls','2002','Eslövs AI BTK',2509,'0','rmld:14450:219:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(124,27,'14450','2015-10-05','2015-10','','male',50,'','Möregårdh, Truls','2002','Eslövs AI BTK',2509,'-3','rmld:14450:217:0','-3',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(125,27,'14450','2015-09-07','2015-09','','male',44,'','Möregårdh, Truls','2002','Eslövs AI BTK',2512,'+52','rmld:14450:215:0','+52',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(126,27,'14450','2015-08-03','2015-08','','male',68,'','Möregårdh, Truls','2002','Eslövs AI BTK',2460,'0','rmld:14450:214:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(127,27,'14450','2015-07-06','2015-07','','male',67,'','Möregårdh, Truls','2002','Eslövs AI BTK',2460,'0','rmld:14450:213:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(128,27,'14450','2015-06-01','2015-06','','male',66,'','Möregårdh, Truls','2002','Eslövs AI BTK',2460,'+39','rmld:14450:212:0','+39',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(129,27,'14450','2015-05-04','2015-05','','male',82,'','Möregårdh, Truls','2002','Eslövs AI BTK',2421,'+73','rmld:14450:211:0','+73',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(130,27,'14450','2015-04-06','2015-04','','male',113,'','Möregårdh, Truls','2002','Eslövs AI BTK',2348,'-17','rmld:14450:209:0','-17',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(131,27,'14450','2015-03-02','2015-03','','male',101,'','Möregårdh, Truls','2002','Eslövs AI BTK',2365,'-11','rmld:14450:208:0','-11',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(132,27,'14450','2015-02-02','2015-02','','male',95,'','Möregårdh, Truls','2002','Eslövs AI BTK',2376,'-1','rmld:14450:207:0','-1',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(133,27,'14450','2015-01-06','2015-01','','male',85,'','Möregårdh, Truls','2002','Eslövs AI BTK',2377,'+87','rmld:14450:206:0','+87',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(134,27,'14450','2014-12-01','2014-12','','male',121,'','Möregårdh, Truls','2002','Eslövs AI BTK',2290,'-26','rmld:14450:205:0','-26',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(135,27,'14450','2014-11-03','2014-11','','male',107,'','Möregårdh, Truls','2002','Eslövs AI BTK',2316,'+38','rmld:14450:204:0','+38',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(136,27,'14450','2014-10-06','2014-10','','male',110,'','Möregårdh, Truls','2002','Eslövs AI BTK',2278,'+84','rmld:14450:203:0','+84',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(137,27,'14450','2014-09-01','2014-09','','male',139,'','Möregårdh, Truls','2002','Eslövs AI BTK',2194,'0','rmld:14450:202:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(138,27,'14450','2014-08-04','2014-08','','male',138,'','Möregårdh, Truls','2002','Eslövs AI BTK',2194,'0','rmld:14450:201:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(139,27,'14450','2014-07-07','2014-07','','male',134,'','Möregårdh, Truls','2002','Eslövs AI BTK',2194,'+14','rmld:14450:200:0','+14',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(140,27,'14450','2014-06-02','2014-06','','male',139,'','Möregårdh, Truls','2002','Eslövs AI BTK',2180,'+52','rmld:14450:199:0','+52',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(141,27,'14450','2014-05-05','2014-05','','male',188,'','Möregårdh, Truls','2002','Eslövs AI BTK',2128,'+18','rmld:14450:197:0','+18',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(142,27,'14450','2014-04-07','2014-04','','male',203,'','Möregårdh, Truls','2002','Eslövs AI BTK',2110,'-6','rmld:14450:196:0','-6',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(143,27,'14450','2014-03-03','2014-03','','male',192,'','Möregårdh, Truls','2002','Eslövs AI BTK',2116,'+57','rmld:14450:195:0','+57',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(144,27,'14450','2014-02-03','2014-02','','male',237,'','Möregårdh, Truls','2002','Eslövs AI BTK',2059,'-24','rmld:14450:194:0','-24',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(145,27,'14450','2014-01-06','2014-01','','male',201,'','Möregårdh, Truls','2002','Eslövs AI BTK',2083,'+85','rmld:14450:192:0','+85',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(146,27,'14450','2013-12-02','2013-12','','male',292,'','Möregårdh, Truls','2002','Eslövs AI BTK',1998,'+70','rmld:14450:191:0','+70',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(147,27,'14450','2013-11-04','2013-11','','male',365,'','Möregårdh, Truls','2002','Eslövs AI BTK',1928,'-57','rmld:14450:190:0','-57',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(148,27,'14450','2013-10-07','2013-10','','male',272,'','Möregårdh, Truls','2002','Eslövs AI BTK',1985,'+104','rmld:14450:188:0','+104',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(149,27,'14450','2013-09-02','2013-09','','male',391,'','Möregårdh, Truls','2002','Eslövs AI BTK',1881,'+66','rmld:14450:187:0','+66',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(150,27,'14450','2013-08-05','2013-08','','male',502,'','Möregårdh, Truls','2002','Eslövs AI BTK',1815,'+84','rmld:14450:186:0','+84',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(151,27,'14450','2013-07-01','2013-07','','male',683,'','Möregårdh, Truls','2002','Eslövs AI BTK',1731,'0','rmld:14450:185:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(152,27,'14450','2013-06-03','2013-06','','male',683,'','Möregårdh, Truls','2002','Eslövs AI BTK',1731,'+65','rmld:14450:184:0','+65',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(153,27,'14450','2013-05-06','2013-05','','male',840,'','Möregårdh, Truls','2002','Eslövs AI BTK',1666,'-17','rmld:14450:183:0','-17',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(154,27,'14450','2013-04-01','2013-04','','male',797,'','Möregårdh, Truls','2002','Eslövs AI BTK',1683,'-19','rmld:14450:182:0','-19',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(155,27,'14450','2013-03-04','2013-03','','male',778,'','Möregårdh, Truls','2002','Eslövs AI BTK',1702,'+23','rmld:14450:181:0','+23',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(156,27,'14450','2013-02-04','2013-02','','male',843,'','Möregårdh, Truls','2002','Eslövs AI BTK',1679,'+91','rmld:14450:180:0','+91',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(157,27,'14450','2013-01-07','2013-01','','male',1112,'','Möregårdh, Truls','2002','Eslövs AI BTK',1588,'+97','rmld:14450:179:0','+97',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(158,27,'14450','2012-12-03','2012-12','','male',1443,'','Möregårdh, Truls','2002','Eslövs AI BTK',1491,'+36','rmld:14450:173:0','+36',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(159,27,'14450','2012-11-05','2012-11','','male',1541,'','Möregårdh, Truls','2002','Eslövs AI BTK',1455,'-26','rmld:14450:172:0','-26',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(160,27,'14450','2012-10-01','2012-10','','male',1426,'','Möregårdh, Truls','2002','Eslövs AI BTK',1481,'+36','rmld:14450:171:0','+36',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(161,27,'14450','2012-09-03','2012-09','','male',1542,'','Möregårdh, Truls','2002','Eslövs AI BTK',1445,'+67','rmld:14450:169:0','+67',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(162,27,'14450','2012-08-06','2012-08','','male',1800,'','Möregårdh, Truls','2002','Eslövs AI BTK',1378,'+59','rmld:14450:168:0','+59',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(163,27,'14450','2012-07-02','2012-07','','male',2062,'','Möregårdh, Truls','2002','Eslövs AI BTK',1319,'0','rmld:14450:167:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(164,27,'14450','2012-07-02','2012-07','','male',2062,'','Möregårdh, Truls','2002','Eslövs AI BTK',1319,'0','rmld:14450:166:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(165,27,'14450','2012-06-04','2012-06','','male',2062,'','Möregårdh, Truls','2002','Eslövs AI BTK',1319,'0','rmld:14450:164:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(166,27,'14450','2012-05-07','2012-05','','male',2061,'','Möregårdh, Truls','2002','Eslövs AI BTK',1319,'+14','rmld:14450:163:0','+14',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(167,27,'14450','2012-04-02','2012-04','','male',2125,'','Möregårdh, Truls','2002','Eslövs AI BTK',1305,'-12','rmld:14450:162:0','-12',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(168,27,'14450','2012-03-05','2012-03','','male',2161,'','Möregårdh, Truls','2002','Eslövs AI BTK',1317,'+103','rmld:14450:161:0','+103',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(169,27,'14450','2012-02-06','2012-02','','male',2703,'','Möregårdh, Truls','2002','Eslövs AI BTK',1214,'-10','rmld:14450:160:0','-10',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(170,27,'14450','2012-01-02','2012-01','','male',2620,'','Möregårdh, Truls','2002','Eslövs AI BTK',1224,'0','rmld:14450:159:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(171,27,'14450','2011-12-05','2011-12','','male',2601,'','Möregårdh, Truls','2002','Eslövs AI BTK',1224,'+400','rmld:14450:158:0','+400',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(172,27,'14450','2011-11-07','2011-11','','male',4617,'','Möregårdh, Truls','2002','Eslövs AI BTK',824,'+57','rmld:14450:157:0','+57',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(173,27,'14450','2011-10-03','2011-10','','male',4144,'','Möregårdh, Truls','2002','Eslövs AI BTK',767,'+18','rmld:14450:156:0','+18',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(174,27,'14450','2011-09-05','2011-09','','male',3954,'','Möregårdh, Truls','2002','Eslövs AI BTK',749,'+124','rmld:14450:155:0','+124',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(175,27,'14450','2011-08-01','2011-08','','male',4192,'','Möregårdh, Truls','2002','Eslövs AI BTK',625,'0','rmld:14450:154:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(176,27,'14450','2011-07-04','2011-07','','male',4139,'','Möregårdh, Truls','2002','Eslövs AI BTK',625,'0','rmld:14450:151:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(177,27,'14450','2011-07-04','2011-07','','male',4138,'','Möregårdh, Truls','2002','Eslövs AI BTK',625,'0','rmld:14450:150:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(178,27,'14450','2011-05-02','2011-05','','male',4140,'','Möregårdh, Truls','2002','Eslövs AI BTK',625,'0','rmld:14450:147:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(179,27,'14450','2011-04-04','2011-04','','male',4314,'','Möregårdh, Truls','2002','Eslövs AI BTK',625,'0','rmld:14450:146:0','0',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(180,27,'14450','2011-03-07','2011-03','','male',4255,'','Möregårdh, Truls','2002','Eslövs AI BTK',625,'+83','rmld:14450:145:0','+83',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(181,27,'14450','2011-02-07','2011-02','','male',4419,'','Möregårdh, Truls','2002','Eslövs AI BTK',542,'+50','rmld:14450:144:0','+50',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(182,27,'14450','2011-01-03','2011-01','','male',4424,'','Möregårdh, Truls','2002','Eslövs AI BTK',492,'+103','rmld:14450:143:0','+103',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(183,27,'14450','2010-12-06','2010-12','','male',4471,'','Möregårdh, Truls','2002','Eslövs AI BTK',389,'+39','rmld:14450:142:0','+39',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(184,27,'14450','2010-11-01','2010-11','','male',3604,'','Möregårdh, Truls','2002','Eslövs AI BTK',350,'','rmld:14450:141:0','',1,NULL,1000,'2026-02-02 09:57:20','2026-02-02 09:57:54'),
(185,28,'13248','2026-01-05','2026-01','','female',1,'','Bergström, Linda','1995','Ängby SK',2240,'0','rmld:13248:391:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(186,28,'13248','2025-12-01','2025-12','','female',1,'','Bergström, Linda','1995','Ängby SK',2240,'0','rmld:13248:390:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(187,28,'13248','2025-11-03','2025-11','','female',1,'','Bergström, Linda','1995','Ängby SK',2240,'+26','rmld:13248:389:0','+26',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(188,28,'13248','2025-10-06','2025-10','','female',1,'','Bergström, Linda','1995','Ängby SK',2214,'0','rmld:13248:387:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(189,28,'13248','2025-09-01','2025-09','','female',1,'','Bergström, Linda','1995','Ängby SK',2214,'0','rmld:13248:386:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(190,28,'13248','2025-08-04','2025-08','','female',1,'','Bergström, Linda','1995','Ängby SK',2214,'0','rmld:13248:385:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(191,28,'13248','2025-07-08','2025-07','','female',1,'','Bergström, Linda','1995','Ängby SK',2214,'-19','rmld:13248:384:0','-19',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(192,28,'13248','2025-07-07','2025-07','','female',1,'','Bergström, Linda','1995','Ängby SK',2233,'0','rmld:13248:383:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(193,28,'13248','2025-06-02','2025-06','','female',1,'','Bergström, Linda','1995','Ängby SK',2233,'0','rmld:13248:382:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(194,28,'13248','2025-05-05','2025-05','','female',1,'','Bergström, Linda','1995','Ängby SK',2233,'0','rmld:13248:379:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(195,28,'13248','2025-04-07','2025-04','','female',1,'','Bergström, Linda','1995','Ängby SK',2233,'0','rmld:13248:378:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(196,28,'13248','2025-03-03','2025-03','','female',1,'','Bergström, Linda','1995','Ängby SK',2233,'+53','rmld:13248:377:0','+53',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(197,28,'13248','2025-02-03','2025-02','','female',1,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:376:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(198,28,'13248','2025-01-07','2025-01','','female',1,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:374:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(199,28,'13248','2024-12-02','2024-12','','female',1,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:373:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(200,28,'13248','2024-11-04','2024-11','','female',1,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:372:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(201,28,'13248','2024-10-07','2024-10','','female',1,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:368:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(202,28,'13248','2024-09-02','2024-09','','female',1,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:365:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(203,28,'13248','2024-08-05','2024-08','','female',2,'','Bergström, Linda','1995','Ängby SK',2180,'0','rmld:13248:364:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(204,28,'13248','2024-07-02','2024-07','','female',2,'','Bergström, Linda','1995','Ängby SK',2180,'-473','rmld:13248:363:0','-473',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(205,28,'13248','2024-07-01','2024-07','','female',2,'','Bergström, Linda','1995','Ängby SK',2653,'0','rmld:13248:361:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(206,28,'13248','2024-06-03','2024-06','','female',1,'','Bergström, Linda','1995','Ängby SK',2653,'0','rmld:13248:360:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(207,28,'13248','2024-05-06','2024-05','','female',1,'','Bergström, Linda','1995','Ängby SK',2653,'0','rmld:13248:356:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(208,28,'13248','2024-04-01','2024-04','','female',1,'','Bergström, Linda','1995','Ängby SK',2653,'+23','rmld:13248:355:0','+23',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(209,28,'13248','2024-03-04','2024-03','','female',1,'','Bergström, Linda','1995','Ängby SK',2630,'0','rmld:13248:353:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(210,28,'13248','2024-02-05','2024-02','','female',1,'','Bergström, Linda','1995','Ängby SK',2630,'0','rmld:13248:351:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(211,28,'13248','2024-01-02','2024-01','','female',2,'','Bergström, Linda','1995','Ängby SK',2630,'0','rmld:13248:350:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(212,28,'13248','2023-12-04','2023-12','','female',2,'','Bergström, Linda','1995','Ängby SK',2630,'0','rmld:13248:348:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(213,28,'13248','2023-11-06','2023-11','','female',2,'','Bergström, Linda','1995','Ängby SK',2630,'-5','rmld:13248:347:0','-5',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(214,28,'13248','2023-10-02','2023-10','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:346:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(215,28,'13248','2023-10-02','2023-10','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:345:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(216,28,'13248','2023-09-04','2023-09','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:344:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(217,28,'13248','2023-08-07','2023-08','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:343:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(218,28,'13248','2023-07-03','2023-07','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:341:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(219,28,'13248','2023-06-06','2023-06','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:340:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(220,28,'13248','2023-05-05','2023-05','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'0','rmld:13248:336:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(221,28,'13248','2023-04-03','2023-04','','female',2,'','Bergström, Linda','1995','Ängby SK',2635,'+31','rmld:13248:332:0','+31',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(222,28,'13248','2023-03-06','2023-03','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:331:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(223,28,'13248','2023-02-06','2023-02','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:330:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(224,28,'13248','2023-01-03','2023-01','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:329:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(225,28,'13248','2023-01-02','2023-01','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:328:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(226,28,'13248','2022-12-05','2022-12','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:327:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(227,28,'13248','2022-11-07','2022-11','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:326:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(228,28,'13248','2022-10-03','2022-10','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:325:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(229,28,'13248','2022-09-05','2022-09','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:324:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(230,28,'13248','2022-08-01','2022-08','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:323:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(231,28,'13248','2022-07-04','2022-07','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'0','rmld:13248:322:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(232,28,'13248','2022-06-07','2022-06','','female',2,'','Bergström, Linda','1995','Ängby SK',2604,'+57','rmld:13248:321:0','+57',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(233,28,'13248','2022-05-02','2022-05','','female',1,'','Bergström, Linda','1995','Ängby SK',2547,'0','rmld:13248:319:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(234,28,'13248','2022-04-04','2022-04','','female',1,'','Bergström, Linda','1995','Ängby SK',2547,'+9','rmld:13248:318:0','+9',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(235,28,'13248','2022-03-07','2022-03','','female',1,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:317:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(236,28,'13248','2022-02-07','2022-02','','female',1,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:316:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(237,28,'13248','2022-01-03','2022-01','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:315:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(238,28,'13248','2021-12-06','2021-12','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:313:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(239,28,'13248','2021-11-01','2021-11','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:312:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(240,28,'13248','2021-10-04','2021-10','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:311:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(241,28,'13248','2021-09-06','2021-09','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:305:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(242,28,'13248','2021-08-21','2021-08','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:304:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(243,28,'13248','2021-08-02','2021-08','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'0','rmld:13248:303:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(244,28,'13248','2021-07-05','2021-07','','female',2,'','Bergström, Linda','1995','Ängby SK',2538,'+38','rmld:13248:302:0','+38',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(245,28,'13248','2021-06-07','2021-06','','female',2,'','Bergström, Linda','1995','Ängby SK',2500,'0','rmld:13248:301:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(246,28,'13248','2021-05-03','2021-05','','female',2,'','Bergström, Linda','1995','Ängby SK',2500,'0','rmld:13248:300:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(247,28,'13248','2021-04-06','2021-04','','female',2,'','Bergström, Linda','1995','Ängby SK',2500,'+9','rmld:13248:299:0','+9',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(248,28,'13248','2021-03-01','2021-03','','female',2,'','Bergström, Linda','1995','Ängby SK',2491,'0','rmld:13248:297:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(249,28,'13248','2021-02-03','2021-02','','female',2,'','Bergström, Linda','1995','Ängby SK',2491,'0','rmld:13248:296:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(250,28,'13248','2020-12-07','2020-12','','female',2,'','Bergström, Linda','1995','Ängby SK',2491,'0','rmld:13248:293:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(251,28,'13248','2020-11-02','2020-11','','female',2,'','Bergström, Linda','1995','Ängby SK',2491,'0','rmld:13248:292:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(252,28,'13248','2020-10-05','2020-10','','female',2,'','Bergström, Linda','1995','Ängby SK',2491,'+18','rmld:13248:289:0','+18',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(253,28,'13248','2020-09-07','2020-09','','female',2,'','Bergström, Linda','1995','Ängby SK',2473,'-2','rmld:13248:288:0','-2',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(254,28,'13248','2020-04-06','2020-04','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:287:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(255,28,'13248','2020-03-02','2020-03','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:286:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(256,28,'13248','2020-02-03','2020-02','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:285:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(257,28,'13248','2020-01-06','2020-01','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:283:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(258,28,'13248','2019-12-02','2019-12','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:282:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(259,28,'13248','2019-11-04','2019-11','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:281:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(260,28,'13248','2019-10-07','2019-10','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'0','rmld:13248:280:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(261,28,'13248','2019-09-02','2019-09','','female',2,'','Bergström, Linda','1995','Ängby SK',2475,'+21','rmld:13248:279:0','+21',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(262,28,'13248','2019-08-05','2019-08','','female',4,'','Bergström, Linda','1995','Ängby SK',2454,'+18','rmld:13248:278:0','+18',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(263,28,'13248','2019-07-01','2019-07','','female',4,'','Bergström, Linda','1995','Ängby SK',2436,'0','rmld:13248:276:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(264,28,'13248','2019-06-03','2019-06','','female',6,'','Bergström, Linda','1995','Ängby SK',2436,'0','rmld:13248:274:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(265,28,'13248','2019-05-06','2019-05','','female',6,'','Bergström, Linda','1995','Ängby SK',2436,'0','rmld:13248:273:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(266,28,'13248','2019-04-01','2019-04','','female',7,'','Bergström, Linda','1995','Ängby SK',2436,'0','rmld:13248:272:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(267,28,'13248','2019-03-04','2019-03','','female',7,'','Bergström, Linda','1995','Ängby SK',2436,'+40','rmld:13248:271:0','+40',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(268,28,'13248','2019-02-04','2019-02','','female',8,'','Bergström, Linda','1995','Ängby SK',2396,'0','rmld:13248:270:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(269,28,'13248','2019-01-07','2019-01','','female',5,'','Bergström, Linda','1995','Ängby SK',2396,'0','rmld:13248:269:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(270,28,'13248','2018-12-03','2018-12','','female',6,'','Bergström, Linda','1995','Ängby SK',2396,'0','rmld:13248:268:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(271,28,'13248','2018-11-05','2018-11','','female',6,'','Bergström, Linda','1995','Ängby SK',2396,'0','rmld:13248:267:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(272,28,'13248','2018-10-01','2018-10','','female',6,'','Bergström, Linda','1995','Ängby SK',2396,'0','rmld:13248:266:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(273,28,'13248','2018-09-03','2018-09','','female',6,'','Bergström, Linda','1995','Ängby SK',2396,'0','rmld:13248:264:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(274,28,'13248','2018-08-06','2018-08','','female',6,'','Bergström, Linda','1995','Ängby SK',2396,'+47','rmld:13248:263:0','+47',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(275,28,'13248','2018-07-02','2018-07','','female',6,'','Bergström, Linda','1995','Ängby SK',2349,'0','rmld:13248:261:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(276,28,'13248','2018-06-04','2018-06','','female',7,'','Bergström, Linda','1995','Ängby SK',2349,'0','rmld:13248:260:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(277,28,'13248','2018-05-07','2018-05','','female',7,'','Bergström, Linda','1995','Ängby SK',2349,'0','rmld:13248:259:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(278,28,'13248','2018-04-02','2018-04','','female',7,'','Bergström, Linda','1995','Ängby SK',2349,'0','rmld:13248:258:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(279,28,'13248','2018-03-05','2018-03','','female',5,'','Bergström, Linda','1995','Ängby SK',2349,'+48','rmld:13248:256:0','+48',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(280,28,'13248','2018-02-05','2018-02','','female',8,'','Bergström, Linda','1995','Ängby SK',2301,'0','rmld:13248:255:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(281,28,'13248','2018-01-02','2018-01','','female',7,'','Bergström, Linda','1995','Ängby SK',2301,'0','rmld:13248:251:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(282,28,'13248','2017-12-04','2017-12','','female',8,'','Bergström, Linda','1995','Ängby SK',2301,'0','rmld:13248:247:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(283,28,'13248','2017-11-06','2017-11','','female',9,'','Bergström, Linda','1995','Ängby SK',2301,'+18','rmld:13248:246:0','+18',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(284,28,'13248','2017-10-02','2017-10','','female',9,'','Bergström, Linda','1995','Ängby SK',2283,'0','rmld:13248:245:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(285,28,'13248','2017-09-04','2017-09','','female',9,'','Bergström, Linda','1995','Ängby SK',2283,'0','rmld:13248:242:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(286,28,'13248','2017-08-07','2017-08','','female',9,'','Bergström, Linda','1995','Ängby SK',2283,'+26','rmld:13248:241:0','+26',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(287,28,'13248','2017-07-03','2017-07','','female',11,'','Bergström, Linda','1995','Ängby SK',2257,'0','rmld:13248:240:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(288,28,'13248','2017-06-05','2017-06','','female',13,'','Bergström, Linda','1995','Ängby SK',2257,'0','rmld:13248:239:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(289,28,'13248','2017-05-01','2017-05','','female',242,'','Bergström, Linda','1995','Ängby SK',2257,'0','rmld:13248:238:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(290,28,'13248','2017-04-03','2017-04','','female',253,'','Bergström, Linda','1995','Ängby SK',2257,'0','rmld:13248:237:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(291,28,'13248','2017-03-06','2017-03','','female',252,'','Bergström, Linda','1995','Ängby SK',2257,'+19','rmld:13248:236:0','+19',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(292,28,'13248','2017-02-06','2017-02','','female',264,'','Bergström, Linda','1995','Ängby SK',2238,'0','rmld:13248:235:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(293,28,'13248','2017-01-02','2017-01','','female',262,'','Bergström, Linda','1995','Ängby SK',2238,'0','rmld:13248:234:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(294,28,'13248','2016-12-05','2016-12','','female',263,'','Bergström, Linda','1995','Ängby SK',2238,'0','rmld:13248:233:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(295,28,'13248','2016-11-07','2016-11','','female',260,'','Bergström, Linda','1995','Ängby SK',2238,'0','rmld:13248:232:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(296,28,'13248','2016-10-03','2016-10','','female',242,'','Bergström, Linda','1995','Ängby SK',2238,'0','rmld:13248:230:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(297,28,'13248','2016-09-05','2016-09','','female',8,'','Bergström, Linda','1995','Ängby SK',2238,'+16','rmld:13248:229:0','+16',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(298,28,'13248','2016-08-01','2016-08','','female',8,'','Bergström, Linda','1995','Ängby SK',2222,'0','rmld:13248:228:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(299,28,'13248','2016-07-04','2016-07','','female',238,'','Bergström, Linda','1995','Ängby SK',2222,'0','rmld:13248:227:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(300,28,'13248','2016-06-06','2016-06','','female',238,'','Bergström, Linda','1995','Ängby SK',2222,'-26','rmld:13248:226:0','-26',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(301,28,'13248','2016-05-02','2016-05','','female',216,'','Bergström, Linda','1995','Ängby SK',2248,'0','rmld:13248:225:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(302,28,'13248','2016-04-04','2016-04','','female',6,'','Bergström, Linda','1995','Ängby SK',2248,'-1','rmld:13248:224:0','-1',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(303,28,'13248','2016-03-07','2016-03','','female',210,'','Bergström, Linda','1995','Ängby SK',2249,'+9','rmld:13248:223:0','+9',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(304,28,'13248','2016-02-01','2016-02','','female',220,'','Bergström, Linda','1995','Ängby SK',2240,'0','rmld:13248:222:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(305,28,'13248','2016-01-04','2016-01','','female',6,'','Bergström, Linda','1995','Ängby SK',2240,'0','rmld:13248:221:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(306,28,'13248','2015-12-07','2015-12','','female',5,'','Bergström, Linda','1995','Ängby SK',2240,'+20','rmld:13248:220:0','+20',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(307,28,'13248','2015-11-02','2015-11','','female',204,'','Bergström, Linda','1995','Ängby SK',2220,'+37','rmld:13248:219:0','+37',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(308,28,'13248','2015-10-05','2015-10','','female',231,'','Bergström, Linda','1995','Ängby SK',2183,'0','rmld:13248:217:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(309,28,'13248','2015-09-07','2015-09','','female',219,'','Bergström, Linda','1995','Ängby SK',2183,'0','rmld:13248:215:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(310,28,'13248','2015-08-03','2015-08','','female',212,'','Bergström, Linda','1995','Ängby SK',2183,'+17','rmld:13248:214:0','+17',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(311,28,'13248','2015-07-06','2015-07','','female',227,'','Bergström, Linda','1995','Ängby SK',2166,'+4','rmld:13248:213:0','+4',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(312,28,'13248','2015-06-01','2015-06','','female',230,'','Bergström, Linda','1995','Ängby SK',2162,'+16','rmld:13248:212:0','+16',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(313,28,'13248','2015-05-04','2015-05','','female',247,'','Bergström, Linda','1995','Ängby SK',2146,'-10','rmld:13248:211:0','-10',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(314,28,'13248','2015-04-06','2015-04','','female',248,'','Bergström, Linda','1995','Ängby SK',2156,'-5','rmld:13248:209:0','-5',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(315,28,'13248','2015-03-02','2015-03','','female',234,'','Bergström, Linda','1995','Ängby SK',2161,'+42','rmld:13248:208:0','+42',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(316,28,'13248','2015-02-02','2015-02','','female',264,'','Bergström, Linda','1995','Ängby SK',2119,'+21','rmld:13248:207:0','+21',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(317,28,'13248','2015-01-06','2015-01','','female',10,'','Bergström, Linda','1995','Ängby SK',2098,'+34','rmld:13248:206:0','+34',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(318,28,'13248','2014-12-01','2014-12','','female',296,'','Bergström, Linda','1995','Ängby SK',2064,'-1','rmld:13248:205:0','-1',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(319,28,'13248','2014-11-03','2014-11','','female',281,'','Bergström, Linda','1995','Ängby SK',2065,'+46','rmld:13248:204:0','+46',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(320,28,'13248','2014-10-06','2014-10','','female',9,'','Bergström, Linda','1995','Ängby SK',2019,'+6','rmld:13248:203:0','+6',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(321,28,'13248','2014-09-01','2014-09','','female',313,'','Bergström, Linda','1995','Ängby SK',2013,'+23','rmld:13248:202:0','+23',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(322,28,'13248','2014-08-04','2014-08','','female',338,'','Bergström, Linda','1995','Ängby SK',1990,'+16','rmld:13248:201:0','+16',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(323,28,'13248','2014-07-07','2014-07','','female',10,'','Bergström, Linda','1995','Ängby SK',1974,'0','rmld:13248:200:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(324,28,'13248','2014-06-02','2014-06','','female',10,'','Bergström, Linda','1995','Ängby SK',1974,'0','rmld:13248:199:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(325,28,'13248','2014-05-05','2014-05','','female',350,'','Bergström, Linda','1995','Ängby SK',1974,'-33','rmld:13248:197:0','-33',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(326,28,'13248','2014-04-07','2014-04','','female',311,'','Bergström, Linda','1995','Ängby SK',2007,'-28','rmld:13248:196:0','-28',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(327,28,'13248','2014-03-03','2014-03','','female',275,'','Bergström, Linda','1995','Ängby SK',2035,'-5','rmld:13248:195:0','-5',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(328,28,'13248','2014-02-03','2014-02','','female',6,'','Bergström, Linda','1995','Ängby SK',2040,'+92','rmld:13248:194:0','+92',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(329,28,'13248','2014-01-06','2014-01','','female',11,'','Bergström, Linda','1995','Ängby SK',1948,'+10','rmld:13248:192:0','+10',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(330,28,'13248','2013-12-02','2013-12','','female',364,'','Bergström, Linda','1995','Ängby SK',1938,'+81','rmld:13248:191:0','+81',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(331,28,'13248','2013-11-04','2013-11','','female',466,'','Bergström, Linda','1995','Ängby SK',1857,'+36','rmld:13248:190:0','+36',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(332,28,'13248','2013-10-07','2013-10','','female',526,'','Bergström, Linda','1995','Ängby SK',1821,'+34','rmld:13248:188:0','+34',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(333,28,'13248','2013-09-02','2013-09','','female',562,'','Bergström, Linda','1995','Ängby SK',1787,'+24','rmld:13248:187:0','+24',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(334,28,'13248','2013-08-05','2013-08','','female',607,'','Bergström, Linda','1995','Ängby SK',1763,'0','rmld:13248:186:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(335,28,'13248','2013-07-01','2013-07','','female',605,'','Bergström, Linda','1995','Ängby SK',1763,'0','rmld:13248:185:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(336,28,'13248','2013-06-03','2013-06','','female',605,'','Bergström, Linda','1995','Ängby SK',1763,'-10','rmld:13248:184:0','-10',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(337,28,'13248','2013-05-06','2013-05','','female',577,'','Bergström, Linda','1995','Ängby SK',1773,'-12','rmld:13248:183:0','-12',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(338,28,'13248','2013-04-01','2013-04','','female',560,'','Bergström, Linda','1995','Ängby SK',1785,'+4','rmld:13248:182:0','+4',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(339,28,'13248','2013-03-04','2013-03','','female',582,'','Bergström, Linda','1995','Ängby SK',1781,'-59','rmld:13248:181:0','-59',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(340,28,'13248','2013-02-04','2013-02','','female',465,'','Bergström, Linda','1995','Ängby SK',1840,'-9','rmld:13248:180:0','-9',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(341,28,'13248','2013-01-07','2013-01','','female',441,'','Bergström, Linda','1995','Ängby SK',1849,'+38','rmld:13248:179:0','+38',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(342,28,'13248','2012-12-03','2012-12','','female',514,'','Bergström, Linda','1995','Ängby SK',1811,'+47','rmld:13248:173:0','+47',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(343,28,'13248','2012-11-05','2012-11','','female',620,'','Bergström, Linda','1995','Ängby SK',1764,'+18','rmld:13248:172:0','+18',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(344,28,'13248','2012-10-01','2012-10','','female',640,'','Bergström, Linda','1995','Ängby SK',1746,'+104','rmld:13248:171:0','+104',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(345,28,'13248','2012-09-03','2012-09','','female',891,'','Bergström, Linda','1995','Ängby SK',1642,'+10','rmld:13248:169:0','+10',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(346,28,'13248','2012-08-06','2012-08','','female',918,'','Bergström, Linda','1995','Ängby SK',1632,'0','rmld:13248:168:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(347,28,'13248','2012-07-02','2012-07','','female',922,'','Bergström, Linda','1995','Ängby SK',1632,'0','rmld:13248:167:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(348,28,'13248','2012-07-02','2012-07','','female',922,'','Bergström, Linda','1995','Ängby SK',1632,'0','rmld:13248:166:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(349,28,'13248','2012-06-04','2012-06','','female',922,'','Bergström, Linda','1995','Ängby SK',1632,'0','rmld:13248:164:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(350,28,'13248','2012-05-07','2012-05','','female',918,'','Bergström, Linda','1995','Ängby SK',1632,'-82','rmld:13248:163:0','-82',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(351,28,'13248','2012-04-02','2012-04','','female',700,'','Bergström, Linda','1995','Ängby SK',1714,'+6','rmld:13248:162:0','+6',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(352,28,'13248','2012-03-05','2012-03','','female',748,'','Bergström, Linda','1995','Ängby SK',1708,'+90','rmld:13248:161:0','+90',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(353,28,'13248','2012-02-06','2012-02','','female',1039,'','Bergström, Linda','1995','Ängby SK',1618,'-107','rmld:13248:160:0','-107',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(354,28,'13248','2012-01-02','2012-01','','female',729,'','Bergström, Linda','1995','Ängby SK',1725,'+15','rmld:13248:159:0','+15',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(355,28,'13248','2011-12-05','2011-12','','female',771,'','Bergström, Linda','1995','Ängby SK',1710,'0','rmld:13248:158:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(356,28,'13248','2011-11-07','2011-11','','female',772,'','Bergström, Linda','1995','Ängby SK',1710,'+29','rmld:13248:157:0','+29',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(357,28,'13248','2011-10-03','2011-10','','female',856,'','Bergström, Linda','1995','Ängby SK',1681,'+20','rmld:13248:156:0','+20',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(358,28,'13248','2011-09-05','2011-09','','female',905,'','Bergström, Linda','1995','Ängby SK',1661,'+177','rmld:13248:155:0','+177',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(359,28,'13248','2011-08-01','2011-08','','female',1365,'','Bergström, Linda','1995','Ängby SK',1484,'0','rmld:13248:154:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(360,28,'13248','2011-07-04','2011-07','','female',1345,'','Bergström, Linda','1995','Ängby SK',1484,'0','rmld:13248:151:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(361,28,'13248','2011-07-04','2011-07','','female',1344,'','Bergström, Linda','1995','Ängby SK',1484,'0','rmld:13248:150:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(362,28,'13248','2011-05-02','2011-05','','female',1345,'','Bergström, Linda','1995','Ängby SK',1484,'+52','rmld:13248:147:0','+52',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(363,28,'13248','2011-04-04','2011-04','','female',1634,'','Bergström, Linda','1995','Ängby SK',1432,'+29','rmld:13248:146:0','+29',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(364,28,'13248','2011-03-07','2011-03','','female',1733,'','Bergström, Linda','1995','Ängby SK',1403,'+31','rmld:13248:145:0','+31',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(365,28,'13248','2011-02-07','2011-02','','female',1844,'','Bergström, Linda','1995','Ängby SK',1372,'-1','rmld:13248:144:0','-1',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(366,28,'13248','2011-01-03','2011-01','','female',1846,'','Bergström, Linda','1995','Ängby SK',1373,'0','rmld:13248:143:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(367,28,'13248','2010-12-06','2010-12','','female',1857,'','Bergström, Linda','1995','Ängby SK',1373,'+42','rmld:13248:142:0','+42',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(368,28,'13248','2010-11-01','2010-11','','female',1879,'','Bergström, Linda','1995','Ängby SK',1331,'-3','rmld:13248:141:0','-3',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(369,28,'13248','2010-10-04','2010-10','','female',120,'','Bergström, Linda','1995','Ängby SK',1334,'+16','rmld:13248:140:0','+16',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(370,28,'13248','2010-08-02','2010-08','','female',1511,'','Bergström, Linda','1995','Ängby SK',1318,'0','rmld:13248:139:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(371,28,'13248','2010-08-02','2010-08','','female',128,'','Bergström, Linda','1995','Ängby SK',1318,'0','rmld:13248:138:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(372,28,'13248','2010-05-03','2010-05','','female',2719,'','Bergström, Linda','1995','Ängby SK',1318,'+10','rmld:13248:137:0','+10',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(373,28,'13248','2010-04-05','2010-04','','female',2718,'','Bergström, Linda','1995','Ängby SK',1308,'0','rmld:13248:136:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(374,28,'13248','2010-03-01','2010-03','','female',2716,'','Bergström, Linda','1995','Ängby SK',1308,'0','rmld:13248:135:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(375,28,'13248','2010-02-01','2010-02','','female',2710,'','Bergström, Linda','1995','Ängby SK',1308,'0','rmld:13248:134:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(376,28,'13248','2010-01-04','2010-01','','female',2693,'','Bergström, Linda','1995','Ängby SK',1308,'0','rmld:13248:133:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(377,28,'13248','2009-12-07','2009-12','','female',2691,'','Bergström, Linda','1995','Ängby SK',1308,'0','rmld:13248:132:0','0',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(378,28,'13248','2009-11-02','2009-11','','female',2681,'','Bergström, Linda','1995','Ängby SK',1308,'+90','rmld:13248:131:0','+90',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(379,28,'13248','2009-10-05','2009-10','','female',4695,'','Bergström, Linda','1995','Ängby SK',1218,'-52','rmld:13248:130:0','-52',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54'),
(380,28,'13248','2009-08-01','2009-08','','female',175,'','Bergström, Linda','1995','Ängby SK',1270,'','rmld:13248:1:0','',1,NULL,1001,'2026-02-02 09:57:53','2026-02-02 09:57:54');
/*!40000 ALTER TABLE `scraped_rankings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_standings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_standings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `series_name` varchar(255) NOT NULL,
  `session_name` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL,
  `team_name` varchar(255) NOT NULL,
  `matches_played` int(11) NOT NULL DEFAULT 0,
  `wins` int(11) NOT NULL DEFAULT 0,
  `losses` int(11) NOT NULL DEFAULT 0,
  `draws` int(11) NOT NULL DEFAULT 0,
  `points` int(11) NOT NULL DEFAULT 0,
  `goal_difference` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_standings_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_standings_period_series_name_index` (`period`,`series_name`),
  CONSTRAINT `scraped_standings_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_standings` WRITE;
/*!40000 ALTER TABLE `scraped_standings` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_standings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraped_transitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraped_transitions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `period` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `born` varchar(255) DEFAULT NULL,
  `from_club` varchar(255) NOT NULL,
  `to_club` varchar(255) NOT NULL,
  `completion_date` varchar(255) DEFAULT NULL,
  `is_synced` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraped_transitions_scraper_run_id_foreign` (`scraper_run_id`),
  KEY `scraped_transitions_surname_first_name_index` (`surname`,`first_name`),
  CONSTRAINT `scraped_transitions_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraped_transitions` WRITE;
/*!40000 ALTER TABLE `scraped_transitions` DISABLE KEYS */;
/*!40000 ALTER TABLE `scraped_transitions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `scraper_run_id` bigint(20) unsigned NOT NULL,
  `level` varchar(255) NOT NULL DEFAULT 'info',
  `message` text NOT NULL,
  `context` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`context`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_logs_scraper_run_id_level_index` (`scraper_run_id`,`level`),
  CONSTRAINT `scraper_logs_scraper_run_id_foreign` FOREIGN KEY (`scraper_run_id`) REFERENCES `scraper_runs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3852 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_logs` WRITE;
/*!40000 ALTER TABLE `scraper_logs` DISABLE KEYS */;
INSERT INTO `scraper_logs` VALUES
(3458,10,'info','Starting: Creating Database Backup','[]','2026-02-02 09:42:58','2026-02-02 09:42:58'),
(3459,10,'info','Completed: Creating Database Backup (in 0.14s)','[]','2026-02-02 09:42:58','2026-02-02 09:42:58'),
(3460,10,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:42:58','2026-02-02 09:42:58'),
(3461,11,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3462,11,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3463,11,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'1\'','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3464,11,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3465,11,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3466,11,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3467,11,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3468,11,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3469,10,'info','Completed: Scraping Rankings & Matches (Male) (in 1.01s)','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3470,10,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(3471,12,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3472,12,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3473,12,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'1\'','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3474,12,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3475,12,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3476,12,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3477,12,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3478,12,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3479,10,'info','Completed: Scraping Rankings & Matches (Female) (in 1.00s)','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3480,10,'info','Starting: Syncing Rankings','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3481,10,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(3482,10,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3483,10,'info','Completed: Syncing Rankings (in 0.03s)','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3484,10,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3485,10,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3486,10,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3487,10,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3488,10,'info','Completed: Creating Monthly Rankings (in 0.00s)','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3489,10,'info','Starting: Syncing Matches','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3490,10,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3491,10,'info','Marking unofficial matches...','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3492,10,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3493,10,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3494,10,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3495,13,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3496,13,'info','Starting series scrape','[]','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3497,13,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:43:01','2026-02-02 09:43:01'),
(3498,14,'info','Starting: Creating Database Backup','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3499,14,'info','Completed: Creating Database Backup (in 0.14s)','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3500,14,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3501,15,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3502,15,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3503,15,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'1\'','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3504,15,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3505,15,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3506,15,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3507,15,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3508,15,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(3509,14,'info','Completed: Scraping Rankings & Matches (Male) (in 1.01s)','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3510,14,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3511,16,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3512,16,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3513,16,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'1\'','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3514,16,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3515,16,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3516,16,'info','Python: from playwright.async_api import async_playwright, Page, Browser, BrowserContext','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3517,16,'info','Python: ModuleNotFoundError: No module named \'playwright\'','[]','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3518,16,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 32, in <module>\\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\\nModuleNotFoundError: No module named \'playwright\'\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(3519,14,'info','Completed: Scraping Rankings & Matches (Female) (in 1.00s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3520,14,'info','Starting: Syncing Rankings','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3521,14,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3522,14,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3523,14,'info','Completed: Syncing Rankings (in 0.03s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3524,14,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3525,14,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3526,14,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3527,14,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3528,14,'info','Completed: Creating Monthly Rankings (in 0.00s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3529,14,'info','Starting: Syncing Matches','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3530,14,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3531,14,'info','Marking unofficial matches...','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3532,14,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3533,14,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3534,14,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3535,17,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3536,17,'info','Starting series scrape','[]','2026-02-02 09:47:46','2026-02-02 09:47:46'),
(3537,17,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:47:47','2026-02-02 09:47:47'),
(3538,18,'info','Starting: Creating Database Backup','[]','2026-02-02 09:52:41','2026-02-02 09:52:41'),
(3539,18,'info','Completed: Creating Database Backup (in 0.15s)','[]','2026-02-02 09:52:41','2026-02-02 09:52:41'),
(3540,18,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:52:41','2026-02-02 09:52:41'),
(3541,19,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3542,19,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3543,19,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'111\'','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3544,19,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3545,19,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3546,19,'info','Python: asyncio.run(main())','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3547,19,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3548,19,'info','Python:     return runner.run(main)','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3549,19,'info','Python:            ^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3550,19,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3551,19,'info','Python:     return self._loop.run_until_complete(task)','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3552,19,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3553,19,'info','Python:   File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3554,19,'info','Python:     return future.result()','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3555,19,'info','Python:            ^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3556,19,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3557,19,'info','Python:     result = await scraper.run()','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3558,19,'info','Python:              ^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3559,19,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3560,19,'info','Python:     self.browser = await p.chromium.launch(','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3561,19,'info','Python:                    ^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3562,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3563,19,'info','Python:     await self._impl_obj.launch(','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3564,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3565,19,'info','Python:     Browser, from_channel(await self._channel.send(\"launch\", params))','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3566,19,'info','Python:                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3567,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3568,19,'info','Python:     return await self._connection.wrap_api_call(','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3569,19,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3570,19,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3571,19,'info','Python:     raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3572,19,'info','Python: playwright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3573,19,'info','Python: ╔════════════════════════════════════════════════════════════╗','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3574,19,'info','Python: ║ Looks like Playwright was just installed or updated.       ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3575,19,'info','Python: ║ Please run the following command to download new browsers: ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3576,19,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3577,19,'info','Python: ║     playwright install                                     ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3578,19,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3579,19,'info','Python: ║ <3 Playwright Team                                         ║','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3580,19,'info','Python: ╚════════════════════════════════════════════════════════════╝','[]','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3581,19,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 449, in <module>\\n    asyncio.run(main())\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 190, in run\\n    return runner.run(main)\\n           ^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 118, in run\\n    return self._loop.run_until_complete(task)\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/base_events.py\\\", line 653, in run_until_complete\\n    return future.result()\\n           ^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 442, in main\\n    result = await scraper.run()\\n             ^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 64, in run\\n    self.browser = await p.chromium.launch(\\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/async_api\\/_generated.py\\\", line 14398, in launch\\n    await self._impl_obj.launch(\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_browser_type.py\\\", line 95, in launch\\n    Browser, from_channel(await self._channel.send(\\\"launch\\\", params))\\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 59, in send\\n    return await self._connection.wrap_api_call(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 520, in wrap_api_call\\n    raise rewrite_error(error, f\\\"{parsed_st[\'apiName\']}: {error}\\\") from None\\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at \\/home\\/webook\\/.cache\\/ms-playwright\\/chromium-1140\\/chrome-linux\\/chrome\\n\\u2554\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2557\\n\\u2551 Looks like Playwright was just installed or updated.       \\u2551\\n\\u2551 Please run the following command to download new browsers: \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551     playwright install                                     \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551 <3 Playwright Team                                         \\u2551\\n\\u255a\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u255d\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(3582,18,'info','Completed: Scraping Rankings & Matches (Male) (in 2.01s)','[]','2026-02-02 09:52:43','2026-02-02 09:52:43'),
(3583,18,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:52:43','2026-02-02 09:52:43'),
(3584,20,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3585,20,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3586,20,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'111\'','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3587,20,'info','Python: Traceback (most recent call last):','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3588,20,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3589,20,'info','Python: asyncio.run(main())','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3590,20,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3591,20,'info','Python:     return runner.run(main)','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3592,20,'info','Python:            ^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3593,20,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3594,20,'info','Python:     return self._loop.run_until_complete(task)','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3595,20,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3596,20,'info','Python:   File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3597,20,'info','Python:     return future.result()','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3598,20,'info','Python:            ^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3599,20,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3600,20,'info','Python:     result = await scraper.run()','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3601,20,'info','Python:              ^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3602,20,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3603,20,'info','Python:     self.browser = await p.chromium.launch(','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3604,20,'info','Python:                    ^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3605,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3606,20,'info','Python:     await self._impl_obj.launch(','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3607,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3608,20,'info','Python:     Browser, from_channel(await self._channel.send(\"launch\", params))','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3609,20,'info','Python:                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3610,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3611,20,'info','Python:     return await self._connection.wrap_api_call(','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3612,20,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3613,20,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3614,20,'info','Python:     raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3615,20,'info','Python: playwright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3616,20,'info','Python: ╔════════════════════════════════════════════════════════════╗','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3617,20,'info','Python: ║ Looks like Playwright was just installed or updated.       ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3618,20,'info','Python: ║ Please run the following command to download new browsers: ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3619,20,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3620,20,'info','Python: ║     playwright install                                     ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3621,20,'info','Python: ║                                                            ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3622,20,'info','Python: ║ <3 Playwright Team                                         ║','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3623,20,'info','Python: ╚════════════════════════════════════════════════════════════╝','[]','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3624,20,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 449, in <module>\\n    asyncio.run(main())\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 190, in run\\n    return runner.run(main)\\n           ^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 118, in run\\n    return self._loop.run_until_complete(task)\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/base_events.py\\\", line 653, in run_until_complete\\n    return future.result()\\n           ^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 442, in main\\n    result = await scraper.run()\\n             ^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 64, in run\\n    self.browser = await p.chromium.launch(\\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/async_api\\/_generated.py\\\", line 14398, in launch\\n    await self._impl_obj.launch(\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_browser_type.py\\\", line 95, in launch\\n    Browser, from_channel(await self._channel.send(\\\"launch\\\", params))\\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 59, in send\\n    return await self._connection.wrap_api_call(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 520, in wrap_api_call\\n    raise rewrite_error(error, f\\\"{parsed_st[\'apiName\']}: {error}\\\") from None\\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at \\/home\\/webook\\/.cache\\/ms-playwright\\/chromium-1140\\/chrome-linux\\/chrome\\n\\u2554\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2557\\n\\u2551 Looks like Playwright was just installed or updated.       \\u2551\\n\\u2551 Please run the following command to download new browsers: \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551     playwright install                                     \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551 <3 Playwright Team                                         \\u2551\\n\\u255a\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u255d\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(3625,18,'info','Completed: Scraping Rankings & Matches (Female) (in 2.01s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3626,18,'info','Starting: Syncing Rankings','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3627,18,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3628,18,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3629,18,'info','Completed: Syncing Rankings (in 0.04s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3630,18,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3631,18,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3632,18,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3633,18,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3634,18,'info','Completed: Creating Monthly Rankings (in 0.01s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3635,18,'info','Starting: Syncing Matches','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3636,18,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3637,18,'info','Marking unofficial matches...','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3638,18,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3639,18,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3640,18,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:52:45','2026-02-02 09:52:45'),
(3641,21,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:52:46','2026-02-02 09:52:46'),
(3642,21,'info','Starting series scrape','[]','2026-02-02 09:52:46','2026-02-02 09:52:46'),
(3643,21,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:52:46','2026-02-02 09:52:46'),
(3644,22,'info','Starting: Creating Database Backup','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3645,22,'info','Completed: Creating Database Backup (in 0.17s)','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3646,22,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3647,23,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3648,23,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3649,23,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'111\'','[]','2026-02-02 09:53:54','2026-02-02 09:53:54'),
(3650,23,'info','Python: [ERROR] Fatal error: Month 2025.11.01 not found in dropdown','[]','2026-02-02 09:53:59','2026-02-02 09:53:59'),
(3651,23,'error','Scrape failed','{\"message\":\"Python scraper failed: [{\\\"error\\\":\\\"Month 2025.11.01 not found in dropdown\\\"}]\",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#1 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#3 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#9 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#11 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#16 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#17 {main}\"}','2026-02-02 09:53:59','2026-02-02 09:53:59'),
(3652,22,'info','Completed: Scraping Rankings & Matches (Male) (in 6.02s)','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3653,22,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3654,24,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3655,24,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3656,24,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'111\'','[]','2026-02-02 09:54:00','2026-02-02 09:54:00'),
(3657,24,'info','Python: [ERROR] Fatal error: Month 2025.11.01 not found in dropdown','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3658,24,'error','Scrape failed','{\"message\":\"Python scraper failed: [{\\\"error\\\":\\\"Month 2025.11.01 not found in dropdown\\\"}]\",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#1 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#3 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#9 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#11 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#16 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#17 {main}\"}','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3659,22,'info','Completed: Scraping Rankings & Matches (Female) (in 5.02s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3660,22,'info','Starting: Syncing Rankings','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3661,22,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3662,22,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3663,22,'info','Completed: Syncing Rankings (in 0.04s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3664,22,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3665,22,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3666,22,'info','Found 0 unique user/period combinations to process','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3667,22,'info','Monthly rankings creation completed: 0 created, 0 errors','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3668,22,'info','Completed: Creating Monthly Rankings (in 0.00s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3669,22,'info','Starting: Syncing Matches','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3670,22,'info','Starting match sync: 0 matches to process','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3671,22,'info','Marking unofficial matches...','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3672,22,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3673,22,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3674,22,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:54:05','2026-02-02 09:54:05'),
(3675,25,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 09:54:06','2026-02-02 09:54:06'),
(3676,25,'info','Starting series scrape','[]','2026-02-02 09:54:06','2026-02-02 09:54:06'),
(3677,25,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:54:06','2026-02-02 09:54:06'),
(3678,26,'info','Starting: Creating Database Backup','[]','2026-02-02 09:56:47','2026-02-02 09:56:47'),
(3679,26,'info','Completed: Creating Database Backup (in 0.14s)','[]','2026-02-02 09:56:47','2026-02-02 09:56:47'),
(3680,26,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 09:56:47','2026-02-02 09:56:47'),
(3681,27,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"12\",\"gender\":\"m\",\"limit_players\":1}','2026-02-02 09:56:48','2026-02-02 09:56:48'),
(3682,27,'info','Starting Python Playwright rankings scraper for 2025-12, gender: m','[]','2026-02-02 09:56:48','2026-02-02 09:56:48'),
(3683,27,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'12\' \'--gender\' \'m\' \'--limit\' \'1\'','[]','2026-02-02 09:56:48','2026-02-02 09:56:48'),
(3684,27,'info','Python: [INFO] Found rid=390 for 2025-12','[]','2026-02-02 09:56:51','2026-02-02 09:56:51'),
(3685,27,'info','Python: [INFO] Found 504 players','[]','2026-02-02 09:57:08','2026-02-02 09:57:08'),
(3686,27,'info','Python: [INFO] Limited to 1 players','[]','2026-02-02 09:57:08','2026-02-02 09:57:08'),
(3687,27,'info','Python: [INFO] Processing 1/1: Möregårdh, Truls','[]','2026-02-02 09:57:08','2026-02-02 09:57:08'),
(3688,27,'info','Python scraper completed: 1 players, 184 rankings, 2 matches','[]','2026-02-02 09:57:20','2026-02-02 09:57:20'),
(3689,27,'info','Rankings scraper completed: 1 players processed, 184 rankings saved, 2 matches saved','[]','2026-02-02 09:57:20','2026-02-02 09:57:20'),
(3690,27,'info','Scrape completed','{\"items_scraped\":186,\"items_failed\":null}','2026-02-02 09:57:20','2026-02-02 09:57:20'),
(3691,26,'info','Completed: Scraping Rankings & Matches (Male) (in 33.09s)','[]','2026-02-02 09:57:20','2026-02-02 09:57:20'),
(3692,26,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 09:57:20','2026-02-02 09:57:20'),
(3693,28,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"12\",\"gender\":\"k\",\"limit_players\":1}','2026-02-02 09:57:21','2026-02-02 09:57:21'),
(3694,28,'info','Starting Python Playwright rankings scraper for 2025-12, gender: k','[]','2026-02-02 09:57:21','2026-02-02 09:57:21'),
(3695,28,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'12\' \'--gender\' \'k\' \'--limit\' \'1\'','[]','2026-02-02 09:57:21','2026-02-02 09:57:21'),
(3696,28,'info','Python: [INFO] Found rid=390 for 2025-12','[]','2026-02-02 09:57:24','2026-02-02 09:57:24'),
(3697,28,'info','Python: [INFO] Found 502 players','[]','2026-02-02 09:57:42','2026-02-02 09:57:42'),
(3698,28,'info','Python: [INFO] Limited to 1 players','[]','2026-02-02 09:57:42','2026-02-02 09:57:42'),
(3699,28,'info','Python: [INFO] Processing 1/1: Bergström, Linda','[]','2026-02-02 09:57:42','2026-02-02 09:57:42'),
(3700,28,'info','Python scraper completed: 1 players, 196 rankings, 0 matches','[]','2026-02-02 09:57:53','2026-02-02 09:57:53'),
(3701,28,'info','Rankings scraper completed: 1 players processed, 196 rankings saved, 0 matches saved','[]','2026-02-02 09:57:53','2026-02-02 09:57:53'),
(3702,28,'info','Scrape completed','{\"items_scraped\":196,\"items_failed\":null}','2026-02-02 09:57:53','2026-02-02 09:57:53'),
(3703,26,'info','Completed: Scraping Rankings & Matches (Female) (in 33.08s)','[]','2026-02-02 09:57:53','2026-02-02 09:57:53'),
(3704,26,'info','Starting: Syncing Rankings','[]','2026-02-02 09:57:53','2026-02-02 09:57:53'),
(3705,26,'info','Starting rankings sync: 380 rankings to process','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3706,26,'info','Synced rankings: 100/380 (Created: 1, Updated: 99, Errors: 0)','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3707,26,'info','Synced rankings: 200/380 (Created: 2, Updated: 198, Errors: 0)','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3708,26,'info','Synced rankings: 300/380 (Created: 2, Updated: 298, Errors: 0)','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3709,26,'info','Synced rankings: 380/380 (Created: 2, Updated: 378, Errors: 0)','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3710,26,'info','Rankings sync completed: 2 created, 378 updated, 0 errors','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3711,26,'info','Completed: Syncing Rankings (in 0.97s)','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3712,26,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3713,26,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3714,26,'info','Found 365 unique user/period combinations to process','[]','2026-02-02 09:57:54','2026-02-02 09:57:54'),
(3715,26,'info','Created monthly rankings: 100/365','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3716,26,'info','Created monthly rankings: 200/365','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3717,26,'info','Created monthly rankings: 300/365','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3718,26,'info','Monthly rankings creation completed: 365 created, 0 errors','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3719,26,'info','Completed: Creating Monthly Rankings (in 0.41s)','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3720,26,'info','Starting: Syncing Matches','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3721,26,'info','Starting match sync: 2 matches to process','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3722,26,'info','Synced matches: 2/2 (Created: 0, Comments migrated: 0, Errors: 0)','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3723,26,'info','Marking unofficial matches...','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3724,26,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3725,26,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3726,26,'info','Starting: Scraping Series Standings','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3727,29,'info','Starting scrape','{\"period\":\"2025-12-01\",\"direction\":\"gte\"}','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3728,29,'info','Starting series scrape','[]','2026-02-02 09:57:55','2026-02-02 09:57:55'),
(3729,29,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 09:57:56','2026-02-02 09:57:56'),
(3730,29,'warning','Retry attempt 2/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":300}','2026-02-02 09:58:56','2026-02-02 09:58:56'),
(3731,29,'error','Scrape failed','{\"message\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"trace\":\"#0 \\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/Browsershot.php(757): Spatie\\\\Browsershot\\\\Browsershot->callBrowser()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/SeriesScraper.php(76): Spatie\\\\Browsershot\\\\Browsershot->evaluate()\\n#2 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(91): App\\\\Services\\\\Scraper\\\\SeriesScraper->{closure:App\\\\Services\\\\Scraper\\\\SeriesScraper::execute():75}()\\n#3 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/SeriesScraper.php(75): App\\\\Services\\\\Scraper\\\\BaseScraperService->withRetry()\\n#4 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\SeriesScraper->execute()\\n#5 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#6 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#12 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#15 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#17 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#18 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#19 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#20 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#21 {main}\"}','2026-02-02 10:03:57','2026-02-02 10:03:57'),
(3732,26,'info','Completed: Scraping Series Standings (in 361.86s)','[]','2026-02-02 10:03:57','2026-02-02 10:03:57'),
(3733,26,'info','Starting: Verifying Data Integrity','[]','2026-02-02 10:03:57','2026-02-02 10:03:57'),
(3734,26,'info','Completed: Verifying Data Integrity (in 0.00s)','[]','2026-02-02 10:03:57','2026-02-02 10:03:57'),
(3735,26,'info','Full scrape completed successfully','[]','2026-02-02 10:03:57','2026-02-02 10:03:57'),
(3736,30,'info','Starting: Creating Database Backup','[]','2026-02-02 10:11:07','2026-02-02 10:11:07'),
(3737,30,'info','Completed: Creating Database Backup (in 0.17s)','[]','2026-02-02 10:11:07','2026-02-02 10:11:07'),
(3738,30,'info','Starting: Scraping Rankings & Matches (Male)','[]','2026-02-02 10:11:07','2026-02-02 10:11:07'),
(3739,31,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}','2026-02-02 10:11:07','2026-02-02 10:11:07'),
(3740,31,'info','Starting Python Playwright rankings scraper for 2025-11, gender: m','[]','2026-02-02 10:11:07','2026-02-02 10:11:07'),
(3741,31,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'m\' \'--limit\' \'1\'','[]','2026-02-02 10:11:07','2026-02-02 10:11:07'),
(3742,31,'info','Python: Traceback (most recent call last):','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3743,31,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3744,31,'info','Python: asyncio.run(main())','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3745,31,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3746,31,'info','Python:     return runner.run(main)','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3747,31,'info','Python:            ^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3748,31,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3749,31,'info','Python:     return self._loop.run_until_complete(task)','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3750,31,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3751,31,'info','Python:   File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3752,31,'info','Python:     return future.result()','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3753,31,'info','Python:            ^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3754,31,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3755,31,'info','Python:     result = await scraper.run()','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3756,31,'info','Python:              ^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3757,31,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3758,31,'info','Python:     self.browser = await p.chromium.launch(','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3759,31,'info','Python:                    ^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3760,31,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3761,31,'info','Python:     await self._impl_obj.launch(','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3762,31,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3763,31,'info','Python:     Browser, from_channel(await self._channel.send(\"launch\", params))','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3764,31,'info','Python:                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3765,31,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3766,31,'info','Python:     return await self._connection.wrap_api_call(','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3767,31,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3768,31,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3769,31,'info','Python:     raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3770,31,'info','Python: playwright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3771,31,'info','Python: ╔════════════════════════════════════════════════════════════╗','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3772,31,'info','Python: ║ Looks like Playwright was just installed or updated.       ║','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3773,31,'info','Python: ║ Please run the following command to download new browsers: ║','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3774,31,'info','Python: ║                                                            ║','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3775,31,'info','Python: ║     playwright install                                     ║','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3776,31,'info','Python: ║                                                            ║','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3777,31,'info','Python: ║ <3 Playwright Team                                         ║','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3778,31,'info','Python: ╚════════════════════════════════════════════════════════════╝','[]','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3779,31,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 449, in <module>\\n    asyncio.run(main())\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 190, in run\\n    return runner.run(main)\\n           ^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 118, in run\\n    return self._loop.run_until_complete(task)\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/base_events.py\\\", line 653, in run_until_complete\\n    return future.result()\\n           ^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 442, in main\\n    result = await scraper.run()\\n             ^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 64, in run\\n    self.browser = await p.chromium.launch(\\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/async_api\\/_generated.py\\\", line 14398, in launch\\n    await self._impl_obj.launch(\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_browser_type.py\\\", line 95, in launch\\n    Browser, from_channel(await self._channel.send(\\\"launch\\\", params))\\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 59, in send\\n    return await self._connection.wrap_api_call(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 520, in wrap_api_call\\n    raise rewrite_error(error, f\\\"{parsed_st[\'apiName\']}: {error}\\\") from None\\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at \\/home\\/webook\\/.cache\\/ms-playwright\\/chromium-1140\\/chrome-linux\\/chrome\\n\\u2554\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2557\\n\\u2551 Looks like Playwright was just installed or updated.       \\u2551\\n\\u2551 Please run the following command to download new browsers: \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551     playwright install                                     \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551 <3 Playwright Team                                         \\u2551\\n\\u255a\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u255d\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 10:11:08','2026-02-02 10:11:08'),
(3780,30,'info','Completed: Scraping Rankings & Matches (Male) (in 2.01s)','[]','2026-02-02 10:11:09','2026-02-02 10:11:09'),
(3781,30,'info','Starting: Scraping Rankings & Matches (Female)','[]','2026-02-02 10:11:09','2026-02-02 10:11:09'),
(3782,32,'info','Starting scrape','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}','2026-02-02 10:11:09','2026-02-02 10:11:09'),
(3783,32,'info','Starting Python Playwright rankings scraper for 2025-11, gender: k','[]','2026-02-02 10:11:09','2026-02-02 10:11:09'),
(3784,32,'info','Executing Python script: \'/var/www/html/scripts/scraper/venv/bin/python3\' \'/var/www/html/scripts/scraper/rankings_popup_scraper.py\' \'--year\' \'2025\' \'--month\' \'11\' \'--gender\' \'k\' \'--limit\' \'1\'','[]','2026-02-02 10:11:09','2026-02-02 10:11:09'),
(3785,32,'info','Python: Traceback (most recent call last):','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3786,32,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3787,32,'info','Python: asyncio.run(main())','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3788,32,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3789,32,'info','Python:     return runner.run(main)','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3790,32,'info','Python:            ^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3791,32,'info','Python:   File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3792,32,'info','Python:     return self._loop.run_until_complete(task)','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3793,32,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3794,32,'info','Python:   File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3795,32,'info','Python:     return future.result()','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3796,32,'info','Python:            ^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3797,32,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3798,32,'info','Python:     result = await scraper.run()','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3799,32,'info','Python:              ^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3800,32,'info','Python:   File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3801,32,'info','Python:     self.browser = await p.chromium.launch(','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3802,32,'info','Python:                    ^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3803,32,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3804,32,'info','Python:     await self._impl_obj.launch(','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3805,32,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3806,32,'info','Python:     Browser, from_channel(await self._channel.send(\"launch\", params))','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3807,32,'info','Python:                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3808,32,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3809,32,'info','Python:     return await self._connection.wrap_api_call(','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3810,32,'info','Python:            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3811,32,'info','Python:   File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3812,32,'info','Python:     raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3813,32,'info','Python: playwright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3814,32,'info','Python: ╔════════════════════════════════════════════════════════════╗','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3815,32,'info','Python: ║ Looks like Playwright was just installed or updated.       ║','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3816,32,'info','Python: ║ Please run the following command to download new browsers: ║','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3817,32,'info','Python: ║                                                            ║','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3818,32,'info','Python: ║     playwright install                                     ║','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3819,32,'info','Python: ║                                                            ║','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3820,32,'info','Python: ║ <3 Playwright Team                                         ║','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3821,32,'info','Python: ╚════════════════════════════════════════════════════════════╝','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3822,32,'error','Scrape failed','{\"message\":\"Python scraper process failed:\\nExit Code: 1\\nError Output: Traceback (most recent call last):\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 449, in <module>\\n    asyncio.run(main())\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 190, in run\\n    return runner.run(main)\\n           ^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/runners.py\\\", line 118, in run\\n    return self._loop.run_until_complete(task)\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/usr\\/lib\\/python3.11\\/asyncio\\/base_events.py\\\", line 653, in run_until_complete\\n    return future.result()\\n           ^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 442, in main\\n    result = await scraper.run()\\n             ^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/rankings_popup_scraper.py\\\", line 64, in run\\n    self.browser = await p.chromium.launch(\\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/async_api\\/_generated.py\\\", line 14398, in launch\\n    await self._impl_obj.launch(\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_browser_type.py\\\", line 95, in launch\\n    Browser, from_channel(await self._channel.send(\\\"launch\\\", params))\\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 59, in send\\n    return await self._connection.wrap_api_call(\\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\\n  File \\\"\\/var\\/www\\/html\\/scripts\\/scraper\\/venv\\/lib\\/python3.11\\/site-packages\\/playwright\\/_impl\\/_connection.py\\\", line 520, in wrap_api_call\\n    raise rewrite_error(error, f\\\"{parsed_st[\'apiName\']}: {error}\\\") from None\\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at \\/home\\/webook\\/.cache\\/ms-playwright\\/chromium-1140\\/chrome-linux\\/chrome\\n\\u2554\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2557\\n\\u2551 Looks like Playwright was just installed or updated.       \\u2551\\n\\u2551 Please run the following command to download new browsers: \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551     playwright install                                     \\u2551\\n\\u2551                                                            \\u2551\\n\\u2551 <3 Playwright Team                                         \\u2551\\n\\u255a\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u2550\\u255d\\n\\nStandard Output: \",\"trace\":\"#0 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/RankingsScraper.php(36): App\\\\Services\\\\Scraper\\\\RankingsScraper->executePythonScraper()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\RankingsScraper->execute()\\n#2 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#3 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#4 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#5 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#6 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#10 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#12 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#14 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#15 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#17 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#18 {main}\"}','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3823,30,'info','Completed: Scraping Rankings & Matches (Female) (in 1.00s)','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3824,30,'info','Starting: Syncing Rankings','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3825,30,'info','Starting rankings sync: 0 rankings to process','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3826,30,'info','Rankings sync completed: 0 created, 0 updated, 0 errors','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3827,30,'info','Completed: Syncing Rankings (in 0.04s)','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3828,30,'info','Starting: Creating Monthly Rankings','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3829,30,'info','Starting monthly rankings creation from scraped data','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3830,30,'info','Found 365 unique user/period combinations to process','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3831,30,'info','Created monthly rankings: 100/365','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3832,30,'info','Created monthly rankings: 200/365','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3833,30,'info','Created monthly rankings: 300/365','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3834,30,'info','Monthly rankings creation completed: 365 created, 0 errors','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3835,30,'info','Completed: Creating Monthly Rankings (in 0.28s)','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3836,30,'info','Starting: Syncing Matches','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3837,30,'info','Starting match sync: 0 matches to process','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3838,30,'info','Marking unofficial matches...','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3839,30,'info','Match sync completed: 0 created, 0 comments migrated, 0 marked unofficial','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3840,30,'info','Completed: Syncing Matches (in 0.01s)','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3841,30,'info','Starting: Scraping Series Standings','[]','2026-02-02 10:11:10','2026-02-02 10:11:10'),
(3842,33,'info','Starting scrape','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}','2026-02-02 10:11:11','2026-02-02 10:11:11'),
(3843,33,'info','Starting series scrape','[]','2026-02-02 10:11:11','2026-02-02 10:11:11'),
(3844,33,'warning','Retry attempt 1/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":60}','2026-02-02 10:11:11','2026-02-02 10:11:11'),
(3845,33,'warning','Retry attempt 2/3','{\"context\":\"Fetch series page\",\"error\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"delay_seconds\":300}','2026-02-02 10:12:11','2026-02-02 10:12:11'),
(3846,33,'error','Scrape failed','{\"message\":\"The command \\\"PATH=$PATH:\\/usr\\/local\\/bin:\\/opt\\/homebrew\\/bin NODE_PATH=$(\\\"\\/usr\\/local\\/bin\\/node\\\" \\\"\\/usr\\/local\\/bin\\/npm\\\" root -g) \\\"\\/usr\\/local\\/bin\\/node\\\" \'\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/..\\/bin\\/browser.cjs\' \'{\\\"url\\\":\\\"https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/login.php?login_public=SBTF.SE.BT\\\",\\\"action\\\":\\\"evaluate\\\",\\\"options\\\":{\\\"pageFunction\\\":\\\"(async function() {\\\\n    try {\\\\n        const response = await fetch(\'\\\\\'\'https:\\\\\\/\\\\\\/www.profixio.com\\\\\\/fx\\\\\\/serieoppsett.php\'\\\\\'\', {\\\\n            credentials: \'\\\\\'\'include\'\\\\\'\'\\\\n        });\\\\n        const html = await response.text();\\\\n\\\\n        const parser = new DOMParser();\\\\n        const doc = parser.parseFromString(html, \'\\\\\'\'text\\\\\\/html\'\\\\\'\');\\\\n\\\\n        \\\\\\/\\\\\\/ Get seasons from the page - look for links containing \\\\\\\"S\\\\u00e4songen\\\\\\\"\\\\n        const allLinks = doc.querySelectorAll(\'\\\\\'\'.maincontent a\'\\\\\'\');\\\\n        let seasons = [];\\\\n        allLinks.forEach(item => {\\\\n            const text = item.innerText.trim();\\\\n            const href = item.getAttribute(\'\\\\\'\'href\'\\\\\'\') || \'\\\\\'\'\'\\\\\'\';\\\\n            if (text.includes(\'\\\\\'\'S\\\\u00e4songen\'\\\\\'\') && href.includes(\'\\\\\'\'serieoppsett_sesong\'\\\\\'\')) {\\\\n                seasons.push({\\\\n                    label: text.replace(\'\\\\\'\'*\'\\\\\'\', \'\\\\\'\'\'\\\\\'\').trim(),\\\\n                    link: href\\\\n                });\\\\n            }\\\\n        });\\\\n\\\\n        return JSON.stringify({\\\\n            seasons: seasons,\\\\n            pageTitle: doc.title\\\\n        });\\\\n    } catch (e) {\\\\n        return JSON.stringify({ error: e.message });\\\\n    }\\\\n})();\\\",\\\"args\\\":[\\\"----disable-web-security\\\",\\\"----disable-features=IsolateOrigins,site-per-process\\\",\\\"--no-sandbox\\\"],\\\"viewport\\\":{\\\"width\\\":800,\\\"height\\\":600},\\\"timeout\\\":60000000,\\\"waitUntil\\\":\\\"networkidle0\\\",\\\"executablePath\\\":\\\"\\\\\\/usr\\\\\\/bin\\\\\\/chromium\\\"}}\'\\\" failed.\\n\\nExit Code: 1(General error)\\n\\nWorking directory: \\/var\\/www\\/html\\n\\nOutput:\\n================\\n\\n\\nError Output:\\n================\\nError: Browser was not found at the configured executablePath (\\/usr\\/bin\\/chromium)\\n    at ChromeLauncher.launch (\\/var\\/www\\/html\\/node_modules\\/puppeteer-core\\/lib\\/cjs\\/puppeteer\\/node\\/BrowserLauncher.js:90:19)\\n    at async callChrome (\\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/bin\\/browser.cjs:102:23)\\n\",\"trace\":\"#0 \\/var\\/www\\/html\\/vendor\\/spatie\\/browsershot\\/src\\/Browsershot.php(757): Spatie\\\\Browsershot\\\\Browsershot->callBrowser()\\n#1 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/SeriesScraper.php(76): Spatie\\\\Browsershot\\\\Browsershot->evaluate()\\n#2 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(91): App\\\\Services\\\\Scraper\\\\SeriesScraper->{closure:App\\\\Services\\\\Scraper\\\\SeriesScraper::execute():75}()\\n#3 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/SeriesScraper.php(75): App\\\\Services\\\\Scraper\\\\BaseScraperService->withRetry()\\n#4 \\/var\\/www\\/html\\/app\\/Services\\/Scraper\\/BaseScraperService.php(47): App\\\\Services\\\\Scraper\\\\SeriesScraper->execute()\\n#5 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(219): App\\\\Services\\\\Scraper\\\\BaseScraperService->scrape()\\n#6 \\/var\\/www\\/html\\/app\\/Console\\/Commands\\/ScraperCommand.php(149): App\\\\Console\\\\Commands\\\\ScraperCommand->runSynchronously()\\n#7 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(36): App\\\\Console\\\\Commands\\\\ScraperCommand->handle()\\n#8 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php(43): Illuminate\\\\Container\\\\BoundMethod::{closure:Illuminate\\\\Container\\\\BoundMethod::call():35}()\\n#9 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(96): Illuminate\\\\Container\\\\Util::unwrapIfClosure()\\n#10 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php(35): Illuminate\\\\Container\\\\BoundMethod::callBoundMethod()\\n#11 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php(836): Illuminate\\\\Container\\\\BoundMethod::call()\\n#12 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(211): Illuminate\\\\Container\\\\Container->call()\\n#13 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php(318): Illuminate\\\\Console\\\\Command->execute()\\n#14 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php(180): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\\n#15 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(1073): Illuminate\\\\Console\\\\Command->run()\\n#16 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(356): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\\n#17 \\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php(195): Symfony\\\\Component\\\\Console\\\\Application->doRun()\\n#18 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php(197): Symfony\\\\Component\\\\Console\\\\Application->run()\\n#19 \\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Application.php(1235): Illuminate\\\\Foundation\\\\Console\\\\Kernel->handle()\\n#20 \\/var\\/www\\/html\\/artisan(16): Illuminate\\\\Foundation\\\\Application->handleCommand()\\n#21 {main}\"}','2026-02-02 10:17:12','2026-02-02 10:17:12'),
(3847,30,'info','Completed: Scraping Series Standings (in 361.90s)','[]','2026-02-02 10:17:12','2026-02-02 10:17:12'),
(3848,30,'info','Starting: Verifying Data Integrity','[]','2026-02-02 10:17:12','2026-02-02 10:17:12'),
(3849,30,'info','Completed: Verifying Data Integrity (in 0.00s)','[]','2026-02-02 10:17:12','2026-02-02 10:17:12'),
(3850,30,'info','Full scrape completed successfully','[]','2026-02-02 10:17:12','2026-02-02 10:17:12'),
(3851,34,'info','Starting: Creating Database Backup','[]','2026-02-02 10:17:19','2026-02-02 10:17:19');
/*!40000 ALTER TABLE `scraper_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_runs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_runs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `current_step` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `parameters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`parameters`)),
  `steps_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`steps_data`)),
  `items_scraped` int(11) NOT NULL DEFAULT 0,
  `items_failed` int(11) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `scraper_runs_type_status_index` (`type`,`status`),
  KEY `scraper_runs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_runs` WRITE;
/*!40000 ALTER TABLE `scraper_runs` DISABLE KEYS */;
INSERT INTO `scraper_runs` VALUES
(10,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.1393117904663086,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-42-58.zip\"},\"completed_at\":\"2026-02-02 10:42:58\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":1.0078339576721191,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:42:59\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":1.0035429000854492,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:43:00\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.031646013259887695,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:43:01\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.004102945327758789,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:43:01\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.01198720932006836,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:43:01\"}}',0,0,NULL,'2026-02-02 09:42:58',NULL,'2026-02-02 09:42:58','2026-02-02 09:43:01'),
(11,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:42:59','2026-02-02 09:42:59','2026-02-02 09:42:59','2026-02-02 09:42:59'),
(12,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:43:00','2026-02-02 09:43:00','2026-02-02 09:43:00','2026-02-02 09:43:00'),
(13,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:43:01',NULL,'2026-02-02 09:43:01','2026-02-02 09:43:01'),
(14,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.142409086227417,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-47-44.zip\"},\"completed_at\":\"2026-02-02 10:47:44\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":1.0111920833587646,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:47:45\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":1.0043950080871582,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:47:46\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.03190207481384277,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:47:46\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.00392603874206543,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:47:46\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.01106405258178711,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:47:46\"}}',0,0,NULL,'2026-02-02 09:47:44',NULL,'2026-02-02 09:47:44','2026-02-02 09:47:46'),
(15,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:47:44','2026-02-02 09:47:44','2026-02-02 09:47:44','2026-02-02 09:47:44'),
(16,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 32, in <module>\n    from playwright.async_api import async_playwright, Page, Browser, BrowserContext\nModuleNotFoundError: No module named \'playwright\'\n\nStandard Output: ','2026-02-02 09:47:45','2026-02-02 09:47:45','2026-02-02 09:47:45','2026-02-02 09:47:45'),
(17,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:47:46',NULL,'2026-02-02 09:47:46','2026-02-02 09:47:46'),
(18,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.15445494651794434,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-52-41.zip\"},\"completed_at\":\"2026-02-02 10:52:41\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":2.0106899738311768,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:52:43\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":2.007002115249634,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:52:45\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.03700900077819824,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:52:45\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.008775949478149414,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:52:45\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.010875940322875977,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:52:45\"}}',0,0,NULL,'2026-02-02 09:52:41',NULL,'2026-02-02 09:52:41','2026-02-02 09:52:45'),
(19,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>\n    asyncio.run(main())\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run\n    return runner.run(main)\n           ^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run\n    return self._loop.run_until_complete(task)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete\n    return future.result()\n           ^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main\n    result = await scraper.run()\n             ^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run\n    self.browser = await p.chromium.launch(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch\n    await self._impl_obj.launch(\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch\n    Browser, from_channel(await self._channel.send(\"launch\", params))\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send\n    return await self._connection.wrap_api_call(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call\n    raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome\n╔════════════════════════════════════════════════════════════╗\n║ Looks like Playwright was just installed or updated.       ║\n║ Please run the following command to download new browsers: ║\n║                                                            ║\n║     playwright install                                     ║\n║                                                            ║\n║ <3 Playwright Team                                         ║\n╚════════════════════════════════════════════════════════════╝\n\nStandard Output: ','2026-02-02 09:52:42','2026-02-02 09:52:42','2026-02-02 09:52:42','2026-02-02 09:52:42'),
(20,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>\n    asyncio.run(main())\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run\n    return runner.run(main)\n           ^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run\n    return self._loop.run_until_complete(task)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete\n    return future.result()\n           ^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main\n    result = await scraper.run()\n             ^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run\n    self.browser = await p.chromium.launch(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch\n    await self._impl_obj.launch(\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch\n    Browser, from_channel(await self._channel.send(\"launch\", params))\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send\n    return await self._connection.wrap_api_call(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call\n    raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome\n╔════════════════════════════════════════════════════════════╗\n║ Looks like Playwright was just installed or updated.       ║\n║ Please run the following command to download new browsers: ║\n║                                                            ║\n║     playwright install                                     ║\n║                                                            ║\n║ <3 Playwright Team                                         ║\n╚════════════════════════════════════════════════════════════╝\n\nStandard Output: ','2026-02-02 09:52:44','2026-02-02 09:52:44','2026-02-02 09:52:44','2026-02-02 09:52:44'),
(21,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:52:46',NULL,'2026-02-02 09:52:46','2026-02-02 09:52:46'),
(22,'full_scrape','Step 7/7: Scraping Series Standings','failed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.1693129539489746,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-53-54.zip\"},\"completed_at\":\"2026-02-02 10:53:54\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":6.0218141078948975,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:54:00\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":5.017053127288818,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 10:54:05\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.03749394416809082,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:54:05\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.004302978515625,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:54:05\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.008448123931884766,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:54:05\"}}',0,0,NULL,'2026-02-02 09:53:54',NULL,'2026-02-02 09:53:54','2026-02-02 09:54:05'),
(23,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":111}',NULL,0,0,'Python scraper failed: [{\"error\":\"Month 2025.11.01 not found in dropdown\"}]','2026-02-02 09:53:54','2026-02-02 09:53:59','2026-02-02 09:53:54','2026-02-02 09:53:59'),
(24,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":111}',NULL,0,0,'Python scraper failed: [{\"error\":\"Month 2025.11.01 not found in dropdown\"}]','2026-02-02 09:54:00','2026-02-02 09:54:05','2026-02-02 09:54:00','2026-02-02 09:54:05'),
(25,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,0,NULL,'2026-02-02 09:54:06',NULL,'2026-02-02 09:54:06','2026-02-02 09:54:06'),
(26,'full_scrape','Step 8/7: Verifying Data Integrity','completed','{\"month\":\"2025-12\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.13652420043945312,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-10-56-47.zip\"},\"completed_at\":\"2026-02-02 10:56:47\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":33.085087060928345,\"success\":true,\"details\":{\"Items Scraped\":186},\"completed_at\":\"2026-02-02 10:57:20\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":33.07852506637573,\"success\":true,\"details\":{\"Items Scraped\":196},\"completed_at\":\"2026-02-02 10:57:53\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.9729199409484863,\"success\":true,\"details\":{\"Created\":2,\"Updated\":378,\"Errors\":0},\"completed_at\":\"2026-02-02 10:57:54\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.4050428867340088,\"success\":true,\"details\":{\"Created\":365,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:57:55\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.011739015579223633,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 10:57:55\"},\"step_7\":{\"description\":\"Scraping Series Standings\",\"duration\":361.8589630126953,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 11:03:57\"},\"step_8\":{\"description\":\"Verifying Data Integrity\",\"duration\":0.004945993423461914,\"success\":true,\"details\":[],\"completed_at\":\"2026-02-02 11:03:57\"}}',0,0,NULL,'2026-02-02 09:56:47','2026-02-02 10:03:57','2026-02-02 09:56:47','2026-02-02 10:03:57'),
(27,'rankings',NULL,'completed','{\"year\":\"2025\",\"month\":\"12\",\"gender\":\"m\",\"limit_players\":1}',NULL,186,0,NULL,'2026-02-02 09:56:48','2026-02-02 09:57:20','2026-02-02 09:56:48','2026-02-02 09:57:20'),
(28,'rankings',NULL,'completed','{\"year\":\"2025\",\"month\":\"12\",\"gender\":\"k\",\"limit_players\":1}',NULL,196,0,NULL,'2026-02-02 09:57:21','2026-02-02 09:57:53','2026-02-02 09:57:21','2026-02-02 09:57:53'),
(29,'series',NULL,'failed','{\"period\":\"2025-12-01\",\"direction\":\"gte\"}',NULL,0,1,'The command \"PATH=$PATH:/usr/local/bin:/opt/homebrew/bin NODE_PATH=$(\"/usr/local/bin/node\" \"/usr/local/bin/npm\" root -g) \"/usr/local/bin/node\" \'/var/www/html/vendor/spatie/browsershot/src/../bin/browser.cjs\' \'{\"url\":\"https:\\/\\/www.profixio.com\\/fx\\/login.php?login_public=SBTF.SE.BT\",\"action\":\"evaluate\",\"options\":{\"pageFunction\":\"(async function() {\\n    try {\\n        const response = await fetch(\'\\\'\'https:\\/\\/www.profixio.com\\/fx\\/serieoppsett.php\'\\\'\', {\\n            credentials: \'\\\'\'include\'\\\'\'\\n        });\\n        const html = await response.text();\\n\\n        const parser = new DOMParser();\\n        const doc = parser.parseFromString(html, \'\\\'\'text\\/html\'\\\'\');\\n\\n        \\/\\/ Get seasons from the page - look for links containing \\\"S\\u00e4songen\\\"\\n        const allLinks = doc.querySelectorAll(\'\\\'\'.maincontent a\'\\\'\');\\n        let seasons = [];\\n        allLinks.forEach(item => {\\n            const text = item.innerText.trim();\\n            const href = item.getAttribute(\'\\\'\'href\'\\\'\') || \'\\\'\'\'\\\'\';\\n            if (text.includes(\'\\\'\'S\\u00e4songen\'\\\'\') && href.includes(\'\\\'\'serieoppsett_sesong\'\\\'\')) {\\n                seasons.push({\\n                    label: text.replace(\'\\\'\'*\'\\\'\', \'\\\'\'\'\\\'\').trim(),\\n                    link: href\\n                });\\n            }\\n        });\\n\\n        return JSON.stringify({\\n            seasons: seasons,\\n            pageTitle: doc.title\\n        });\\n    } catch (e) {\\n        return JSON.stringify({ error: e.message });\\n    }\\n})();\",\"args\":[\"----disable-web-security\",\"----disable-features=IsolateOrigins,site-per-process\",\"--no-sandbox\"],\"viewport\":{\"width\":800,\"height\":600},\"timeout\":60000000,\"waitUntil\":\"networkidle0\",\"executablePath\":\"\\/usr\\/bin\\/chromium\"}}\'\" failed.\n\nExit Code: 1(General error)\n\nWorking directory: /var/www/html\n\nOutput:\n================\n\n\nError Output:\n================\nError: Browser was not found at the configured executablePath (/usr/bin/chromium)\n    at ChromeLauncher.launch (/var/www/html/node_modules/puppeteer-core/lib/cjs/puppeteer/node/BrowserLauncher.js:90:19)\n    at async callChrome (/var/www/html/vendor/spatie/browsershot/bin/browser.cjs:102:23)\n','2026-02-02 09:57:55','2026-02-02 10:03:57','2026-02-02 09:57:55','2026-02-02 10:03:57'),
(30,'full_scrape','Step 8/7: Verifying Data Integrity','completed','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}','{\"step_1\":{\"description\":\"Creating Database Backup\",\"duration\":0.17488312721252441,\"success\":true,\"details\":{\"Backup File\":\"\\/var\\/www\\/html\\/storage\\/app\\/private\\/iRacket\\/2026-02-02-11-11-07.zip\"},\"completed_at\":\"2026-02-02 11:11:07\"},\"step_2\":{\"description\":\"Scraping Rankings & Matches (Male)\",\"duration\":2.0134479999542236,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 11:11:09\"},\"step_3\":{\"description\":\"Scraping Rankings & Matches (Female)\",\"duration\":1.0039238929748535,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 11:11:10\"},\"step_4\":{\"description\":\"Syncing Rankings\",\"duration\":0.037776947021484375,\"success\":true,\"details\":{\"Created\":0,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 11:11:10\"},\"step_5\":{\"description\":\"Creating Monthly Rankings\",\"duration\":0.2849240303039551,\"success\":true,\"details\":{\"Created\":365,\"Updated\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 11:11:10\"},\"step_6\":{\"description\":\"Syncing Matches\",\"duration\":0.0075838565826416016,\"success\":true,\"details\":{\"Created\":0,\"Errors\":0},\"completed_at\":\"2026-02-02 11:11:10\"},\"step_7\":{\"description\":\"Scraping Series Standings\",\"duration\":361.89556097984314,\"success\":true,\"details\":{\"Items Scraped\":0},\"completed_at\":\"2026-02-02 11:17:12\"},\"step_8\":{\"description\":\"Verifying Data Integrity\",\"duration\":0.00413203239440918,\"success\":true,\"details\":[],\"completed_at\":\"2026-02-02 11:17:12\"}}',0,0,NULL,'2026-02-02 10:11:07','2026-02-02 10:17:12','2026-02-02 10:11:07','2026-02-02 10:17:12'),
(31,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"m\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>\n    asyncio.run(main())\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run\n    return runner.run(main)\n           ^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run\n    return self._loop.run_until_complete(task)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete\n    return future.result()\n           ^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main\n    result = await scraper.run()\n             ^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run\n    self.browser = await p.chromium.launch(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch\n    await self._impl_obj.launch(\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch\n    Browser, from_channel(await self._channel.send(\"launch\", params))\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send\n    return await self._connection.wrap_api_call(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call\n    raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome\n╔════════════════════════════════════════════════════════════╗\n║ Looks like Playwright was just installed or updated.       ║\n║ Please run the following command to download new browsers: ║\n║                                                            ║\n║     playwright install                                     ║\n║                                                            ║\n║ <3 Playwright Team                                         ║\n╚════════════════════════════════════════════════════════════╝\n\nStandard Output: ','2026-02-02 10:11:07','2026-02-02 10:11:08','2026-02-02 10:11:07','2026-02-02 10:11:08'),
(32,'rankings',NULL,'failed','{\"year\":\"2025\",\"month\":\"11\",\"gender\":\"k\",\"limit_players\":1}',NULL,0,0,'Python scraper process failed:\nExit Code: 1\nError Output: Traceback (most recent call last):\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 449, in <module>\n    asyncio.run(main())\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 190, in run\n    return runner.run(main)\n           ^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/runners.py\", line 118, in run\n    return self._loop.run_until_complete(task)\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/usr/lib/python3.11/asyncio/base_events.py\", line 653, in run_until_complete\n    return future.result()\n           ^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 442, in main\n    result = await scraper.run()\n             ^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/rankings_popup_scraper.py\", line 64, in run\n    self.browser = await p.chromium.launch(\n                   ^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/async_api/_generated.py\", line 14398, in launch\n    await self._impl_obj.launch(\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_browser_type.py\", line 95, in launch\n    Browser, from_channel(await self._channel.send(\"launch\", params))\n                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 59, in send\n    return await self._connection.wrap_api_call(\n           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^\n  File \"/var/www/html/scripts/scraper/venv/lib/python3.11/site-packages/playwright/_impl/_connection.py\", line 520, in wrap_api_call\n    raise rewrite_error(error, f\"{parsed_st[\'apiName\']}: {error}\") from None\nplaywright._impl._errors.Error: BrowserType.launch: Executable doesn\'t exist at /home/webook/.cache/ms-playwright/chromium-1140/chrome-linux/chrome\n╔════════════════════════════════════════════════════════════╗\n║ Looks like Playwright was just installed or updated.       ║\n║ Please run the following command to download new browsers: ║\n║                                                            ║\n║     playwright install                                     ║\n║                                                            ║\n║ <3 Playwright Team                                         ║\n╚════════════════════════════════════════════════════════════╝\n\nStandard Output: ','2026-02-02 10:11:09','2026-02-02 10:11:10','2026-02-02 10:11:09','2026-02-02 10:11:10'),
(33,'series',NULL,'failed','{\"period\":\"2025-11-01\",\"direction\":\"gte\"}',NULL,0,1,'The command \"PATH=$PATH:/usr/local/bin:/opt/homebrew/bin NODE_PATH=$(\"/usr/local/bin/node\" \"/usr/local/bin/npm\" root -g) \"/usr/local/bin/node\" \'/var/www/html/vendor/spatie/browsershot/src/../bin/browser.cjs\' \'{\"url\":\"https:\\/\\/www.profixio.com\\/fx\\/login.php?login_public=SBTF.SE.BT\",\"action\":\"evaluate\",\"options\":{\"pageFunction\":\"(async function() {\\n    try {\\n        const response = await fetch(\'\\\'\'https:\\/\\/www.profixio.com\\/fx\\/serieoppsett.php\'\\\'\', {\\n            credentials: \'\\\'\'include\'\\\'\'\\n        });\\n        const html = await response.text();\\n\\n        const parser = new DOMParser();\\n        const doc = parser.parseFromString(html, \'\\\'\'text\\/html\'\\\'\');\\n\\n        \\/\\/ Get seasons from the page - look for links containing \\\"S\\u00e4songen\\\"\\n        const allLinks = doc.querySelectorAll(\'\\\'\'.maincontent a\'\\\'\');\\n        let seasons = [];\\n        allLinks.forEach(item => {\\n            const text = item.innerText.trim();\\n            const href = item.getAttribute(\'\\\'\'href\'\\\'\') || \'\\\'\'\'\\\'\';\\n            if (text.includes(\'\\\'\'S\\u00e4songen\'\\\'\') && href.includes(\'\\\'\'serieoppsett_sesong\'\\\'\')) {\\n                seasons.push({\\n                    label: text.replace(\'\\\'\'*\'\\\'\', \'\\\'\'\'\\\'\').trim(),\\n                    link: href\\n                });\\n            }\\n        });\\n\\n        return JSON.stringify({\\n            seasons: seasons,\\n            pageTitle: doc.title\\n        });\\n    } catch (e) {\\n        return JSON.stringify({ error: e.message });\\n    }\\n})();\",\"args\":[\"----disable-web-security\",\"----disable-features=IsolateOrigins,site-per-process\",\"--no-sandbox\"],\"viewport\":{\"width\":800,\"height\":600},\"timeout\":60000000,\"waitUntil\":\"networkidle0\",\"executablePath\":\"\\/usr\\/bin\\/chromium\"}}\'\" failed.\n\nExit Code: 1(General error)\n\nWorking directory: /var/www/html\n\nOutput:\n================\n\n\nError Output:\n================\nError: Browser was not found at the configured executablePath (/usr/bin/chromium)\n    at ChromeLauncher.launch (/var/www/html/node_modules/puppeteer-core/lib/cjs/puppeteer/node/BrowserLauncher.js:90:19)\n    at async callChrome (/var/www/html/vendor/spatie/browsershot/bin/browser.cjs:102:23)\n','2026-02-02 10:11:11','2026-02-02 10:17:12','2026-02-02 10:11:11','2026-02-02 10:17:12'),
(34,'full_scrape','Step 1/7: Creating Database Backup','running','{\"month\":\"2025-11\",\"all\":false,\"no_backup\":false}',NULL,0,0,NULL,'2026-02-02 10:17:19',NULL,'2026-02-02 10:17:19','2026-02-02 10:17:19');
/*!40000 ALTER TABLE `scraper_runs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `scraper_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `scraper_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` text DEFAULT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'string',
  `group` varchar(255) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `scraper_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `scraper_settings` WRITE;
/*!40000 ALTER TABLE `scraper_settings` DISABLE KEYS */;
INSERT INTO `scraper_settings` VALUES
(1,'url_rankings','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for rankings scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(2,'url_players','https://www.profixio.com/fx/lisens/public_oversikt.php','string','urls','URL for players list scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(3,'url_transitions','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for transitions scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(4,'url_series','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for series scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(5,'url_live_center','https://www.profixio.com/fx/ranking_sbtf/ranking_sbtf_list.php','string','urls','URL for live center scraper','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(6,'schedule_players_enabled','1','boolean','schedule','Enable automatic players scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(7,'schedule_players_frequency','monthly','string','schedule','Players scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(8,'schedule_players_day','1','string','schedule','Day to run players scrape (1-31 for monthly, sunday-saturday for weekly)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(9,'schedule_players_time','03:00','string','schedule','Time to run players scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(10,'schedule_rankings_enabled','1','boolean','schedule','Enable automatic rankings scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(11,'schedule_rankings_frequency','weekly','string','schedule','Rankings scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(12,'schedule_rankings_day','sunday','string','schedule','Day to run rankings scrape','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(13,'schedule_rankings_time','02:00','string','schedule','Time to run rankings scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(14,'schedule_transitions_enabled','0','boolean','schedule','Enable automatic transitions scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(15,'schedule_transitions_frequency','weekly','string','schedule','Transitions scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(16,'schedule_transitions_day','monday','string','schedule','Day to run transitions scrape','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(17,'schedule_transitions_time','03:30','string','schedule','Time to run transitions scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(18,'schedule_series_enabled','0','boolean','schedule','Enable automatic series scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(19,'schedule_series_frequency','weekly','string','schedule','Series scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(20,'schedule_series_day','monday','string','schedule','Day to run series scrape','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(21,'schedule_series_time','04:00','string','schedule','Time to run series scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(22,'schedule_live_center_enabled','0','boolean','schedule','Enable automatic live center scraping','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(23,'schedule_live_center_frequency','daily','string','schedule','Live center scraping frequency','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(24,'schedule_live_center_day','','string','schedule','Day to run live center scrape (not used for daily)','2026-01-29 15:24:42','2026-01-29 15:24:42'),
(25,'schedule_live_center_time','05:00','string','schedule','Time to run live center scrape (HH:MM)','2026-01-29 15:24:42','2026-01-29 15:24:42');
/*!40000 ALTER TABLE `scraper_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`title`)),
  `slug` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`content`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `terms_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `terms` WRITE;
/*!40000 ALTER TABLE `terms` DISABLE KEYS */;
/*!40000 ALTER TABLE `terms` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_monitors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_monitors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `monitored_user_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_monitors_user_id_monitored_user_id_unique` (`user_id`,`monitored_user_id`),
  KEY `user_monitors_monitored_user_id_foreign` (`monitored_user_id`),
  CONSTRAINT `user_monitors_monitored_user_id_foreign` FOREIGN KEY (`monitored_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_monitors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_monitors` WRITE;
/*!40000 ALTER TABLE `user_monitors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_monitors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` uuid NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_fullname` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `age` tinyint(3) unsigned DEFAULT NULL,
  `birth_year` int(11) DEFAULT NULL,
  `club_id` bigint(20) unsigned DEFAULT NULL,
  `visible_in_players` tinyint(1) NOT NULL DEFAULT 1,
  `google_id` varchar(255) DEFAULT NULL,
  `apple_id` varchar(255) DEFAULT NULL,
  `sbtf_player_id` varchar(255) DEFAULT NULL,
  `sbtf_synced` tinyint(1) NOT NULL DEFAULT 0,
  `sbtf_synced_at` timestamp NULL DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `is_connected` tinyint(1) NOT NULL DEFAULT 0,
  `is_active_player` tinyint(1) NOT NULL DEFAULT 1,
  `accepts_push_notifications` tinyint(1) NOT NULL DEFAULT 0,
  `verification_code` varchar(6) DEFAULT NULL,
  `verification_code_expires_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `fcm_token` varchar(255) DEFAULT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `fcm_token_updated_at` timestamp NULL DEFAULT NULL,
  `terms_accepted` tinyint(1) NOT NULL DEFAULT 0,
  `terms_accepted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_uuid_unique` (`uuid`),
  KEY `users_club_id_foreign` (`club_id`),
  KEY `users_player_match_index` (`last_name`,`first_name`,`birth_year`),
  KEY `users_sbtf_player_id_index` (`sbtf_player_id`),
  CONSTRAINT `users_club_id_foreign` FOREIGN KEY (`club_id`) REFERENCES `clubs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(999,'b0975171-01a8-40d8-8ca6-4220270960ab','Damjan','damjan','Damjan damjan',NULL,'damjan@weboook.co.uk',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,'2026-01-30 08:42:38',1,0,0,NULL,NULL,'$2y$12$PTOPxcTlMoB9OD2fpZqX8e5CpjP3hjvKZU00ePNU8K1o38Z7og1BC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-01-30 08:42:19','2026-01-30 08:42:19','2026-01-30 08:42:39'),
(1000,'af6e033d-7740-48c1-acbf-a3e502cbd86a','Truls','Möregårdh',NULL,NULL,'trulsmoregardh@iracket.local',NULL,'male',NULL,2002,187,1,NULL,NULL,NULL,1,'2026-02-02 09:57:54',NULL,0,1,0,NULL,NULL,'$2y$12$xnkir/Mss9D9q5Sz5XE9Be43Bd5BIdsTs2HfYVqMF4F4v4G8kze8a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-02-02 09:57:54','2026-02-02 09:57:54'),
(1001,'c55de404-7908-4bf8-b1ca-ab7b68374b7c','Linda','Bergström',NULL,NULL,'lindabergstrom@iracket.local',NULL,'female',NULL,1995,188,1,NULL,NULL,NULL,1,'2026-02-02 09:57:54',NULL,0,1,0,NULL,NULL,'$2y$12$s.isQ7TvTndspti2yYBGwOw0Inm7U8Et1n9LQaJ1SnyVotwF6AjDm',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'2026-02-02 09:57:54','2026-02-02 09:57:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

